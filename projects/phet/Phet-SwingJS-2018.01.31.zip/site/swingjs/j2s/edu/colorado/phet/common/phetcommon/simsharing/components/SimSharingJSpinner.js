(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.components"),I$=[['java.awt.event.MouseAdapter','java.awt.event.KeyAdapter','java.awt.event.FocusAdapter','edu.colorado.phet.common.phetcommon.simsharing.messages.UserActions','edu.colorado.phet.common.phetcommon.simsharing.messages.ParameterKeys','edu.colorado.phet.common.phetcommon.simsharing.messages.ParameterValues','edu.colorado.phet.common.phetcommon.simsharing.messages.ParameterSet','javax.swing.SpinnerNumberModel',['javax.swing.JSpinner','.NumberEditor'],'edu.colorado.phet.common.phetcommon.simsharing.messages.UserComponent','javax.swing.JButton','javax.swing.JPanel','javax.swing.JFrame']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SimSharingJSpinner", null, 'javax.swing.JSpinner');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.userComponent = null;
this.buttonPressed = false;
this.enterPressed = false;
this.focusLost = false;
this.upPressed = false;
this.downPressed = false;
this.$keyListener = null;
this.$focusListener = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$javax_swing_SpinnerModel', function (userComponent, model) {
C$.superclazz.c$$javax_swing_SpinnerModel.apply(this, [model]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent', function (userComponent) {
Clazz.super_(C$, this,1);
this.userComponent = userComponent;
p$.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'init', function () {
p$.initListeners.apply(this, []);
p$.enableMouseEvents.apply(this, []);
});

Clazz.newMeth(C$, 'initListeners', function () {
var mouseListener = ((
(function(){var C$=Clazz.newClass(P$, "SimSharingJSpinner$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
this.b$['edu.colorado.phet.common.phetcommon.simsharing.components.SimSharingJSpinner'].buttonPressed = true;
});

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (e) {
this.b$['edu.colorado.phet.common.phetcommon.simsharing.components.SimSharingJSpinner'].buttonPressed = false;
});
})()
), Clazz.new_((I$[1]||$incl$(1)), [this, null],P$.SimSharingJSpinner$1));
for (var child, $child = 0, $$child = this.getComponents(); $child<$$child.length&&((child=$$child[$child]),1);$child++) {
if (Clazz.instanceOf(child, "javax.swing.JButton")) {
(child).addMouseListener$java_awt_event_MouseListener(mouseListener);
}}
{
this.$keyListener = ((
(function(){var C$=Clazz.newClass(P$, "SimSharingJSpinner$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.KeyAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'keyPressed$java_awt_event_KeyEvent', function (e) {
if (e.getKeyCode() == 10) {
this.b$['edu.colorado.phet.common.phetcommon.simsharing.components.SimSharingJSpinner'].enterPressed = true;
} else if (e.getKeyCode() == 38) {
this.b$['edu.colorado.phet.common.phetcommon.simsharing.components.SimSharingJSpinner'].upPressed = true;
} else if (e.getKeyCode() == 40) {
this.b$['edu.colorado.phet.common.phetcommon.simsharing.components.SimSharingJSpinner'].downPressed = true;
}});
})()
), Clazz.new_((I$[2]||$incl$(2)), [this, null],P$.SimSharingJSpinner$2));
this.$focusListener = ((
(function(){var C$=Clazz.newClass(P$, "SimSharingJSpinner$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.FocusAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'focusLost$java_awt_event_FocusEvent', function (e) {
this.b$['edu.colorado.phet.common.phetcommon.simsharing.components.SimSharingJSpinner'].focusLost = true;
});
})()
), Clazz.new_((I$[3]||$incl$(3)), [this, null],P$.SimSharingJSpinner$3));
var editor = this.getEditor();
if (Clazz.instanceOf(editor, "javax.swing.JSpinner.DefaultEditor")) {
var textField = (editor).getTextField();
textField.addKeyListener$java_awt_event_KeyListener(this.$keyListener);
textField.addFocusListener$java_awt_event_FocusListener(this.$focusListener);
}}});

Clazz.newMeth(C$, 'setEnabled$Z', function (enabled) {
this.focusLost = this.focusLost && enabled ;
C$.superclazz.prototype.setEnabled$Z.apply(this, [enabled]);
});

Clazz.newMeth(C$, 'setEditor$javax_swing_JComponent', function (editor) {
var currentEditor = this.getEditor();
if (Clazz.instanceOf(currentEditor, "javax.swing.JSpinner.DefaultEditor")) {
var textField = (currentEditor).getTextField();
textField.removeKeyListener$java_awt_event_KeyListener(this.$keyListener);
textField.removeFocusListener$java_awt_event_FocusListener(this.$focusListener);
}if (Clazz.instanceOf(editor, "javax.swing.JSpinner.DefaultEditor")) {
var textField = (editor).getTextField();
textField.addKeyListener$java_awt_event_KeyListener(this.$keyListener);
textField.addFocusListener$java_awt_event_FocusListener(this.$focusListener);
}C$.superclazz.prototype.setEditor$javax_swing_JComponent.apply(this, [editor]);
});

Clazz.newMeth(C$, 'enableMouseEvents', function () {
this.enableEvents$J(16);
});

Clazz.newMeth(C$, 'processMouseEvent$java_awt_event_MouseEvent', function (e) {
if (e.getID() == 501 && !this.isEnabled() ) {
this.sendMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserAction$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet((I$[4]||$incl$(4)).mousePressed, this.getCommonParameters().$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$Z((I$[5]||$incl$(5)).enabled, this.isEnabled()).$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$Z((I$[5]||$incl$(5)).interactive, this.isEnabled()));
}C$.superclazz.prototype.processMouseEvent$java_awt_event_MouseEvent.apply(this, [e]);
});

Clazz.newMeth(C$, 'fireStateChanged', function () {
if (this.buttonPressed) {
this.sendMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserAction((I$[4]||$incl$(4)).buttonPressed);
} else if (this.enterPressed) {
p$.sendTextFieldCommittedMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterValue.apply(this, [(I$[6]||$incl$(6)).enterKey]);
this.enterPressed = false;
} else if (this.focusLost) {
p$.sendTextFieldCommittedMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterValue.apply(this, [(I$[6]||$incl$(6)).focusLost]);
this.focusLost = false;
} else if (this.upPressed) {
p$.sendTextFieldCommittedMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterValue.apply(this, [(I$[6]||$incl$(6)).upKey]);
this.upPressed = false;
} else if (this.downPressed) {
p$.sendTextFieldCommittedMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterValue.apply(this, [(I$[6]||$incl$(6)).downKey]);
this.downPressed = false;
}C$.superclazz.prototype.fireStateChanged.apply(this, []);
});

Clazz.newMeth(C$, 'sendTextFieldCommittedMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterValue', function (commitAction) {
this.sendMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserAction$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet((I$[4]||$incl$(4)).textFieldCommitted, (I$[7]||$incl$(7)).parameterSet$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterValue((I$[5]||$incl$(5)).commitAction, commitAction).$with$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet(this.getCommonParameters()));
});

Clazz.newMeth(C$, 'getCommonParameters', function () {
return edu.colorado.phet.common.phetcommon.simsharing.messages.ParameterSet.parameterSet$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$S((I$[5]||$incl$(5)).value, this.getValue().toString());
});

Clazz.newMeth(C$, 'sendMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserAction', function (action) {
this.sendMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserAction$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet(action, this.getCommonParameters());
});

Clazz.newMeth(C$, 'sendMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserAction$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet', function (action, parameterSet) {
});

Clazz.newMeth(C$, 'main', function (args) {
var spinner = ((
(function(){var C$=Clazz.newClass(P$, "SimSharingJSpinner$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('edu.colorado.phet.common.phetcommon.simsharing.components.SimSharingJSpinner'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
{
this.setModel$javax_swing_SpinnerModel(Clazz.new_((I$[8]||$incl$(8)).c$$I$I$I$I,[0, 0, 100, 1]));
var editor = Clazz.new_((I$[9]||$incl$(9)).c$$javax_swing_JSpinner,[this]);
this.setEditor$javax_swing_JComponent(editor);
editor.getTextField().addKeyListener$java_awt_event_KeyListener(((
(function(){var C$=Clazz.newClass(P$, "SimSharingJSpinner$4$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.KeyAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'keyPressed$java_awt_event_KeyEvent', function (e) {
if (e.getKeyCode() == 10) {
try {
this.b$['edu.colorado.phet.common.phetcommon.simsharing.components.SimSharingJSpinner$4'].commitEdit();
} catch (pe) {
if (Clazz.exceptionOf(pe, "java.text.ParseException")){
pe.printStackTrace();
} else {
throw pe;
}
}
System.out.println$S("client: enter pressed, value=" + this.b$['edu.colorado.phet.common.phetcommon.simsharing.components.SimSharingJSpinner$4'].getValue());
}});
})()
), Clazz.new_((I$[2]||$incl$(2)), [this, null],P$.SimSharingJSpinner$4$1)));
editor.getTextField().addFocusListener$java_awt_event_FocusListener(((
(function(){var C$=Clazz.newClass(P$, "SimSharingJSpinner$4$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.FocusAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'focusLost$java_awt_event_FocusEvent', function (e) {
try {
this.b$['edu.colorado.phet.common.phetcommon.simsharing.components.SimSharingJSpinner$4'].commitEdit();
} catch (pe) {
if (Clazz.exceptionOf(pe, "java.text.ParseException")){
pe.printStackTrace();
} else {
throw pe;
}
}
System.out.println$S("client: focus lost, value=" + this.b$['edu.colorado.phet.common.phetcommon.simsharing.components.SimSharingJSpinner$4'].getValue());
});
})()
), Clazz.new_((I$[3]||$incl$(3)), [this, null],P$.SimSharingJSpinner$4$2)));
}
}, 1);
})()
), Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent, [this, null, Clazz.new_((I$[10]||$incl$(10)).c$$S,["testSpinner"])],P$.SimSharingJSpinner$4));
var button = Clazz.new_((I$[11]||$incl$(11)).c$$S,["button"]);
var frame = ((
(function(){var C$=Clazz.newClass(P$, "SimSharingJSpinner$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.JFrame'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
{
this.setContentPane$java_awt_Container(((
(function(){var C$=Clazz.newClass(P$, "SimSharingJSpinner$5$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.JPanel'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
{
this.add$java_awt_Component(this.$finals.spinner);
this.add$java_awt_Component(this.$finals.button);
}
}, 1);
})()
), Clazz.new_((I$[12]||$incl$(12)), [this, {spinner: this.$finals.spinner, button: this.$finals.button}],P$.SimSharingJSpinner$5$1)));
this.pack();
this.setDefaultCloseOperation$I(3);
}
}, 1);
})()
), Clazz.new_((I$[13]||$incl$(13)), [this, {spinner: spinner, button: button}],P$.SimSharingJSpinner$5));
frame.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:50
