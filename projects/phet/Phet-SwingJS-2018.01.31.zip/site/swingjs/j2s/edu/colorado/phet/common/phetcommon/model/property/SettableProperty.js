(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.property"),I$=[];
var C$=Clazz.newClass(P$, "SettableProperty", null, 'edu.colorado.phet.common.phetcommon.model.property.ObservableProperty');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['c$$TT'], function (oldValue) {
C$.superclazz.c$$TT.apply(this, [oldValue]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:48
