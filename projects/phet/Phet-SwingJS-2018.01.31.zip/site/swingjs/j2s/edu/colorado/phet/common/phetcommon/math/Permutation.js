(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[['java.util.ArrayList','edu.colorado.phet.common.phetcommon.util.FunctionalUtils','edu.colorado.phet.common.phetcommon.math.Permutation','edu.colorado.phet.common.phetcommon.math.Permutation$1','edu.colorado.phet.common.phetcommon.math.Permutation$2','java.util.Arrays']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Permutation");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.indices = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'identity$I', function (size) {
Clazz.assert(C$, this, function(){return (size >= 0)});
var indices = Clazz.array(Integer.TYPE, [size]);
for (var i = 0; i < size; i++) {
indices[i] = i;
}
return Clazz.new_(C$.c$$IA,[indices]);
}, 1);

Clazz.newMeth(C$, 'permutations$I', function (size) {
var result = Clazz.new_((I$[1]||$incl$(1)));
C$.forEachPermutation$java_util_List$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1((I$[2]||$incl$(2)).rangeInclusive$I$I(0, size - 1), ((
(function(){var C$=Clazz.newClass(P$, "Permutation$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.VoidFunction1', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['$apply$java_util_List','$apply$TT'], function (integers) {
this.$finals.result.add$TE(Clazz.new_((I$[3]||$incl$(3)).c$$java_util_List,[integers]));
});
})()
), Clazz.new_((I$[4]||$incl$(4)).$init$, [this, {result: result}])));
return result;
}, 1);

Clazz.newMeth(C$, 'c$$IA', function (permutation) {
C$.$init$.apply(this);
this.indices = permutation;
}, 1);

Clazz.newMeth(C$, 'c$$java_util_List', function (permutation) {
C$.$init$.apply(this);
this.indices = Clazz.array(Integer.TYPE, [permutation.size()]);
for (var i = 0; i < permutation.size(); i++) {
this.indices[i] = (permutation.get$I(i)).intValue();
}
}, 1);

Clazz.newMeth(C$, '$apply$java_util_List', function (objects) {
if (objects.size() != this.indices.length) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Permutation length " + this.size() + " not equal to list length " + objects.size() ]);
}var result = Clazz.new_((I$[1]||$incl$(1)).c$$I,[objects.size()]);
for (var i = 0; i < objects.size(); i++) {
result.add$TE(objects.get$I(this.indices[i]));
}
return result;
});

Clazz.newMeth(C$, '$apply$I', function (index) {
return this.indices[index];
});

Clazz.newMeth(C$, 'size', function () {
return this.indices.length;
});

Clazz.newMeth(C$, 'inverted', function () {
var newPermutation = Clazz.array(Integer.TYPE, [this.size()]);
for (var i = 0; i < this.size(); i++) {
newPermutation[this.indices[i]] = i;
}
return Clazz.new_(C$.c$$IA,[newPermutation]);
});

Clazz.newMeth(C$, 'withIndicesPermuted$java_util_List', function (indices) {
var result = Clazz.new_((I$[1]||$incl$(1)));
C$.forEachPermutation$java_util_List$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1(indices, ((
(function(){var C$=Clazz.newClass(P$, "Permutation$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.VoidFunction1', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['$apply$java_util_List','$apply$TT'], function (integers) {
var oldIndices = this.b$['edu.colorado.phet.common.phetcommon.math.Permutation'].indices;
var newPermutation = Clazz.array(Integer.TYPE, [oldIndices.length]);
System.arraycopy(oldIndices, 0, newPermutation, 0, oldIndices.length);
for (var i = 0; i < this.$finals.indices.size(); i++) {
newPermutation[this.$finals.indices.get$I(i)] = oldIndices[integers.get$I(i)];
}
this.$finals.result.add$TE(Clazz.new_((I$[3]||$incl$(3)).c$$IA,[newPermutation]));
});
})()
), Clazz.new_((I$[5]||$incl$(5)).$init$, [this, {indices: indices, result: result}])));
return result;
});

Clazz.newMeth(C$, 'toString', function () {
return (I$[6]||$incl$(6)).toString$IA(this.indices);
});

Clazz.newMeth(C$, 'forEachPermutation$java_util_List$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1', function (list, $function) {
C$.forEachPermutation$java_util_List$java_util_List$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1(list, Clazz.new_((I$[1]||$incl$(1))), $function);
}, 1);

Clazz.newMeth(C$, 'forEachPermutation$java_util_List$java_util_List$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1', function (list, prefix, $function) {
if (list.isEmpty()) {
$function.$apply$TT(prefix);
} else {
for (var element, $element = list.iterator(); $element.hasNext()&&((element=$element.next()),1);) {
C$.forEachPermutation$java_util_List$java_util_List$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1(((
(function(){var C$=Clazz.newClass(P$, "Permutation$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.util.ArrayList'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
{
this.remove$O(this.$finals.element);
}
}, 1);
})()
), Clazz.new_((I$[1]||$incl$(1)).c$$java_util_Collection, [this, null, list],P$.Permutation$3)), ((
(function(){var C$=Clazz.newClass(P$, "Permutation$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.util.ArrayList'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
{
this.add$TE(this.$finals.element);
}
}, 1);
})()
), Clazz.new_((I$[1]||$incl$(1)).c$$java_util_Collection, [this, null, prefix],P$.Permutation$4)), $function);
}
}}, 1);

Clazz.newMeth(C$, 'main', function (args) {
var a = Clazz.new_(C$.c$$IA,[Clazz.array(Integer.TYPE, -1, [1, 4, 3, 2, 0])]);
System.out.println$O(a);
var b = a.inverted();
System.out.println$O(b);
System.out.println$O(b.withIndicesPermuted$java_util_List((I$[6]||$incl$(6)).asList$TTA([new Integer(0), new Integer(3), new Integer(4)])));
System.out.println$O(C$.permutations$I(4));
}, 1);
C$.$_ASSERT_ENABLED_ = ClassLoader.$getClassAssertionStatus(C$);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:46
