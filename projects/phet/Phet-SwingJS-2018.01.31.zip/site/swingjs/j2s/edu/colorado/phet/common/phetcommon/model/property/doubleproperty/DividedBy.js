(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.property.doubleproperty"),I$=[['edu.colorado.phet.common.phetcommon.model.property.doubleproperty.DividedBy$1']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DividedBy", null, 'edu.colorado.phet.common.phetcommon.model.property.doubleproperty.CompositeDoubleProperty');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty', function (numerator, denominator) {
C$.superclazz.c$$edu_colorado_phet_common_phetcommon_util_function_Function0$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA.apply(this, [((
(function(){var C$=Clazz.newClass(P$, "DividedBy$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.Function0', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, '$apply', function () {
if ((this.$finals.numerator.get()).doubleValue() === 0 ) {
return new Double(0.0);
} else {
return new Double((this.$finals.numerator.get()).doubleValue() / (this.$finals.denominator.get()).doubleValue());
}});
})()
), Clazz.new_((I$[1]||$incl$(1)).$init$, [this, {numerator: numerator, denominator: denominator}])), [numerator, denominator]]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:48
