(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.dialogs"),I$=[['edu.colorado.phet.common.phetcommon.resources.PhetCommonResources','edu.colorado.phet.common.phetcommon.view.VerticalLayoutPanel','javax.swing.JSeparator','edu.colorado.phet.common.phetcommon.view.util.SwingUtils','javax.swing.JLabel','java.awt.Font','java.awt.Insets','javax.swing.Box','edu.colorado.phet.common.phetcommon.simsharing.components.SimSharingJButton','edu.colorado.phet.common.phetcommon.simsharing.messages.UserComponents','edu.colorado.phet.common.phetcommon.dialogs.PhetAboutDialog$1','javax.swing.JPanel','java.awt.FlowLayout']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "PhetAboutDialog", null, 'edu.colorado.phet.common.phetcommon.application.PaintImmediateDialog');
C$.TITLE = null;
C$.SIM_VERSION = null;
C$.BUILD_DATE = null;
C$.DISTRIBUTION = null;
C$.JAVA_VERSION = null;
C$.OS_VERSION = null;
C$.CLOSE_BUTTON = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.TITLE = (I$[1]||$incl$(1)).getString$S("Common.HelpMenu.AboutTitle");
C$.SIM_VERSION = (I$[1]||$incl$(1)).getString$S("Common.About.Version");
C$.BUILD_DATE = (I$[1]||$incl$(1)).getString$S("Common.About.BuildDate");
C$.DISTRIBUTION = (I$[1]||$incl$(1)).getString$S("Common.About.Distribution");
C$.JAVA_VERSION = (I$[1]||$incl$(1)).getString$S("Common.About.JavaVersion");
C$.OS_VERSION = (I$[1]||$incl$(1)).getString$S("Common.About.OSVersion");
C$.CLOSE_BUTTON = (I$[1]||$incl$(1)).getString$S("Common.choice.close");
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_application_PhetApplication', function (phetApplication) {
C$.c$$java_awt_Frame$edu_colorado_phet_common_phetcommon_application_ISimInfo.apply(this, [phetApplication.getPhetFrame(), phetApplication.getSimInfo()]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Frame$edu_colorado_phet_common_phetcommon_application_ISimInfo', function (owner, config) {
C$.superclazz.c$$java_awt_Frame.apply(this, [owner]);
C$.$init$.apply(this);
this.setResizable$Z(false);
var titleString = config.getName();
this.setTitle$S(C$.TITLE + " " + titleString );
var infoPanel = p$.createInfoPanel$edu_colorado_phet_common_phetcommon_application_ISimInfo.apply(this, [config]);
var buttonPanel = p$.createButtonPanel$Z.apply(this, [config.isStatisticsFeatureIncluded()]);
var contentPanel = Clazz.new_((I$[2]||$incl$(2)));
contentPanel.setFillHorizontal();
contentPanel.add$java_awt_Component(infoPanel);
contentPanel.add$java_awt_Component(Clazz.new_((I$[3]||$incl$(3))));
contentPanel.add$java_awt_Component(buttonPanel);
this.setContentPane$java_awt_Container(contentPanel);
this.pack();
(I$[4]||$incl$(4)).centerDialogInParent$javax_swing_JDialog(this);
}, 1);

Clazz.newMeth(C$, 'createInfoPanel$edu_colorado_phet_common_phetcommon_application_ISimInfo', function (config) {
var titleString = config.getName();
var versionString = config.getVersion().formatForAboutDialog();
var buildDate = config.getVersion().formatTimestamp();
var distributionTag = config.getDistributionTag();
var infoPanel = Clazz.new_((I$[2]||$incl$(2)));
var titleLabel = Clazz.new_((I$[5]||$incl$(5)).c$$S,[titleString]);
var f = titleLabel.getFont();
titleLabel.setFont$java_awt_Font(Clazz.new_((I$[6]||$incl$(6)).c$$S$I$I,[f.getFontName(), 1, f.getSize()]));
var versionLabel = Clazz.new_((I$[5]||$incl$(5)).c$$S,[C$.SIM_VERSION + " " + versionString ]);
var buildDateLabel = Clazz.new_((I$[5]||$incl$(5)).c$$S,[C$.BUILD_DATE + " " + buildDate ]);
var distributionTagLabel = null;
if (distributionTag != null  && distributionTag.length$() > 0 ) {
distributionTagLabel = Clazz.new_((I$[5]||$incl$(5)).c$$S,[C$.DISTRIBUTION + " " + distributionTag ]);
}var javaVersionString = C$.JAVA_VERSION + " " + System.getProperty("java.version") ;
var javaVersionLabel = Clazz.new_((I$[5]||$incl$(5)).c$$S,[javaVersionString]);
var osVersion = C$.OS_VERSION + " " + System.getProperty("os.name") + " " + System.getProperty("os.version") ;
var osVersionLabel = Clazz.new_((I$[5]||$incl$(5)).c$$S,[osVersion]);
var xMargin = 10;
var ySpacing = 10;
infoPanel.setInsets$java_awt_Insets(Clazz.new_((I$[7]||$incl$(7)).c$$I$I$I$I,[0, xMargin, 0, xMargin]));
infoPanel.add$java_awt_Component((I$[8]||$incl$(8)).createVerticalStrut$I(ySpacing));
infoPanel.add$java_awt_Component(titleLabel);
infoPanel.add$java_awt_Component((I$[8]||$incl$(8)).createVerticalStrut$I(ySpacing));
infoPanel.add$java_awt_Component(versionLabel);
infoPanel.add$java_awt_Component(buildDateLabel);
if (distributionTagLabel != null ) {
infoPanel.add$java_awt_Component(distributionTagLabel);
}infoPanel.add$java_awt_Component((I$[8]||$incl$(8)).createVerticalStrut$I(ySpacing));
infoPanel.add$java_awt_Component(javaVersionLabel);
infoPanel.add$java_awt_Component(osVersionLabel);
infoPanel.add$java_awt_Component((I$[8]||$incl$(8)).createVerticalStrut$I(ySpacing));
return infoPanel;
});

Clazz.newMeth(C$, 'createButtonPanel$Z', function (isStatisticsFeatureIncluded) {
var closeButton = Clazz.new_((I$[9]||$incl$(9)).c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$S,[(I$[10]||$incl$(10)).aboutDialogCloseButton, C$.CLOSE_BUTTON]);
this.getRootPane().setDefaultButton$javax_swing_JButton(closeButton);
closeButton.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "PhetAboutDialog$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['edu.colorado.phet.common.phetcommon.dialogs.PhetAboutDialog'].dispose();
});
})()
), Clazz.new_((I$[11]||$incl$(11)).$init$, [this, null])));
var buttonPanel = Clazz.new_((I$[12]||$incl$(12)));
buttonPanel.setLayout$java_awt_LayoutManager(Clazz.new_((I$[13]||$incl$(13))));
buttonPanel.add$java_awt_Component(closeButton);
return buttonPanel;
});

Clazz.newMeth(C$, 'showCredits', function () {
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:45
