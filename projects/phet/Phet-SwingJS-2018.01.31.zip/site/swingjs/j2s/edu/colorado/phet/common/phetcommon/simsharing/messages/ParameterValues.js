(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.messages"),I$=[];
var C$=Clazz.newClass(P$, "ParameterValues", null, 'Enum', 'edu.colorado.phet.common.phetcommon.simsharing.messages.IParameterValue');

C$.$clinit$ = function() {Clazz.load(C$, 1);
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "focusLost", 0, []);
Clazz.newEnumConst($vals, C$.c$, "enterKey", 1, []);
Clazz.newEnumConst($vals, C$.c$, "downKey", 2, []);
Clazz.newEnumConst($vals, C$.c$, "upKey", 3, []);
Clazz.newEnumConst($vals, C$.c$, "parseError", 4, []);
Clazz.newEnumConst($vals, C$.c$, "rangeError", 5, []);
Clazz.newEnumConst($vals, C$.c$, "numberFormatException", 6, []);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values', function() { return $vals }, 1);
})();
//Created 2018-01-31 11:02:51
