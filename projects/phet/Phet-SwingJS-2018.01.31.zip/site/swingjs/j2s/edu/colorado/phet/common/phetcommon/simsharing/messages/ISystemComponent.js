(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.messages"),I$=[];
var C$=Clazz.newInterface(P$, "ISystemComponent", null, null, 'edu.colorado.phet.common.phetcommon.simsharing.messages.IUserComponent');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-01-31 11:02:50
