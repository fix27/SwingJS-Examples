(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.components"),I$=[];
var C$=Clazz.newClass(P$, "SimSharingIcon", null, 'javax.swing.JLabel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.object = null;
this.$function = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$javax_swing_Icon$edu_colorado_phet_common_phetcommon_util_function_VoidFunction0', function (object, icon, $function) {
C$.superclazz.c$$javax_swing_Icon.apply(this, [icon]);
C$.$init$.apply(this);
this.object = object;
this.$function = $function;
this.enableEvents$J(16);
}, 1);

Clazz.newMeth(C$, 'processMouseEvent$java_awt_event_MouseEvent', function (e) {
if (e.getID() == 501) {
this.$function.$apply();
}C$.superclazz.prototype.processMouseEvent$java_awt_event_MouseEvent.apply(this, [e]);
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:49
