(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.util"),I$=[['edu.colorado.phet.common.phetcommon.view.util.ColorUtils']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ColorRange");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.min = null;
this.max = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Color$java_awt_Color', function (min, max) {
C$.$init$.apply(this);
this.min = min;
this.max = max;
}, 1);

Clazz.newMeth(C$, 'getMin', function () {
return this.min;
});

Clazz.newMeth(C$, 'getMax', function () {
return this.max;
});

Clazz.newMeth(C$, 'interpolateLinear$D', function (distance) {
if (distance < 0  || distance > 1  ) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["distance out of range: " + new Double(distance).toString()]);
}return (I$[1]||$incl$(1)).interpolateRBGA$java_awt_Color$java_awt_Color$D(this.min, this.max, distance);
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:51
