(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.resources"),I$=[['java.util.Hashtable','java.util.Properties','edu.colorado.phet.common.phetcommon.resources.PhetProperties','Thread','java.lang.StringBuffer','java.io.ByteArrayOutputStream']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "AbstractResourceLoader", null, null, 'edu.colorado.phet.common.phetcommon.resources.IResourceLoader');
C$.htProperties = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.htProperties = Clazz.new_((I$[1]||$incl$(1)));
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'exists$S', function (resource) {
var cl = this.getClass().getClassLoader();
var url = cl.getResource$S(resource);
return url != null ;
});

Clazz.newMeth(C$, 'getProperties$S$java_util_Locale', function (resourceName, locale) {
var saved = C$.htProperties.get$O(resourceName);
if (saved != null ) return saved;
var properties = null;
try {
properties = p$.loadProperties$S.apply(this, [p$.getFallbackPropertiesResourceName$S.apply(this, [resourceName])]);
var slang = locale.toString();
if (!slang.equals$O("en_US") && !slang.equals$O("en") ) {
var props = p$.loadProperties$S.apply(this, [p$.getLocalizedPropertiesResourceName$S$S.apply(this, [resourceName, slang.substring(0, 2)])]);
properties.putAll$java_util_Map(props);
if (locale.getCountry().length$() > 0) {
props = p$.loadProperties$S.apply(this, [p$.getLocalizedPropertiesResourceName$S$S.apply(this, [resourceName, slang.substring(0, 5)])]);
properties.putAll$java_util_Map(props);
}if (locale.getVariant().length$() > 0) {
props = p$.loadProperties$S.apply(this, [p$.getLocalizedPropertiesResourceName$S$S.apply(this, [resourceName, slang])]);
properties.putAll$java_util_Map(props);
}}} catch (e) {
if (Clazz.exceptionOf(e, "java.io.IOException")){
e.printStackTrace();
properties = Clazz.new_((I$[2]||$incl$(2)));
} else {
throw e;
}
}
var ret = Clazz.new_((I$[3]||$incl$(3)).c$$java_util_Properties,[properties]);
C$.htProperties.put$TK$TV(resourceName, ret);
return ret;
});

Clazz.newMeth(C$, 'loadProperties$S', function (resourceName) {
var properties = Clazz.new_((I$[2]||$incl$(2)));
var inStream = (I$[4]||$incl$(4)).currentThread().getContextClassLoader().getResourceAsStream$S(resourceName);
if (inStream != null ) {
properties.load$java_io_InputStream(inStream);
}return properties;
});

Clazz.newMeth(C$, 'getLocalizedPropertiesResourceName$S$S', function (resourceName, inFix) {
return p$.stripPropertiesSuffix$S.apply(this, [resourceName]) + "_" + inFix + ".properties" ;
});

Clazz.newMeth(C$, 'getFallbackPropertiesResourceName$S', function (resourceName) {
var basename = p$.stripPropertiesSuffix$S.apply(this, [resourceName]);
return basename + ".properties";
});

Clazz.newMeth(C$, 'stripPropertiesSuffix$S', function (s) {
if (s.endsWith$S(".properties")) {
s = s.substring(0, s.length$() - ".properties".length$());
}return s;
});

Clazz.newMeth(C$, 'getResourceAsStream$S', function (resource) {
var stream = (I$[4]||$incl$(4)).currentThread().getContextClassLoader().getResourceAsStream$S(resource);
if (stream == null ) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["invalid resource: " + resource]);
}return stream;
});

Clazz.newMeth(C$, 'getResourceAsString$S', function (resourceName) {
var $in = this.getResourceAsStream$S(resourceName);
var out = Clazz.new_((I$[5]||$incl$(5)));
var b = Clazz.array(Byte.TYPE, [4096]);
for (var n; (n = $in.read$BA(b)) != -1; ) {
out.append$S( String.instantialize(b, 0, n));
}
return out.toString();
});

Clazz.newMeth(C$, 'getResource$S', function (resource) {
var out = Clazz.new_((I$[6]||$incl$(6)));
var stream = this.getResourceAsStream$S(resource);
try {
var buffer = Clazz.array(Byte.TYPE, [1000]);
var bytesRead;
while ((bytesRead = stream.read$BA(buffer)) >= 0){
out.write$BA$I$I(buffer, 0, bytesRead);
}
out.flush();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
try {
stream.close();
} catch (e1) {
if (Clazz.exceptionOf(e1, "java.io.IOException")){
e1.printStackTrace();
} else {
throw e1;
}
}
} else {
throw e;
}
}
return out.toByteArray();
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:49
