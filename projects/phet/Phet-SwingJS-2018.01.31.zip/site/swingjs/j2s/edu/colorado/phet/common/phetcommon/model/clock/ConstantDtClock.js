(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.clock"),I$=[['javax.swing.event.EventListenerList',['edu.colorado.phet.common.phetcommon.model.clock.ConstantDtClock','.ConstantDtClockEvent'],['edu.colorado.phet.common.phetcommon.model.clock.TimingStrategy','.Constant'],['edu.colorado.phet.common.phetcommon.model.clock.ConstantDtClock','.ConstantDtClockListener']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ConstantDtClock", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'edu.colorado.phet.common.phetcommon.model.clock.SwingClock');
C$.TEST = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.TEST = Clazz.new_(C$.c$$I$D,[1, 1]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.listenerList = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$D.apply(this, [30.0]);
}, 1);

Clazz.newMeth(C$, 'c$$D', function (framesPerSecond) {
C$.c$$I$D.apply(this, [((1000 / framesPerSecond)|0), 1 / framesPerSecond]);
}, 1);

Clazz.newMeth(C$, 'c$$I$D', function (delay, dt) {
C$.superclazz.c$$I$D.apply(this, [delay, dt]);
C$.$init$.apply(this);
this.listenerList = Clazz.new_((I$[1]||$incl$(1)));
}, 1);

Clazz.newMeth(C$, 'setDelay$I', function (delay) {
if (delay != this.getDelay()) {
C$.superclazz.prototype.setDelay$I.apply(this, [delay]);
p$.fireDelayChanged$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock_ConstantDtClockEvent.apply(this, [Clazz.new_((I$[2]||$incl$(2)).c$$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock,[this])]);
}});

Clazz.newMeth(C$, 'setDt$D', function (dt) {
if (dt != this.getDt() ) {
this.setTimingStrategy$edu_colorado_phet_common_phetcommon_model_clock_TimingStrategy(Clazz.new_((I$[3]||$incl$(3)).c$$D,[dt]));
}});

Clazz.newMeth(C$, 'getDt', function () {
return (this.getTimingStrategy()).getSimulationTimeChange();
});

Clazz.newMeth(C$, 'setRunning$Z', function (running) {
if (running) {
this.start();
} else {
this.pause();
}});

Clazz.newMeth(C$, 'setPaused$Z', function (paused) {
this.setRunning$Z(!paused);
});

Clazz.newMeth(C$, 'setTimingStrategy$edu_colorado_phet_common_phetcommon_model_clock_TimingStrategy', function (timingStrategy) {
if (!(Clazz.instanceOf(timingStrategy, "edu.colorado.phet.common.phetcommon.model.clock.TimingStrategy.Constant"))) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["timingStrategy must be of type TimingStrategy.Constant"]);
}C$.superclazz.prototype.setTimingStrategy$edu_colorado_phet_common_phetcommon_model_clock_TimingStrategy.apply(this, [timingStrategy]);
p$.fireDtChanged$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock_ConstantDtClockEvent.apply(this, [Clazz.new_((I$[2]||$incl$(2)).c$$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock,[this])]);
});

Clazz.newMeth(C$, 'addConstantDtClockListener$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock_ConstantDtClockListener', function (listener) {
this.listenerList.add$Class$TT(Clazz.getClass((I$[4]||$incl$(4)),['delayChanged$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock_ConstantDtClockEvent','dtChanged$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock_ConstantDtClockEvent']), listener);
});

Clazz.newMeth(C$, 'removeConstantDtClockListener$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock_ConstantDtClockListener', function (listener) {
this.listenerList.remove$Class$TT(Clazz.getClass((I$[4]||$incl$(4)),['delayChanged$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock_ConstantDtClockEvent','dtChanged$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock_ConstantDtClockEvent']), listener);
});

Clazz.newMeth(C$, 'fireDelayChanged$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock_ConstantDtClockEvent', function (event) {
var listeners = this.listenerList.getListenerList();
for (var i = 0; i < listeners.length; i = i+(2)) {
if (listeners[i] === Clazz.getClass((I$[4]||$incl$(4)),['delayChanged$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock_ConstantDtClockEvent','dtChanged$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock_ConstantDtClockEvent']) ) {
(listeners[i + 1]).delayChanged$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock_ConstantDtClockEvent(event);
}}
});

Clazz.newMeth(C$, 'fireDtChanged$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock_ConstantDtClockEvent', function (event) {
var listeners = this.listenerList.getListenerList();
for (var i = 0; i < listeners.length; i = i+(2)) {
if (listeners[i] === Clazz.getClass((I$[4]||$incl$(4)),['delayChanged$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock_ConstantDtClockEvent','dtChanged$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock_ConstantDtClockEvent']) ) {
(listeners[i + 1]).dtChanged$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock_ConstantDtClockEvent(event);
}}
});
;
(function(){var C$=Clazz.newInterface(P$.ConstantDtClock, "ConstantDtClockListener", function(){
}, null, 'java.util.EventListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})()
;
(function(){var C$=Clazz.newClass(P$.ConstantDtClock, "ConstantDtClockAdapter", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, [['edu.colorado.phet.common.phetcommon.model.clock.ConstantDtClock','edu.colorado.phet.common.phetcommon.model.clock.ConstantDtClock.ConstantDtClockListener']]);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'delayChanged$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock_ConstantDtClockEvent', function (event) {
});

Clazz.newMeth(C$, 'dtChanged$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock_ConstantDtClockEvent', function (event) {
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.ConstantDtClock, "ConstantDtClockEvent", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'java.util.EventObject');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_model_clock_ConstantDtClock', function (source) {
C$.superclazz.c$.apply(this, [source]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getClock', function () {
return this.getSource();
});

Clazz.newMeth(C$);
})()
})();
//Created 2018-01-31 11:02:47
