(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[];
var C$=Clazz.newClass(P$, "MutableComplex", null, 'edu.colorado.phet.common.phetcommon.math.Complex');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$D$D', function (real, imaginary) {
C$.superclazz.c$$D$D.apply(this, [real, imaginary]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_Complex', function (c) {
C$.superclazz.c$$edu_colorado_phet_common_phetcommon_math_Complex.apply(this, [c]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'copy', function () {
return C$.superclazz.prototype.copy.apply(this, []);
});

Clazz.newMeth(C$, 'setValue$edu_colorado_phet_common_phetcommon_math_Complex', function (c) {
this.setValue$D$D(c._real, c._imaginary);
});

Clazz.newMeth(C$, 'setValue$D$D', function (real, imag) {
this._real = real;
this._imaginary = imag;
});

Clazz.newMeth(C$, 'setValue$D', function (real) {
this.setValue$D$D(real, 0);
});

Clazz.newMeth(C$, 'zero', function () {
this.setValue$D$D(0, 0);
});

Clazz.newMeth(C$, 'add$edu_colorado_phet_common_phetcommon_math_Complex', function (c) {
this.add$D$D(c._real, c._imaginary);
});

Clazz.newMeth(C$, 'add$D$D', function (real, imaginary) {
this._real += real;
this._imaginary += imaginary;
});

Clazz.newMeth(C$, 'add$D', function (real) {
this.add$D$D(real, 0);
});

Clazz.newMeth(C$, 'subtract$edu_colorado_phet_common_phetcommon_math_Complex', function (c) {
this.subtract$D$D(c._real, c._imaginary);
});

Clazz.newMeth(C$, 'subtract$D$D', function (real, imaginary) {
this._real -= real;
this._imaginary -= imaginary;
});

Clazz.newMeth(C$, 'subtract$D', function (real) {
this.subtract$D$D(real, 0);
});

Clazz.newMeth(C$, 'multiply$edu_colorado_phet_common_phetcommon_math_Complex', function (c) {
this.multiply$D$D(c._real, c._imaginary);
});

Clazz.newMeth(C$, 'multiply$D$D', function (real, imaginary) {
var newReal = this._real * real - this._imaginary * imaginary;
var newImaginary = this._real * imaginary + this._imaginary * real;
this._real = newReal;
this._imaginary = newImaginary;
});

Clazz.newMeth(C$, 'multiply$D', function (real) {
this.multiply$D$D(real, 0);
});

Clazz.newMeth(C$, 'divide$edu_colorado_phet_common_phetcommon_math_Complex', function (c) {
this.divide$D$D(c._real, c._imaginary);
});

Clazz.newMeth(C$, 'divide$D$D', function (real, imaginary) {
var q = real * real + imaginary * imaginary;
var g = this._real * real + this._imaginary * imaginary;
var h = this._imaginary * real - this._real * imaginary;
this._real = g / q;
this._imaginary = h / q;
});

Clazz.newMeth(C$, 'divide$D', function (real) {
this.divide$D$D(real, 0);
});

Clazz.newMeth(C$, 'scale$D', function (scale) {
this._real *= scale;
this._imaginary *= scale;
});

Clazz.newMeth(C$, 'exp', function () {
var multiplier = Math.exp(this._real);
this._real = multiplier * Math.cos(this._imaginary);
this._imaginary = multiplier * Math.sin(this._imaginary);
});
})();
//Created 2018-01-31 11:02:46
