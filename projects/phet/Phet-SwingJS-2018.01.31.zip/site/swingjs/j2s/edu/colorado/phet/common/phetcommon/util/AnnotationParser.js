(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.util"),I$=[['java.util.StringTokenizer','java.util.ArrayList',['edu.colorado.phet.common.phetcommon.util.AnnotationParser','.Annotation'],'java.util.HashMap','edu.colorado.phet.common.phetcommon.util.FileUtils',['edu.colorado.phet.common.phetcommon.util.AnnotationParser','.Result'],'java.io.File']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "AnnotationParser", function(){
Clazz.newInstance(this, arguments,0,C$);
});
var p$=C$.prototype;

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getAnnotations$S', function (text) {
var st = Clazz.new_((I$[1]||$incl$(1)).c$$S$S,[text, "\u000a"]);
var annotations = Clazz.new_((I$[2]||$incl$(2)));
while (st.hasMoreTokens()){
var tok = st.nextToken().trim();
if (!tok.startsWith$S("#")) {
annotations.add$TE(C$.parse$S(tok));
}}
return annotations.toArray$TTA(Clazz.array((I$[3]||$incl$(3)), [annotations.size()]));
}, 1);

Clazz.newMeth(C$, 'parse$S', function (line) {
line = line.trim();
var st = Clazz.new_((I$[1]||$incl$(1)).c$$S$S,[line, " "]);
var map = Clazz.new_((I$[4]||$incl$(4)));
var id = st.nextToken();
var keyOrdering = Clazz.new_((I$[2]||$incl$(2)));
for (var index = line.indexOf("="); index >= 0; index = line.indexOf("=", index + 1)) {
var key = C$.getKey$S$I(line, index);
var value = C$.getValue$S$I(line, index);
map.put$TK$TV(key, value);
keyOrdering.add$TE(key);
}
return Clazz.new_((I$[3]||$incl$(3)).c$$S$java_util_HashMap$java_util_ArrayList,[id, map, keyOrdering]);
}, 1);

Clazz.newMeth(C$, 'getValue$S$I', function (line, index) {
var end = line.indexOf("=", index + 1);
if (end < 0) {
end = line.length$();
} else {
for (var i = end; i >= 0; i--) {
if (line.charAt(i) == " ") {
end = i;
break;
}}
}var val = line.substring(index + 1, end);
return val.trim();
}, 1);

Clazz.newMeth(C$, 'getKey$S$I', function (line, index) {
for (var i = index; i >= 0; i--) {
if (line.charAt(i) == " ") {
var key = line.substring(i, index);
return key.trim();
}}
throw Clazz.new_(Clazz.load('java.lang.RuntimeException').c$$S,["No key found"]);
}, 1);

Clazz.newMeth(C$, 'visit$java_io_File', function (file) {
if (file.isDirectory()) {
var fileList = file.listFiles();
for (var file1, $file1 = 0, $$file1 = fileList; $file1<$$file1.length&&((file1=$$file1[$file1]),1);$file1++) {
C$.visit$java_io_File(file1);
}
} else {
if (file.getName().equals$O("license.txt")) {
var newFile = "{\u000a";
try {
var s = (I$[5]||$incl$(5)).loadFileAsString$java_io_File(file);
var st = Clazz.new_((I$[1]||$incl$(1)).c$$S$S,[s, "\u000a"]);
var prev = false;
while (st.hasMoreTokens()){
var token = st.nextToken();
var a = C$.parse$S(token);
if (prev) {
newFile = newFile + ",\n";
}newFile = newFile + C$.annotationToJSONString$S$edu_colorado_phet_common_phetcommon_util_AnnotationParser_Annotation(token, a);
prev = true;
}
} catch (e) {
if (Clazz.exceptionOf(e, "java.io.IOException")){
e.printStackTrace();
} else {
throw e;
}
}
newFile = newFile + "\n}";
(I$[5]||$incl$(5)).writeString$java_io_File$S(file, newFile);
}}}, 1);

Clazz.newMeth(C$, 'annotationToJSONString$S$edu_colorado_phet_common_phetcommon_util_AnnotationParser_Annotation', function (line, a) {
var id = a.id;
var projectURL = a.get$S("source");
var notes = a.get$S("notes");
var license = a.get$S("license");
var author = a.get$S("author");
if (a.map.containsKey$O("Author")) {
author = a.get$S("Author");
}if (a.map.containsKey$O("author") && a.map.containsKey$O("Author") ) {
throw Clazz.new_(Clazz.load('java.lang.RuntimeException').c$$S,["Two authors"]);
}if (projectURL == null ) {
projectURL = "";
}if (notes == null ) {
notes = "";
}if (license == null ) {
license = "";
}if (author == null ) {
author = "";
}var switchToPhET = false;
if (author.equals$O("") && author.equals$O("Ron Le Master") ) {
switchToPhET = true;
notes = "by Ron Le Master" + (notes.equals$O("") ? "" : ", " + notes);
}if (author.equals$O("") && author.equals$O("Emily Randall") ) {
switchToPhET = true;
notes = "by Emily Randall" + (notes.equals$O("") ? "" : ", " + notes);
}if (author.equals$O("") && author.equals$O("Yuen-ying Carpenter") ) {
switchToPhET = true;
notes = "by Yuen-ying Carpenter" + (notes.equals$O("") ? "" : ", " + notes);
}if (author.equals$O("") && author.equals$O("Bryce") ) {
switchToPhET = true;
notes = "by Bryce" + (notes.equals$O("") ? "" : ", " + notes);
}var set = a.map.keySet();
for (var key, $key = set.iterator(); $key.hasNext()&&((key=$key.next()),1);) {
if (!key.equals$O("source") && !key.equals$O("notes") && !key.equals$O("license") && !key.equals$O("author") && !key.equals$O("Author")  ) {
System.out.println$S("UNUSED KEY: " + key);
}}
if (line.toLowerCase().contains$CharSequence("=phet") || switchToPhET ) {
if (notes.equals$O("")) {
notes = author;
} else if (!author.equals$O("")) {
notes = notes + ", " + author ;
}author = "University of Colorado Boulder";
projectURL = "http://phet.colorado.edu";
license = "contact phethelp@colorado.edu";
}var text = "    \"Copyright 2002-2015 " + author + "\"\n" ;
if (line.toLowerCase().contains$CharSequence("public domain")) {
text = "    \"Public Domain\"\u000a";
license = "Public Domain";
}var outputText = Clazz.new_((I$[6]||$incl$(6)).c$$S$S$S$S$S,[id, text, projectURL, license, notes]).toString();
System.out.println$S("LINE:\n" + line + "\nTEXT:\n" + outputText );
return outputText;
}, 1);

Clazz.newMeth(C$, 'main', function (args) {
var a = C$.parse$S("test-id name=my name age=3 timestamp=dec 13, 2008");
System.out.println$S("a = " + a);
C$.visit$java_io_File(Clazz.new_((I$[7]||$incl$(7)).c$$S,["/Users/samreid/github"]));
}, 1);
;
(function(){var C$=Clazz.newClass(P$.AnnotationParser, "Annotation", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.id = null;
this.map = null;
this.keyOrdering = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S$java_util_HashMap$java_util_ArrayList', function (id, map, keyOrdering) {
C$.$init$.apply(this);
this.id = id;
this.map = map;
this.keyOrdering = keyOrdering;
}, 1);

Clazz.newMeth(C$, 'getId', function () {
return this.id;
});

Clazz.newMeth(C$, 'getMap', function () {
return this.map;
});

Clazz.newMeth(C$, 'toString', function () {
return this.id + ": " + this.map ;
});

Clazz.newMeth(C$, 'get$S', function (s) {
return this.map.get$O(s);
});

Clazz.newMeth(C$, 'getKeyOrdering', function () {
return this.keyOrdering;
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.AnnotationParser, "Result", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.id = null;
this.projectURL = null;
this.notes = null;
this.license = null;
this.text = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S$S$S$S$S', function (id, text, projectURL, license, notes) {
C$.$init$.apply(this);
this.id = id;
this.projectURL = projectURL;
this.notes = notes;
this.license = license;
this.text = text;
}, 1);

Clazz.newMeth(C$, 'toString', function () {
return "  \"" + this.id + "\": {\n" + "    \"text\": [\n" + "  " + this.text + "    ],\n" + "    \"projectURL\": \"" + this.projectURL + "\",\n" + "    \"license\": \"" + this.license + "\",\n" + "    \"notes\": \"" + this.notes + "\"\n" + "  }" ;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:51
