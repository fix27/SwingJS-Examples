(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.property"),I$=[['java.util.ArrayList','edu.colorado.phet.common.phetcommon.model.property.Property','edu.colorado.phet.common.phetcommon.model.property.ObservableProperty$1','edu.colorado.phet.common.phetcommon.model.property.ValueEquals']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ObservableProperty", null, null, 'Cloneable');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.simpleObservers = null;
this.newValueObservers = null;
this.newAndOldValueObservers = null;
this.oldValue = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.simpleObservers = Clazz.new_((I$[1]||$incl$(1)));
this.newValueObservers = Clazz.new_((I$[1]||$incl$(1)));
this.newAndOldValueObservers = Clazz.new_((I$[1]||$incl$(1)));
}, 1);

Clazz.newMeth(C$, 'c$$TT', function (oldValue) {
C$.$init$.apply(this);
this.oldValue = oldValue;
}, 1);

Clazz.newMeth(C$, 'addObserver$edu_colorado_phet_common_phetcommon_util_SimpleObserver$Z', function (simpleObserver, notifyOnAdd) {
{
this.simpleObservers.add$TE(simpleObserver);
}if (notifyOnAdd) {
simpleObserver.update();
}});

Clazz.newMeth(C$, 'notifyObservers$TT$TT', function (value, oldValue) {
p$.notifySimpleObservers.apply(this, []);
p$.notifyNewValueObservers$TT.apply(this, [value]);
p$.notifyNewAndOldValueObservers$TT$TT.apply(this, [value, oldValue]);
});

Clazz.newMeth(C$, 'notifySimpleObservers', function () {
var copy;
{
copy = Clazz.new_((I$[1]||$incl$(1)).c$$java_util_Collection,[this.simpleObservers]);
}for (var simpleObserver, $simpleObserver = copy.iterator(); $simpleObserver.hasNext()&&((simpleObserver=$simpleObserver.next()),1);) {
simpleObserver.update();
}
});

Clazz.newMeth(C$, 'notifyNewValueObservers$TT', function (newValue) {
var copy;
{
copy = Clazz.new_((I$[1]||$incl$(1)).c$$java_util_Collection,[this.newValueObservers]);
}for (var observer, $observer = copy.iterator(); $observer.hasNext()&&((observer=$observer.next()),1);) {
observer.$apply$TT(newValue);
}
});

Clazz.newMeth(C$, 'removeObserver$edu_colorado_phet_common_phetcommon_util_SimpleObserver', function (observer) {
{
this.simpleObservers.remove$O(observer);
}});

Clazz.newMeth(C$, 'addObserver$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1', function (observer) {
{
this.newValueObservers.add$TE(observer);
}observer.$apply$TT(this.get());
});

Clazz.newMeth(C$, 'removeObserver$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1', function (observer) {
{
this.newValueObservers.remove$O(observer);
}});

Clazz.newMeth(C$, 'notifyNewAndOldValueObservers$TT$TT', function (newValue, oldValue) {
var copy;
{
copy = Clazz.new_((I$[1]||$incl$(1)).c$$java_util_Collection,[this.newAndOldValueObservers]);
}for (var observer, $observer = copy.iterator(); $observer.hasNext()&&((observer=$observer.next()),1);) {
observer.update$TT$TT(newValue, oldValue);
}
});

Clazz.newMeth(C$, 'addObserver$edu_colorado_phet_common_phetcommon_model_property_ChangeObserver', function (observer) {
{
this.newAndOldValueObservers.add$TE(observer);
}});

Clazz.newMeth(C$, 'removeObserver$edu_colorado_phet_common_phetcommon_model_property_ChangeObserver', function (observer) {
{
this.newAndOldValueObservers.remove$O(observer);
}});

Clazz.newMeth(C$, 'addObserver$edu_colorado_phet_common_phetcommon_util_SimpleObserver', function (simpleObserver) {
this.addObserver$edu_colorado_phet_common_phetcommon_util_SimpleObserver$Z(simpleObserver, true);
});

Clazz.newMeth(C$, 'toString', function () {
return this.get().toString();
});

Clazz.newMeth(C$, 'trace$S', function (text) {
});

Clazz.newMeth(C$, 'main', function (args) {
var p = Clazz.new_((I$[2]||$incl$(2)).c$$TT,["hello"]);
p.trace$S("text");
p.set$TT("world");
}, 1);

Clazz.newMeth(C$, 'getChangeNotifier', function () {
var newValue = this.get();
var changed = newValue == null  ? this.oldValue != null  : !newValue.equals$O(this.oldValue);
var oldNotifyValue = this.oldValue;
var notifier = ((
(function(){var C$=Clazz.newClass(P$, "ObservableProperty$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'run', function () {
if (this.$finals.changed) {
this.b$['edu.colorado.phet.common.phetcommon.model.property.ObservableProperty'].notifyObservers$TT$TT.apply(this.b$['edu.colorado.phet.common.phetcommon.model.property.ObservableProperty'], [this.$finals.newValue, this.$finals.oldNotifyValue]);
}});
})()
), Clazz.new_((I$[3]||$incl$(3)).$init$, [this, {changed: changed, newValue: newValue, oldNotifyValue: oldNotifyValue}]));
if (changed) {
this.oldValue = newValue;
}return notifier;
});

Clazz.newMeth(C$, 'notifyIfChanged', function () {
this.getChangeNotifier().run();
});

Clazz.newMeth(C$, 'removeAllObservers', function () {
{
this.simpleObservers.clear();
}{
this.newValueObservers.clear();
}{
this.newAndOldValueObservers.clear();
}});

Clazz.newMeth(C$, 'valueEquals$TT', function (value) {
return Clazz.new_((I$[4]||$incl$(4)).c$$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty$TT,[this, value]);
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:48
