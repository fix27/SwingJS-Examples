(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.util"),I$=[['java.io.File','java.util.Properties','java.io.BufferedInputStream','java.io.FileInputStream','java.io.FileOutputStream']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "AbstractPropertiesFile");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.file = null;
this.properties = null;
this.header = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (filename) {
C$.c$$java_io_File.apply(this, [Clazz.new_((I$[1]||$incl$(1)).c$$S,[filename])]);
}, 1);

Clazz.newMeth(C$, 'c$$java_io_File', function (file) {
C$.$init$.apply(this);
this.file = file;
this.header = null;
this.properties = C$.load$java_io_File(file);
}, 1);

Clazz.newMeth(C$, 'load$java_io_File', function (file) {
var properties = Clazz.new_((I$[2]||$incl$(2)));
if (file.exists()) {
try {
var stream = Clazz.new_((I$[3]||$incl$(3)).c$$java_io_InputStream,[Clazz.new_((I$[4]||$incl$(4)).c$$java_io_File,[file])]);
properties.load$java_io_InputStream(stream);
stream.close();
} catch (e$$) {
if (Clazz.exceptionOf(e$$, "java.io.IOException")){
var e = e$$;
{
e.printStackTrace();
}
} else if (Clazz.exceptionOf(e$$, "java.security.AccessControlException")){
var e = e$$;
{
System.err.println$S(Clazz.getClass(C$).getName() + " access denied to file " + file.getAbsolutePath() );
}
} else {
throw e$$;
}
}
}return properties;
}, 1);

Clazz.newMeth(C$, 'store', function () {
try {
var parent = this.file.getParentFile();
if (!parent.exists()) {
parent.mkdirs();
}var stream = Clazz.new_((I$[5]||$incl$(5)).c$$java_io_File,[this.file]);
this.properties.store$java_io_OutputStream$S(stream, this.header);
stream.close();
} catch (e$$) {
if (Clazz.exceptionOf(e$$, "java.io.IOException")){
var e = e$$;
{
e.printStackTrace();
}
} else if (Clazz.exceptionOf(e$$, "java.security.AccessControlException")){
var e = e$$;
{
System.err.println$S(this.getClass().getName() + " access denied to file " + this.file.getAbsolutePath() );
}
} else {
throw e$$;
}
}
});

Clazz.newMeth(C$, 'setHeader$S', function (header) {
this.header = header;
});

Clazz.newMeth(C$, 'exists', function () {
return this.file.exists();
});

Clazz.newMeth(C$, 'getPropertyNames', function () {
return this.properties.propertyNames();
});

Clazz.newMeth(C$, 'setProperty$S$S', function (key, value) {
this.properties.setProperty$S$S(key, value);
p$.store.apply(this, []);
});

Clazz.newMeth(C$, 'setProperty$S$I', function (key, value) {
this.setProperty$S$S(key, String.valueOf(value));
});

Clazz.newMeth(C$, 'setProperty$S$J', function (key, value) {
this.setProperty$S$S(key, String.valueOf(value));
});

Clazz.newMeth(C$, 'getProperty$S', function (key) {
return this.properties.getProperty$S(key);
});

Clazz.newMeth(C$, 'getPropertyInt$S$I', function (key, defaultValue) {
var value = defaultValue;
var s = this.getProperty$S(key);
if (s != null ) {
try {
value = Integer.parseInt(s);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.NumberFormatException")){
System.err.println$S("PropertiesFile.getPropertyInt: " + key + " is not an integer in file " + this.file.getAbsolutePath() );
} else {
throw e;
}
}
}return value;
});

Clazz.newMeth(C$, 'getPropertyLong$S$J', function (key, defaultValue) {
var value = defaultValue;
var s = this.getProperty$S(key);
if (s != null ) {
try {
value = Long.parseLong(s);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.NumberFormatException")){
System.err.println$S("PropertiesFile.getPropertyInt: " + key + " is not a long in file " + this.file.getAbsolutePath() );
} else {
throw e;
}
}
}return value;
});

Clazz.newMeth(C$, 'toString', function () {
return this.properties.toString();
});

Clazz.newMeth(C$, '$delete', function () {
this.properties.clear();
return this.file.$delete();
});

Clazz.newMeth(C$, 'deleteOnExit', function () {
this.file.deleteOnExit();
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:51
