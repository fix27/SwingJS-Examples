(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.messages"),I$=[];
var C$=Clazz.newClass(P$, "SystemComponents", null, 'Enum', 'edu.colorado.phet.common.phetcommon.simsharing.messages.ISystemComponent');

C$.$clinit$ = function() {Clazz.load(C$, 1);
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "simsharingManager", 0, []);
Clazz.newEnumConst($vals, C$.c$, "application", 1, []);
Clazz.newEnumConst($vals, C$.c$, "phetFrame", 2, []);
Clazz.newEnumConst($vals, C$.c$, "sponsorDialog", 3, []);
Clazz.newEnumConst($vals, C$.c$, "askDialog", 4, []);
Clazz.newEnumConst($vals, C$.c$, "resetAllConfirmationDialog", 5, []);
Clazz.newEnumConst($vals, C$.c$, "loadTester", 6, []);
Clazz.newEnumConst($vals, C$.c$, "invalidValueDialog", 7, []);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values', function() { return $vals }, 1);
})();
//Created 2018-01-31 11:02:51
