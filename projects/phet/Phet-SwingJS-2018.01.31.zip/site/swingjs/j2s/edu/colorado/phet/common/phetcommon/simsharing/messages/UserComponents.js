(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.messages"),I$=[];
var C$=Clazz.newClass(P$, "UserComponents", null, 'Enum', 'edu.colorado.phet.common.phetcommon.simsharing.messages.IUserComponent');

C$.$clinit$ = function() {Clazz.load(C$, 1);
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "playPauseButton", 0, []);
Clazz.newEnumConst($vals, C$.c$, "tab", 1, []);
Clazz.newEnumConst($vals, C$.c$, "stepButton", 2, []);
Clazz.newEnumConst($vals, C$.c$, "stepBackButton", 3, []);
Clazz.newEnumConst($vals, C$.c$, "rewindButton", 4, []);
Clazz.newEnumConst($vals, C$.c$, "sponsorDialog", 5, []);
Clazz.newEnumConst($vals, C$.c$, "askDialog", 6, []);
Clazz.newEnumConst($vals, C$.c$, "dataCollectionLogMenuItem", 7, []);
Clazz.newEnumConst($vals, C$.c$, "resetAllConfirmationDialogYesButton", 8, []);
Clazz.newEnumConst($vals, C$.c$, "resetAllConfirmationDialogNoButton", 9, []);
Clazz.newEnumConst($vals, C$.c$, "nextButton", 10, []);
Clazz.newEnumConst($vals, C$.c$, "previousButton", 11, []);
Clazz.newEnumConst($vals, C$.c$, "showLogs", 12, []);
Clazz.newEnumConst($vals, C$.c$, "simSharingLogFileDialog", 13, []);
Clazz.newEnumConst($vals, C$.c$, "fileChooserCancelButton", 14, []);
Clazz.newEnumConst($vals, C$.c$, "fileChooserSaveButton", 15, []);
Clazz.newEnumConst($vals, C$.c$, "replaceFileNoButton", 16, []);
Clazz.newEnumConst($vals, C$.c$, "replaceFileYesButton", 17, []);
Clazz.newEnumConst($vals, C$.c$, "saveButton", 18, []);
Clazz.newEnumConst($vals, C$.c$, "phetFrame", 19, []);
Clazz.newEnumConst($vals, C$.c$, "fileMenu", 20, []);
Clazz.newEnumConst($vals, C$.c$, "exitMenuItem", 21, []);
Clazz.newEnumConst($vals, C$.c$, "helpMenu", 22, []);
Clazz.newEnumConst($vals, C$.c$, "helpMenuItem", 23, []);
Clazz.newEnumConst($vals, C$.c$, "megaHelpMenuItem", 24, []);
Clazz.newEnumConst($vals, C$.c$, "aboutMenuItem", 25, []);
Clazz.newEnumConst($vals, C$.c$, "checkForSimulationUpdateMenuItem", 26, []);
Clazz.newEnumConst($vals, C$.c$, "saveMenuItem", 27, []);
Clazz.newEnumConst($vals, C$.c$, "loadMenuItem", 28, []);
Clazz.newEnumConst($vals, C$.c$, "preferencesMenuItem", 29, []);
Clazz.newEnumConst($vals, C$.c$, "optionsMenu", 30, []);
Clazz.newEnumConst($vals, C$.c$, "teacherMenu", 31, []);
Clazz.newEnumConst($vals, C$.c$, "resetAllButton", 32, []);
Clazz.newEnumConst($vals, C$.c$, "faucetImage", 33, []);
Clazz.newEnumConst($vals, C$.c$, "slider", 34, []);
Clazz.newEnumConst($vals, C$.c$, "spinner", 35, []);
Clazz.newEnumConst($vals, C$.c$, "onRadioButton", 36, []);
Clazz.newEnumConst($vals, C$.c$, "offRadioButton", 37, []);
Clazz.newEnumConst($vals, C$.c$, "conductivityTester", 38, []);
Clazz.newEnumConst($vals, C$.c$, "positiveProbe", 39, []);
Clazz.newEnumConst($vals, C$.c$, "negativeProbe", 40, []);
Clazz.newEnumConst($vals, C$.c$, "heaterCoolerSlider", 41, []);
Clazz.newEnumConst($vals, C$.c$, "aboutDialogCloseButton", 42, []);
Clazz.newEnumConst($vals, C$.c$, "aboutDialogCreditsButton", 43, []);
Clazz.newEnumConst($vals, C$.c$, "aboutDialogSoftwareAgreementButton", 44, []);
Clazz.newEnumConst($vals, C$.c$, "icon", 45, []);
Clazz.newEnumConst($vals, C$.c$, "helpButton", 46, []);
Clazz.newEnumConst($vals, C$.c$, "hideHelpButton", 47, []);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values', function() { return $vals }, 1);
})();
//Created 2018-01-31 11:02:51
