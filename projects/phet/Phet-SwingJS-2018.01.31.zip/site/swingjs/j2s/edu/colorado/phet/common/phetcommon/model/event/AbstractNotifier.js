(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.event"),I$=[['java.util.LinkedList','java.util.ArrayList']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "AbstractNotifier");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.listeners = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.listeners = Clazz.new_((I$[1]||$incl$(1)));
}, 1);

Clazz.newMeth(C$, 'addListener$TT', function (listener) {
this.listeners.add$TE(listener);
});

Clazz.newMeth(C$, 'removeListener$TT', function (listener) {
this.listeners.remove$O(listener);
});

Clazz.newMeth(C$, 'updateListeners$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1', function (callback) {
for (var listener, $listener = Clazz.new_((I$[2]||$incl$(2)).c$$java_util_Collection,[this.listeners]).iterator(); $listener.hasNext()&&((listener=$listener.next()),1);) {
callback.$apply$TT(listener);
}
});

Clazz.newMeth(C$, 'getListeners', function () {
return Clazz.new_((I$[1]||$incl$(1)).c$$java_util_Collection,[this.listeners]);
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:48
