(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.event"),I$=[];
var C$=Clazz.newClass(P$, "UpdateListener", null, null, ['edu.colorado.phet.common.phetcommon.util.SimpleObserver', 'edu.colorado.phet.common.phetcommon.util.function.VoidFunction1']);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['$apply$O','$apply$TT'], function (o) {
this.update();
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:48
