(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math.vector"),I$=[['edu.colorado.phet.common.phetcommon.math.vector.Vector2D']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "MutableVector2D", null, 'edu.colorado.phet.common.phetcommon.math.vector.AbstractVector2D');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x = 0;
this.y = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'hashCode', function () {
return Float.floatToIntBits(this.x) ^ Float.floatToIntBits(this.y);
});

Clazz.newMeth(C$, 'equals$O', function (o) {
if (!(Clazz.instanceOf(o, "edu.colorado.phet.common.phetcommon.math.vector.MutableVector2D"))) {
return false;
}var m = o;
return (m.x == this.x  && m.y == this.y  );
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D', function (v) {
C$.c$$D$D.apply(this, [v.getX(), v.getY()]);
}, 1);

Clazz.newMeth(C$, 'c$$D$D', function (x, y) {
Clazz.super_(C$, this,1);
this.x = x;
this.y = y;
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_geom_Point2D', function (p) {
C$.c$$D$D.apply(this, [p.getX(), p.getY()]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_geom_Point2D$java_awt_geom_Point2D', function (src, dst) {
Clazz.super_(C$, this,1);
this.x = dst.getX() - src.getX();
this.y = dst.getY() - src.getY();
}, 1);

Clazz.newMeth(C$, 'add$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D', function (v) {
this.x += v.getX();
this.y += v.getY();
return this;
});

Clazz.newMeth(C$, 'normalize', function () {
var magnitude = this.magnitude();
if (magnitude == 0 ) {
throw Clazz.new_(Clazz.load('java.lang.UnsupportedOperationException').c$$S,["Cannot normalize a zero-magnitude vector."]);
}return this.scale$D(1.0 / magnitude);
});

Clazz.newMeth(C$, 'scale$D', function (scale) {
this.x *= scale;
this.y *= scale;
return this;
});

Clazz.newMeth(C$, 'setX$D', function (x) {
this.x = x;
});

Clazz.newMeth(C$, 'setY$D', function (y) {
this.y = y;
});

Clazz.newMeth(C$, 'setComponents$D$D', function (x, y) {
this.x = x;
this.y = y;
});

Clazz.newMeth(C$, 'setValue$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D', function (value) {
this.setComponents$D$D(value.getX(), value.getY());
});

Clazz.newMeth(C$, 'setMagnitudeAndAngle$D$D', function (magnitude, angle) {
this.setComponents$D$D(Math.cos(angle) * magnitude, Math.sin(angle) * magnitude);
});

Clazz.newMeth(C$, 'setMagnitude$D', function (magnitude) {
this.setMagnitudeAndAngle$D$D(magnitude, this.getAngle());
});

Clazz.newMeth(C$, 'setAngle$D', function (angle) {
this.setMagnitudeAndAngle$D$D(this.magnitude(), angle);
});

Clazz.newMeth(C$, 'subtract$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D', function (v) {
this.x -= v.getX();
this.y -= v.getY();
return this;
});

Clazz.newMeth(C$, 'rotate$D', function (theta) {
var r = this.magnitude();
var alpha = this.getAngle();
var gamma = alpha + theta;
var xPrime = r * Math.cos(gamma);
var yPrime = r * Math.sin(gamma);
this.setComponents$D$D(xPrime, yPrime);
return this;
});

Clazz.newMeth(C$, 'negate', function () {
this.setComponents$D$D(-this.getX(), -this.getY());
return this;
});

Clazz.newMeth(C$, 'getY', function () {
return this.y;
});

Clazz.newMeth(C$, 'getX', function () {
return this.x;
});

Clazz.newMeth(C$, 'addXY$D$D', function (x, y) {
this.x += x;
this.y += y;
});

Clazz.newMeth(C$, 'createPolar$D$D', function (magnitude, angle) {
return (I$[1]||$incl$(1)).createPolar$D$D(magnitude, angle);
}, 1);

Clazz.newMeth(C$, 'main', function (args) {
var v = Clazz.new_(C$.c$$D$D,[0, 0]);
System.out.println$S("v = " + v);
System.out.println$S("v.hashCode() = " + v.hashCode());
var b = Clazz.new_(C$.c$$D$D,[1, 2]);
var c = Clazz.new_(C$.c$$D$D,[0, 0]);
System.out.println$S("v.equals( b ) = " + v.equals$O(b) + " (should be false)" );
System.out.println$S("v.equals( c ) = " + v.equals$O(c) + " (should be true)" );
}, 1);
})();
//Created 2018-01-31 11:02:47
