(function(){var P$=Clazz.newPackage("edu.colorado.phet.assets"),I$=[];
var C$=Clazz.newClass(P$, "Assets");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'main', function (args) {
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:43
