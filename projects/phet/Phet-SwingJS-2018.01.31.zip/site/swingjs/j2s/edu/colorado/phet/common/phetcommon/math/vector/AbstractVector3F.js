(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math.vector"),I$=[['edu.colorado.phet.common.phetcommon.math.vector.Vector3F','edu.colorado.phet.common.phetcommon.math.MathUtil','edu.colorado.phet.common.phetcommon.math.vector.Vector3D']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "AbstractVector3F", null, null, 'java.io.Serializable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'magnitude', function () {
return Math.sqrt(this.magnitudeSquared());
});

Clazz.newMeth(C$, 'magnitudeSquared', function () {
return this.getX() * this.getX() + this.getY() * this.getY() + this.getZ() * this.getZ();
});

Clazz.newMeth(C$, 'dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F', function (v) {
return this.getX() * v.getX() + this.getY() * v.getY() + this.getZ() * v.getZ();
});

Clazz.newMeth(C$, 'distance$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F', function (v) {
var dx = this.getX() - v.getX();
var dy = this.getY() - v.getY();
var dz = this.getZ() - v.getZ();
return Math.sqrt(dx * dx + dy * dy + dz * dz);
});

Clazz.newMeth(C$, 'cross$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F', function (v) {
return Clazz.new_((I$[1]||$incl$(1)).c$$F$F$F,[this.getY() * v.getZ() - this.getZ() * v.getY(), this.getZ() * v.getX() - this.getX() * v.getZ(), this.getX() * v.getY() - this.getY() * v.getX()]);
});

Clazz.newMeth(C$, 'angleBetween$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F', function (v) {
return Math.acos((I$[2]||$incl$(2)).clamp$D$D$D(-1, this.normalized().dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(v.normalized()), 1));
});

Clazz.newMeth(C$, 'angleBetweenInDegrees$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F', function (v) {
return (this.angleBetween$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(v) * 180 / 3.141592653589793);
});

Clazz.newMeth(C$, 'normalized', function () {
var magnitude = this.magnitude();
if (magnitude == 0 ) {
throw Clazz.new_(Clazz.load('java.lang.UnsupportedOperationException').c$$S,["Cannot normalize a zero-magnitude vector."]);
}return Clazz.new_((I$[1]||$incl$(1)).c$$F$F$F,[this.getX() / magnitude, this.getY() / magnitude, this.getZ() / magnitude]);
});

Clazz.newMeth(C$, 'getInstanceOfMagnitude$F', function (magnitude) {
return this.times$F(magnitude / this.magnitude());
});

Clazz.newMeth(C$, 'times$F', function (scalar) {
return Clazz.new_((I$[1]||$incl$(1)).c$$F$F$F,[this.getX() * scalar, this.getY() * scalar, this.getZ() * scalar]);
});

Clazz.newMeth(C$, 'componentTimes$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F', function (v) {
return Clazz.new_((I$[1]||$incl$(1)).c$$F$F$F,[this.getX() * v.getX(), this.getY() * v.getY(), this.getZ() * v.getZ()]);
});

Clazz.newMeth(C$, 'plus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F', function (v) {
return Clazz.new_((I$[1]||$incl$(1)).c$$F$F$F,[this.getX() + v.getX(), this.getY() + v.getY(), this.getZ() + v.getZ()]);
});

Clazz.newMeth(C$, 'plus$F$F$F', function (x, y, z) {
return Clazz.new_((I$[1]||$incl$(1)).c$$F$F$F,[this.getX() + x, this.getY() + y, this.getZ() + z]);
});

Clazz.newMeth(C$, 'minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F', function (v) {
return Clazz.new_((I$[1]||$incl$(1)).c$$F$F$F,[this.getX() - v.getX(), this.getY() - v.getY(), this.getZ() - v.getZ()]);
});

Clazz.newMeth(C$, 'minus$F$F$F', function (x, y, z) {
return Clazz.new_((I$[1]||$incl$(1)).c$$F$F$F,[this.getX() - x, this.getY() - y, this.getZ() - z]);
});

Clazz.newMeth(C$, 'negated', function () {
return Clazz.new_((I$[1]||$incl$(1)).c$$F$F$F,[-this.getX(), -this.getY(), -this.getZ()]);
});

Clazz.newMeth(C$, 'to3D', function () {
return Clazz.new_((I$[3]||$incl$(3)).c$$D$D$D,[this.getX(), this.getY(), this.getZ()]);
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:46
