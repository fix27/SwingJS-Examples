(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math.vector"),I$=[[['java.awt.geom.Line2D','.Double']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Vector2D", null, 'edu.colorado.phet.common.phetcommon.math.vector.AbstractVector2D');
C$.ZERO = null;
C$.X_UNIT = null;
C$.Y_UNIT = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.ZERO = Clazz.new_(C$);
C$.X_UNIT = Clazz.new_(C$.c$$D$D,[1, 0]);
C$.Y_UNIT = Clazz.new_(C$.c$$D$D,[0, 1]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x = 0;
this.y = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'hashCode', function () {
return Float.floatToIntBits(this.x) ^ Float.floatToIntBits(this.y);
});

Clazz.newMeth(C$, 'equals$O', function (o) {
if (!(Clazz.instanceOf(o, "edu.colorado.phet.common.phetcommon.math.vector.Vector2D"))) {
return false;
}var m = o;
return (m.x == this.x  && m.y == this.y  );
});

Clazz.newMeth(C$, 'c$', function () {
C$.c$$D$D.apply(this, [0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$D$D', function (x, y) {
Clazz.super_(C$, this,1);
this.x = x;
this.y = y;
}, 1);

Clazz.newMeth(C$, 'distance2p$java_awt_geom_Point2D', function (pt) {
var a;
var b;
return (a = pt.getX() - this.x) * a + (b = pt.getY() - this.y) * b;
});

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D', function (v) {
C$.c$$D$D.apply(this, [v.getX(), v.getY()]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_geom_Point2D', function (p) {
C$.c$$D$D.apply(this, [p.getX(), p.getY()]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_geom_Point2D$java_awt_geom_Point2D', function (initialPt, finalPt) {
C$.c$$D$D.apply(this, [finalPt.getX() - initialPt.getX(), finalPt.getY() - initialPt.getY()]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_Vector2D$edu_colorado_phet_common_phetcommon_math_vector_Vector2D', function (initialPt, finalPt) {
C$.c$$D$D.apply(this, [finalPt.getX() - initialPt.getX(), finalPt.getY() - initialPt.getY()]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_geom_Dimension2D', function (v) {
C$.c$$D$D.apply(this, [v.getWidth(), v.getHeight()]);
}, 1);

Clazz.newMeth(C$, 'getY', function () {
return this.y;
});

Clazz.newMeth(C$, 'getX', function () {
return this.x;
});

Clazz.newMeth(C$, 'createPolar$D$D', function (radius, angle) {
return Clazz.new_(C$.c$$D$D,[Math.cos(angle), Math.sin(angle)]).times$D(radius);
}, 1);

Clazz.newMeth(C$, 'v$D$D', function (x, y) {
return Clazz.new_(C$.c$$D$D,[x, y]);
}, 1);

Clazz.newMeth(C$, 'lineTo$D$D', function (x, y) {
return Clazz.new_((I$[1]||$incl$(1)).c$$D$D$D$D,[this.x, this.y, x, y]);
});

Clazz.newMeth(C$, 'lineTo$edu_colorado_phet_common_phetcommon_math_vector_Vector2D', function (end) {
return this.lineTo$D$D(end.x, end.y);
});

Clazz.newMeth(C$, 'main', function (args) {
var v = Clazz.new_(C$.c$$D$D,[0, 0]);
System.out.println$S("v = " + v);
System.out.println$S("v.hashCode() = " + v.hashCode());
var b = Clazz.new_(C$.c$$D$D,[1, 2]);
var c = Clazz.new_(C$.c$$D$D,[0, 0]);
System.out.println$S("v.equals( b ) = " + v.equals$O(b) + " (should be false)" );
System.out.println$S("v.equals( c ) = " + v.equals$O(c) + " (should be true)" );
System.out.println$S("2root2= " + new Double(Clazz.new_(C$.c$$D$D,[0, 0]).distance$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D(Clazz.new_(C$.c$$D$D,[1, 1]))).toString());
}, 1);
})();
//Created 2018-01-31 11:02:47
