(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.logs"),I$=[];
var C$=Clazz.newClass(P$, "MongoLog");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:50
