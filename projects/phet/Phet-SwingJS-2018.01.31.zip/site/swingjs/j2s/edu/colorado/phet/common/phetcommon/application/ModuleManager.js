(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.application"),I$=[['java.util.ArrayList','edu.colorado.phet.common.phetcommon.application.ModuleEvent','edu.colorado.phet.common.phetcommon.application.Module']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ModuleManager");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.modules = null;
this.activeModule = null;
this.phetApplication = null;
this.moduleObservers = null;
this.startModule = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.modules = Clazz.new_((I$[1]||$incl$(1)));
this.moduleObservers = Clazz.new_((I$[1]||$incl$(1)));
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_application_PhetApplication', function (phetApplication) {
C$.$init$.apply(this);
this.phetApplication = phetApplication;
this.startModule = null;
}, 1);

Clazz.newMeth(C$, 'moduleAt$I', function (i) {
return this.modules.get$I(i);
});

Clazz.newMeth(C$, 'getActiveModule', function () {
return this.activeModule;
});

Clazz.newMeth(C$, 'numModules', function () {
return this.modules.size();
});

Clazz.newMeth(C$, 'addModule$edu_colorado_phet_common_phetcommon_application_Module', function (module) {
if (this.modules.size() == 0) {
this.startModule = module;
}this.modules.add$TE(module);
p$.notifyModuleAdded$edu_colorado_phet_common_phetcommon_application_ModuleEvent.apply(this, [Clazz.new_((I$[2]||$incl$(2)).c$$edu_colorado_phet_common_phetcommon_application_PhetApplication$edu_colorado_phet_common_phetcommon_application_Module,[p$.getPhetApplication.apply(this, []), module])]);
});

Clazz.newMeth(C$, 'removeModule$edu_colorado_phet_common_phetcommon_application_Module', function (module) {
this.modules.remove$O(module);
if (module === this.startModule ) {
this.startModule = null;
if (this.modules.size() > 0) {
this.startModule = this.moduleAt$I(0);
}}if (this.getActiveModule() === module ) {
this.setActiveModule$edu_colorado_phet_common_phetcommon_application_Module(this.modules.size() == 0 ? null : this.modules.get$I(0));
}p$.notifyModuleRemoved$edu_colorado_phet_common_phetcommon_application_ModuleEvent.apply(this, [Clazz.new_((I$[2]||$incl$(2)).c$$edu_colorado_phet_common_phetcommon_application_PhetApplication$edu_colorado_phet_common_phetcommon_application_Module,[p$.getPhetApplication.apply(this, []), module])]);
});

Clazz.newMeth(C$, 'indexOf$edu_colorado_phet_common_phetcommon_application_Module', function (m) {
return this.modules.indexOf$O(m);
});

Clazz.newMeth(C$, 'setModules$edu_colorado_phet_common_phetcommon_application_ModuleA', function (modules) {
while (this.numModules() > 0){
var module = this.moduleAt$I(0);
this.removeModule$edu_colorado_phet_common_phetcommon_application_Module(module);
}
this.addAllModules$edu_colorado_phet_common_phetcommon_application_ModuleA(modules);
});

Clazz.newMeth(C$, 'addAllModules$edu_colorado_phet_common_phetcommon_application_ModuleA', function (modules) {
for (var i = 0; i < modules.length; i++) {
this.addModule$edu_colorado_phet_common_phetcommon_application_Module(modules[i]);
}
});

Clazz.newMeth(C$, 'getModules', function () {
var moduleArray = Clazz.array((I$[3]||$incl$(3)), [this.modules.size()]);
for (var i = 0; i < this.modules.size(); i++) {
moduleArray[i] = this.modules.get$I(i);
}
return moduleArray;
});

Clazz.newMeth(C$, 'setActiveModule$I', function (i) {
this.setActiveModule$edu_colorado_phet_common_phetcommon_application_Module(this.moduleAt$I(i));
});

Clazz.newMeth(C$, 'setActiveModule$edu_colorado_phet_common_phetcommon_application_Module', function (module) {
if (module == null ) {
throw Clazz.new_(Clazz.load('java.lang.RuntimeException').c$$S,["Active module can\'t be null."]);
}if (this.activeModule !== module ) {
this.deactivateCurrentModule();
p$.activate$edu_colorado_phet_common_phetcommon_application_Module.apply(this, [module]);
p$.notifyActiveModuleChanged$edu_colorado_phet_common_phetcommon_application_ModuleEvent.apply(this, [Clazz.new_((I$[2]||$incl$(2)).c$$edu_colorado_phet_common_phetcommon_application_PhetApplication$edu_colorado_phet_common_phetcommon_application_Module,[p$.getPhetApplication.apply(this, []), module])]);
p$.verifyActiveState.apply(this, []);
}});

Clazz.newMeth(C$, 'verifyActiveState', function () {
var numActiveModules = p$.getNumActiveModules.apply(this, []);
var numClocksRunning = p$.getNumClocksRunning.apply(this, []);
var clockShared = p$.isClockShared.apply(this, []);
if (numActiveModules != 1) {
Clazz.new_(Clazz.load('java.lang.IllegalStateException').c$$S,["multiple modules are running: active modules=" + numActiveModules]).printStackTrace();
}if (numClocksRunning > 1) {
var runningModules = Clazz.new_((I$[1]||$incl$(1)));
for (var module, $module = this.modules.iterator(); $module.hasNext()&&((module=$module.next()),1);) {
if (module.getClock().isRunning()) {
runningModules.add$TE(module.getName());
}}
Clazz.new_(Clazz.load('java.lang.IllegalStateException').c$$S,["multiple clocks are running: running clocks=" + numClocksRunning + ", in modules " + runningModules ]).printStackTrace();
}if (numClocksRunning == 1 && !this.activeModule.getClock().isRunning() ) {
Clazz.new_(Clazz.load('java.lang.IllegalStateException').c$$S,["a clock is running that does not belong to the active module"]).printStackTrace();
}if (clockShared) {
Clazz.new_(Clazz.load('java.lang.IllegalStateException').c$$S,["Multiple modules are using the same clock instance."]).printStackTrace();
}});

Clazz.newMeth(C$, 'isClockShared', function () {
for (var i = 0; i < this.modules.size(); i++) {
for (var k = 0; k < this.modules.size(); k++) {
if (k != i) {
var clock1 = this.modules.get$I(i).getClock();
var clock2 = this.modules.get$I(k).getClock();
if (clock1 === clock2 ) {
return true;
}}}
}
return false;
});

Clazz.newMeth(C$, 'getNumActiveModules', function () {
var count = 0;
for (var i = 0; i < this.modules.size(); i++) {
if (this.modules.get$I(i).isActive()) {
count++;
}}
return count;
});

Clazz.newMeth(C$, 'getNumClocksRunning', function () {
var runningClocks = Clazz.new_((I$[1]||$incl$(1)));
for (var i = 0; i < this.modules.size(); i++) {
var clock = this.modules.get$I(i).getClock();
if (clock.isRunning()) {
if (!runningClocks.contains$O(clock)) {
runningClocks.add$TE(clock);
}}}
return runningClocks.size();
});

Clazz.newMeth(C$, 'addModuleObserver$edu_colorado_phet_common_phetcommon_application_ModuleObserver', function (observer) {
this.moduleObservers.add$TE(observer);
});

Clazz.newMeth(C$, 'getPhetApplication', function () {
return this.phetApplication;
});

Clazz.newMeth(C$, 'activate$edu_colorado_phet_common_phetcommon_application_Module', function (module) {
this.activeModule = module;
if (module != null ) {
module.activate();
this.setActiveModule$edu_colorado_phet_common_phetcommon_application_Module(module);
}});

Clazz.newMeth(C$, 'deactivateCurrentModule', function () {
if (this.activeModule != null ) {
this.activeModule.deactivate();
}});

Clazz.newMeth(C$, 'notifyModuleAdded$edu_colorado_phet_common_phetcommon_application_ModuleEvent', function (event) {
for (var i = 0; i < this.moduleObservers.size(); i++) {
var moduleObserver = this.moduleObservers.get$I(i);
moduleObserver.moduleAdded$edu_colorado_phet_common_phetcommon_application_ModuleEvent(event);
}
});

Clazz.newMeth(C$, 'notifyActiveModuleChanged$edu_colorado_phet_common_phetcommon_application_ModuleEvent', function (event) {
for (var i = 0; i < this.moduleObservers.size(); i++) {
var moduleObserver = this.moduleObservers.get$I(i);
moduleObserver.activeModuleChanged$edu_colorado_phet_common_phetcommon_application_ModuleEvent(event);
}
});

Clazz.newMeth(C$, 'notifyModuleRemoved$edu_colorado_phet_common_phetcommon_application_ModuleEvent', function (event) {
for (var i = 0; i < this.moduleObservers.size(); i++) {
var moduleObserver = this.moduleObservers.get$I(i);
moduleObserver.moduleRemoved$edu_colorado_phet_common_phetcommon_application_ModuleEvent(event);
}
});

Clazz.newMeth(C$, 'getStartModule', function () {
return this.startModule;
});

Clazz.newMeth(C$, 'setStartModule$edu_colorado_phet_common_phetcommon_application_Module', function (module) {
if (!this.modules.contains$O(module)) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["start module has not been added"]);
}this.startModule = module;
});

Clazz.newMeth(C$, 'removeModuleObserver$edu_colorado_phet_common_phetcommon_application_ModuleObserver', function (moduleObserver) {
this.moduleObservers.remove$O(moduleObserver);
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:44
