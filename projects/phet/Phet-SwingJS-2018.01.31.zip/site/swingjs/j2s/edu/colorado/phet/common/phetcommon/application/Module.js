(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.application"),I$=[['java.util.ArrayList','edu.colorado.phet.common.phetcommon.model.BaseModel','edu.colorado.phet.common.phetcommon.view.ModulePanel','edu.colorado.phet.common.phetcommon.view.LogoPanel','edu.colorado.phet.common.phetcommon.view.HelpPanel','edu.colorado.phet.common.phetcommon.model.clock.ModuleClockAdapter','edu.colorado.phet.common.phetcommon.view.ClockControlPanel','javax.swing.SwingUtilities','edu.colorado.phet.common.phetcommon.application.Module$2','edu.colorado.phet.common.phetcommon.simsharing.messages.UserComponents','javax.swing.text.JTextComponent','edu.colorado.phet.common.phetcommon.view.util.SwingUtils']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Module", function(){
Clazz.newInstance(this, arguments,0,C$);
}, null, 'edu.colorado.phet.common.phetcommon.model.Resettable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.name = null;
this.model = null;
this.clock = null;
this.active = false;
this.clockRunningWhenActive = false;
this.moduleRunner = null;
this.modulePanel = null;
this.listeners = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.active = false;
this.clockRunningWhenActive = true;
this.listeners = Clazz.new_((I$[1]||$incl$(1)));
}, 1);

Clazz.newMeth(C$, 'c$$S$edu_colorado_phet_common_phetcommon_model_clock_IClock', function (name, clock) {
C$.c$$S$edu_colorado_phet_common_phetcommon_model_clock_IClock$Z.apply(this, [name, clock, false]);
}, 1);

Clazz.newMeth(C$, 'c$$S$edu_colorado_phet_common_phetcommon_model_clock_IClock$Z', function (name, clock, startsPaused) {
C$.$init$.apply(this);
this.name = name;
this.clock = clock;
this.setModel$edu_colorado_phet_common_phetcommon_model_BaseModel(Clazz.new_((I$[2]||$incl$(2))));
this.modulePanel = Clazz.new_((I$[3]||$incl$(3)));
this.setClockControlPanel$javax_swing_JComponent(this.createClockControlPanel$edu_colorado_phet_common_phetcommon_model_clock_IClock(clock));
this.setLogoPanel$javax_swing_JComponent(Clazz.new_((I$[4]||$incl$(4))));
this.setHelpPanel$javax_swing_JComponent(Clazz.new_((I$[5]||$incl$(5)).c$$edu_colorado_phet_common_phetcommon_application_Module,[this]));
this.moduleRunner = ((
(function(){var C$=Clazz.newClass(P$, "Module$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('edu.colorado.phet.common.phetcommon.model.clock.ModuleClockAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'clockTicked$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
this.b$['edu.colorado.phet.common.phetcommon.application.Module'].handleClockTick$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(clockEvent);
});
})()
), Clazz.new_((I$[6]||$incl$(6)), [this, null],P$.Module$1));
clock.addClockListener$edu_colorado_phet_common_phetcommon_model_clock_ClockListener(this.moduleRunner);
this.clockRunningWhenActive = !startsPaused;
this.updateHelpPanelVisible();
}, 1);

Clazz.newMeth(C$, 'createClockControlPanel$edu_colorado_phet_common_phetcommon_model_clock_IClock', function (clock) {
return Clazz.new_((I$[7]||$incl$(7)).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[clock]);
});

Clazz.newMeth(C$, 'getClock', function () {
return this.clock;
});

Clazz.newMeth(C$, 'handleClockTick$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (event) {
this.handleUserInput();
this.model.update$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(event);
this.updateGraphics$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(event);
});

Clazz.newMeth(C$, 'setClockRunningWhenActive$Z', function (b) {
this.clockRunningWhenActive = b;
if (this.isActive()) {
if (this.clockRunningWhenActive) {
this.clock.start();
} else {
this.clock.pause();
}}});

Clazz.newMeth(C$, 'getClockRunningWhenActive', function () {
if (this.isActive()) {
this.clockRunningWhenActive = this.clock.isRunning();
}return this.clockRunningWhenActive;
});

Clazz.newMeth(C$, 'setModel$edu_colorado_phet_common_phetcommon_model_BaseModel', function (model) {
this.model = model;
});

Clazz.newMeth(C$, 'getModel', function () {
return this.model;
});

Clazz.newMeth(C$, 'addModelElement$edu_colorado_phet_common_phetcommon_model_ModelElement', function (modelElement) {
this.getModel().addModelElement$edu_colorado_phet_common_phetcommon_model_ModelElement(modelElement);
});

Clazz.newMeth(C$, 'getModulePanel', function () {
return this.modulePanel;
});

Clazz.newMeth(C$, 'setMonitorPanel$javax_swing_JComponent', function (panel) {
this.modulePanel.setMonitorPanel$javax_swing_JComponent(panel);
});

Clazz.newMeth(C$, 'setSimulationPanel$javax_swing_JComponent', function (panel) {
this.modulePanel.setSimulationPanel$javax_swing_JComponent(panel);
if (panel != null ) {
var window = (I$[8]||$incl$(8)).getWindowAncestor$java_awt_Component(panel);
if (window != null ) {
window.invalidate();
window.validate();
window.doLayout();
}}});

Clazz.newMeth(C$, 'getSimulationPanel', function () {
return this.modulePanel.getSimulationPanel();
});

Clazz.newMeth(C$, 'setClockControlPanel$javax_swing_JComponent', function (panel) {
this.modulePanel.setClockControlPanel$javax_swing_JComponent(panel);
});

Clazz.newMeth(C$, 'getClockControlPanel', function () {
return this.modulePanel.getClockControlPanel();
});

Clazz.newMeth(C$, 'setLogoPanel$javax_swing_JComponent', function (panel) {
this.modulePanel.setLogoPanel$javax_swing_JComponent(panel);
});

Clazz.newMeth(C$, 'getLogoPanel', function () {
var logoPanel = null;
var panel = this.modulePanel.getLogoPanel();
if (panel != null  && Clazz.instanceOf(panel, "edu.colorado.phet.common.phetcommon.view.LogoPanel") ) {
logoPanel = panel;
}return logoPanel;
});

Clazz.newMeth(C$, 'setControlPanel$javax_swing_JComponent', function (panel) {
this.modulePanel.setControlPanel$javax_swing_JComponent(panel);
});

Clazz.newMeth(C$, 'getControlPanel', function () {
var controlPanel = null;
var panel = this.modulePanel.getControlPanel();
if (panel != null  && Clazz.instanceOf(panel, "edu.colorado.phet.common.phetcommon.view.ControlPanel") ) {
controlPanel = panel;
}return controlPanel;
});

Clazz.newMeth(C$, 'setHelpPanel$javax_swing_JComponent', function (panel) {
this.modulePanel.setHelpPanel$javax_swing_JComponent(panel);
});

Clazz.newMeth(C$, 'getHelpPanel', function () {
var helpPanel = null;
var panel = this.modulePanel.getHelpPanel();
if (panel != null  && Clazz.instanceOf(panel, "edu.colorado.phet.common.phetcommon.view.HelpPanel") ) {
helpPanel = panel;
}return helpPanel;
});

Clazz.newMeth(C$, 'hasHelp', function () {
return false;
});

Clazz.newMeth(C$, 'hasMegaHelp', function () {
return false;
});

Clazz.newMeth(C$, 'setHelpEnabled$Z', function (enabled) {
var helpPanel = this.getHelpPanel();
if (helpPanel != null ) {
helpPanel.setHelpEnabled$Z(enabled);
}});

Clazz.newMeth(C$, 'isHelpEnabled', function () {
var enabled = false;
var helpPanel = this.getHelpPanel();
if (helpPanel != null ) {
enabled = helpPanel.isHelpEnabled();
}return enabled;
});

Clazz.newMeth(C$, 'showMegaHelp', function () {
});

Clazz.newMeth(C$, 'setLogoPanelVisible$Z', function (visible) {
var logoPanel = this.modulePanel.getLogoPanel();
if (logoPanel != null ) {
logoPanel.setVisible$Z(visible);
}});

Clazz.newMeth(C$, 'isLogoPanelVisible', function () {
var visible = false;
var logoPanel = this.modulePanel.getLogoPanel();
if (logoPanel != null ) {
visible = logoPanel.isVisible();
}return visible;
});

Clazz.newMeth(C$, 'activate', function () {
if (!this.isWellFormed()) {
throw Clazz.new_(Clazz.load('java.lang.RuntimeException').c$$S,["Module missing important data, module=" + this]);
}if (this.clockRunningWhenActive) {
this.clock.start();
}this.updateHelpPanelVisible();
this.active = true;
for (var i = 0; i < this.listeners.size(); i++) {
(this.listeners.get$I(i)).activated();
}
});

Clazz.newMeth(C$, 'updateHelpPanelVisible', function () {
var helpPanel = this.getHelpPanel();
if (helpPanel != null ) {
helpPanel.setVisible$Z(this.hasHelp());
}});

Clazz.newMeth(C$, 'addListener$edu_colorado_phet_common_phetcommon_application_Module_Listener', function (listener) {
this.listeners.add$TE(listener);
});

Clazz.newMeth(C$, 'removeListener$edu_colorado_phet_common_phetcommon_application_Module_Listener', function (listener) {
this.listeners.remove$O(listener);
});

Clazz.newMeth(C$, 'addRepaintOnActivateBehavior', function () {
this.addListener$edu_colorado_phet_common_phetcommon_application_Module_Listener(((
(function(){var C$=Clazz.newClass(P$, "Module$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, [['edu.colorado.phet.common.phetcommon.application.Module','edu.colorado.phet.common.phetcommon.application.Module.Listener']], 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'activated', function () {
this.b$['edu.colorado.phet.common.phetcommon.application.Module'].getModulePanel().paintImmediately$I$I$I$I(0, 0, this.b$['edu.colorado.phet.common.phetcommon.application.Module'].getModulePanel().getWidth(), this.b$['edu.colorado.phet.common.phetcommon.application.Module'].getModulePanel().getHeight());
});

Clazz.newMeth(C$, 'deactivated', function () {
});
})()
), Clazz.new_((I$[9]||$incl$(9)).$init$, [this, null])));
});

Clazz.newMeth(C$, 'getTabUserComponent', function () {
return (I$[10]||$incl$(10)).tab;
});

Clazz.newMeth(C$, 'deactivate', function () {
this.clockRunningWhenActive = this.getClock().isRunning();
this.clock.pause();
this.active = false;
for (var i = 0; i < this.listeners.size(); i++) {
(this.listeners.get$I(i)).deactivated();
}
});

Clazz.newMeth(C$, 'isActive', function () {
return this.active;
});

Clazz.newMeth(C$, 'isWellFormed', function () {
var result = true;
result = (result&& (this.getModel() != null ));
result = (result&& (this.getSimulationPanel() != null ));
return result;
});

Clazz.newMeth(C$, 'setName$S', function (name) {
this.name = name;
});

Clazz.newMeth(C$, 'getName', function () {
return this.name;
});

Clazz.newMeth(C$, 'toString', function () {
return "name=" + this.name + ", model=" + this.model + ", simulationPanel=" + this.getSimulationPanel() ;
});

Clazz.newMeth(C$, 'setReferenceSize', function () {
});

Clazz.newMeth(C$, 'handleUserInput', function () {
});

Clazz.newMeth(C$, 'updateGraphics$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (event) {
});

Clazz.newMeth(C$, 'setControlPanelBackground$java_awt_Color', function (color) {
if (this.getControlPanel() != null ) {
var excludedClasses = Clazz.array(java.lang.Class, -1, [Clazz.getClass((I$[11]||$incl$(11)))]);
this.setControlPanelBackground$java_awt_Color$ClassA(color, excludedClasses);
}});

Clazz.newMeth(C$, 'setControlPanelBackground$java_awt_Color$ClassA', function (color, excludedClasses) {
if (this.getControlPanel() != null ) {
(I$[12]||$incl$(12)).setBackgroundDeep$java_awt_Component$java_awt_Color$ClassA$Z(this.getControlPanel(), color, excludedClasses, false);
}});

Clazz.newMeth(C$, 'setClockControlPanelBackground$java_awt_Color', function (color) {
if (this.getClockControlPanel() != null ) {
var excludedClasses = Clazz.array(java.lang.Class, -1, [Clazz.getClass((I$[11]||$incl$(11)))]);
this.setClockControlPanelBackground$java_awt_Color$ClassA(color, excludedClasses);
}});

Clazz.newMeth(C$, 'setClockControlPanelBackground$java_awt_Color$ClassA', function (color, excludedClasses) {
if (this.getClockControlPanel() != null ) {
(I$[12]||$incl$(12)).setBackgroundDeep$java_awt_Component$java_awt_Color$ClassA$Z(this.getClockControlPanel(), color, excludedClasses, false);
}});

Clazz.newMeth(C$, 'setHelpPanelBackground$java_awt_Color', function (color) {
if (this.getHelpPanel() != null ) {
var excludedClasses = Clazz.array(java.lang.Class, -1, [Clazz.getClass((I$[11]||$incl$(11)))]);
this.setHelpPanelBackground$java_awt_Color$ClassA(color, excludedClasses);
}});

Clazz.newMeth(C$, 'setHelpPanelBackground$java_awt_Color$ClassA', function (color, excludedClasses) {
if (this.getHelpPanel() != null ) {
(I$[12]||$incl$(12)).setBackgroundDeep$java_awt_Component$java_awt_Color$ClassA$Z(this.getHelpPanel(), color, excludedClasses, false);
}});

Clazz.newMeth(C$, 'reset', function () {
});
;
(function(){var C$=Clazz.newInterface(P$.Module, "Listener", function(){
}, null, 'java.util.EventListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})()

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:44
