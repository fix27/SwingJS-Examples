(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[[['java.awt.geom.Point2D','.Double']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "PolygonUtils");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getArea$java_awt_geom_Point2DA', function (p) {
var a = 0;
for (var i = 0; i < p.length; i++) {
var j = (i + 1) % p.length;
a += (p[i].getX() * p[j].getY());
a -= (p[j].getX() * p[i].getY());
}
a *= 0.5;
return a;
}, 1);

Clazz.newMeth(C$, 'getCentroid$java_awt_geom_Point2DA', function (p) {
var cx = 0;
var cy = 0;
for (var i = 0; i < p.length; i++) {
var j = (i + 1) % p.length;
var n = ((p[i].getX() * p[j].getY()) - (p[j].getX() * p[i].getY()));
cx += (p[i].getX() + p[j].getX()) * n;
cy += (p[i].getY() + p[j].getY()) * n;
}
var a = C$.getArea$java_awt_geom_Point2DA(p);
var f = 1 / (a * 6.0);
cx *= f;
cy *= f;
return Clazz.new_((I$[1]||$incl$(1)).c$$D$D,[cx, cy]);
}, 1);
})();
//Created 2018-01-31 11:02:46
