(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[['java.util.Arrays']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "MedianFilter");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.source = null;
this.target = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$DA', function (data) {
C$.$init$.apply(this);
this.source = data;
this.target = Clazz.array(Double.TYPE, [this.source.length]);
}, 1);

Clazz.newMeth(C$, 'getMedian$DA', function (data) {
var workingData = Clazz.array(Double.TYPE, [data.length]);
for (var i = 0; i < data.length; i++) {
workingData[i] = data[i];
}
return C$.getMedianInternal$DA(workingData);
}, 1);

Clazz.newMeth(C$, 'getMedianInternal$DA', function (data) {
(I$[1]||$incl$(1)).sort$DA(data);
return data[(data.length/2|0)];
}, 1);

Clazz.newMeth(C$, 'filter$I', function (width) {
var temp = Clazz.array(Double.TYPE, [width]);
for (var i = 0; i < this.source.length - width + 1; i++) {
for (var k = 0; k < width; k++) {
temp[k] = this.source[i + k];
}
this.target[i + (width/2|0)] = C$.getMedianInternal$DA(temp);
}
for (var i = 0; i < (width/2|0); i++) {
this.target[i] = this.target[(width/2|0)];
}
for (var i = this.target.length - (width/2|0); i < this.target.length; i++) {
this.target[i] = this.target[this.target.length - (width/2|0) - 1];
}
for (var i = 0; i < this.source.length; i++) {
this.source[i] = this.target[i];
}
return this.source;
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:46
