(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model"),I$=[];
var C$=Clazz.newInterface(P$, "ResetModel");
})();
//Created 2018-01-31 11:02:47
