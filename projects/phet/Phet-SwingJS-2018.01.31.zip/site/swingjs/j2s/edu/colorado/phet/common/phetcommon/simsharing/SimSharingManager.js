(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing"),I$=[['java.util.ArrayList','edu.colorado.phet.common.phetcommon.simsharing.logs.StringLog','edu.colorado.phet.common.phetcommon.application.PhetApplicationConfig']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SimSharingManager");
C$.INSTANCE = null;
C$.initListeners = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.INSTANCE = null;
C$.initListeners = Clazz.new_((I$[1]||$incl$(1)));
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.enabled = false;
this.messageCount = 0;
this.logs = null;
this.stringLog = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.logs = Clazz.new_((I$[1]||$incl$(1)));
this.stringLog = Clazz.new_((I$[2]||$incl$(2)));
}, 1);

Clazz.newMeth(C$, 'getInstance', function () {
if (C$.INSTANCE == null ) {
C$.init$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig(Clazz.new_((I$[3]||$incl$(3)).c$$SA$S,[Clazz.array(java.lang.String, -1, []), "sim-sharing-manager"]));
}Clazz.assert(C$, this, function(){return (C$.INSTANCE != null )});
return C$.INSTANCE;
}, 1);

Clazz.newMeth(C$, 'init', function () {
C$.init$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig(Clazz.new_((I$[3]||$incl$(3)).c$$SA$S,[Clazz.array(java.lang.String, -1, ["-study"]), "sim-sharing-manager"]));
}, 1);

Clazz.newMeth(C$, 'init$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig', function (config) {
C$.init$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig$S(config, "sessions");
}, 1);

Clazz.newMeth(C$, 'init$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig$S', function (config, dbName) {
C$.INSTANCE = Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig$S,[config, dbName]);
for (var initListener, $initListener = C$.initListeners.iterator(); $initListener.hasNext()&&((initListener=$initListener.next()),1);) {
initListener.$apply$TT(C$.INSTANCE);
}
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig$S', function (applicationConfig, dbName) {
C$.$init$.apply(this);
this.enabled = false;
}, 1);

Clazz.newMeth(C$, 'getMessageCount', function () {
return this.messageCount;
});

Clazz.newMeth(C$, 'isEnabled', function () {
return this.enabled;
});

Clazz.newMeth(C$, 'sendSystemMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_ISystemComponent$edu_colorado_phet_common_phetcommon_simsharing_messages_ISystemComponentType$edu_colorado_phet_common_phetcommon_simsharing_messages_ISystemAction', function (component, componentType, action) {
}, 1);

Clazz.newMeth(C$, 'sendSystemMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_ISystemComponent$edu_colorado_phet_common_phetcommon_simsharing_messages_ISystemComponentType$edu_colorado_phet_common_phetcommon_simsharing_messages_ISystemAction$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet', function (component, componentType, action, parameters) {
}, 1);

Clazz.newMeth(C$, 'sendSystemMessageNS$edu_colorado_phet_common_phetcommon_simsharing_messages_ISystemComponent$edu_colorado_phet_common_phetcommon_simsharing_messages_ISystemComponentType$edu_colorado_phet_common_phetcommon_simsharing_messages_ISystemAction$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet', function (component, componentType, action, parameters) {
});

Clazz.newMeth(C$, 'sendButtonPressed$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent', function (component) {
}, 1);

Clazz.newMeth(C$, 'sendUserMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponentType$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserAction', function (component, componentType, action) {
}, 1);

Clazz.newMeth(C$, 'sendUserMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponentType$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserAction$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet', function (component, componentType, action, parameters) {
}, 1);

Clazz.newMeth(C$, 'sendModelMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IModelComponent$edu_colorado_phet_common_phetcommon_simsharing_messages_IModelComponentType$edu_colorado_phet_common_phetcommon_simsharing_messages_IModelAction', function (component, componentType, action) {
}, 1);

Clazz.newMeth(C$, 'sendModelMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IModelComponent$edu_colorado_phet_common_phetcommon_simsharing_messages_IModelComponentType$edu_colorado_phet_common_phetcommon_simsharing_messages_IModelAction$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet', function (component, componentType, action, parameters) {
}, 1);

Clazz.newMeth(C$, 'getLogNames', function () {
var logNames = Clazz.new_((I$[1]||$incl$(1)));
for (var log, $log = this.logs.iterator(); $log.hasNext()&&((log=$log.next()),1);) {
logNames.add$TE(log.getName());
}
return logNames;
});

Clazz.newMeth(C$, 'shutdown', function () {
for (var log, $log = this.logs.iterator(); $log.hasNext()&&((log=$log.next()),1);) {
log.shutdown();
}
});
C$.$_ASSERT_ENABLED_ = ClassLoader.$getClassAssertionStatus(C$);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:49
