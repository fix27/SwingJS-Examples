(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model"),I$=[[['java.awt.geom.Point2D','.Double'],['java.awt.geom.Ellipse2D','.Double'],'edu.colorado.phet.common.phetcommon.view.util.DoubleGeneralPath','java.awt.geom.Area']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Bucket");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.position = null;
this.holeShape = null;
this.containerShape = null;
this.baseColor = null;
this.captionText = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.position = Clazz.new_((I$[1]||$incl$(1)));
}, 1);

Clazz.newMeth(C$, 'c$$D$D$java_awt_geom_Dimension2D$java_awt_Color$S', function (x, y, size, baseColor, caption) {
C$.c$$java_awt_geom_Point2D_Double$java_awt_geom_Dimension2D$java_awt_Color$S.apply(this, [Clazz.new_((I$[1]||$incl$(1)).c$$D$D,[x, y]), size, baseColor, caption]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_geom_Point2D_Double$java_awt_geom_Dimension2D$java_awt_Color$S', function (position, size, baseColor, caption) {
C$.$init$.apply(this);
this.position.x = position.x;
this.position.y = position.y;
this.baseColor = baseColor;
this.captionText = caption;
this.holeShape = Clazz.new_((I$[2]||$incl$(2)).c$$D$D$D$D,[-size.getWidth() / 2, -size.getHeight() * 0.25 / 2, size.getWidth(), size.getHeight() * 0.25]);
var containerHeight = size.getHeight() * 0.875;
var containerPath = Clazz.new_((I$[3]||$incl$(3)));
containerPath.moveTo$D$D(-size.getWidth() * 0.5, 0);
containerPath.lineTo$D$D(-size.getWidth() * 0.4, -containerHeight * 0.8);
containerPath.curveTo$D$D$D$D$D$D(-size.getWidth() * 0.3, -containerHeight * 0.8 - size.getHeight() * 0.25 * 0.6 , size.getWidth() * 0.3, -containerHeight * 0.8 - size.getHeight() * 0.25 * 0.6 , size.getWidth() * 0.4, -containerHeight * 0.8);
containerPath.lineTo$D$D(size.getWidth() * 0.5, 0);
containerPath.closePath();
var containerArea = Clazz.new_((I$[4]||$incl$(4)).c$$java_awt_Shape,[containerPath.getGeneralPath()]);
containerArea.subtract$java_awt_geom_Area(Clazz.new_((I$[4]||$incl$(4)).c$$java_awt_Shape,[this.holeShape]));
this.containerShape = containerArea;
}, 1);

Clazz.newMeth(C$, 'getPosition', function () {
return this.position;
});

Clazz.newMeth(C$, 'setPosition$java_awt_geom_Point2D_Double', function (position) {
this.position = position;
});

Clazz.newMeth(C$, 'getHoleShape', function () {
return this.holeShape;
});

Clazz.newMeth(C$, 'getContainerShape', function () {
return this.containerShape;
});

Clazz.newMeth(C$, 'getBaseColor', function () {
return this.baseColor;
});

Clazz.newMeth(C$, 'getCaptionText', function () {
return this.captionText;
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:47
