(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.property"),I$=[];
var C$=Clazz.newClass(P$, "ConstrainedDoubleProperty", null, 'edu.colorado.phet.common.phetcommon.model.property.ConstrainedProperty');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.min = 0;
this.max = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$D$D$D', function (min, max, value) {
C$.superclazz.c$$TT.apply(this, [new Double(value)]);
C$.$init$.apply(this);
this.min = min;
this.max = max;
if (!this.isValid$Double(new Double(value))) {
this.handleInvalidValue$TT(new Double(value));
}}, 1);

Clazz.newMeth(C$, ['isValid$Double','isValid$TT'], function (value) {
return ((value).doubleValue() >= this.min  && (value).doubleValue() <= this.max  );
});

Clazz.newMeth(C$, 'getMin', function () {
return this.min;
});

Clazz.newMeth(C$, 'getMax', function () {
return this.max;
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:48
