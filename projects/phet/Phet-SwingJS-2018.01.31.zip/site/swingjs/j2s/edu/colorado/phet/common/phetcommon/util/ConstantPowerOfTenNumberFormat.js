(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.util"),I$=[['edu.colorado.phet.common.phetcommon.util.DefaultDecimalFormat','java.text.MessageFormat','java.text.NumberFormat','javax.swing.JFrame','javax.swing.JPanel','edu.colorado.phet.common.phetcommon.view.util.EasyGridBagLayout','java.awt.Insets','javax.swing.JLabel','edu.colorado.phet.common.phetcommon.view.util.SwingUtils']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ConstantPowerOfTenNumberFormat", null, 'java.text.NumberFormat');
C$.SIMPLE_FORMAT = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.SIMPLE_FORMAT = Clazz.new_((I$[1]||$incl$(1)).c$$S,["0"]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._decimalFormat = null;
this._simpleMantissaFormat = false;
this._constantExponent = 0;
this._simpleExponentFormat = false;
this._exponentScale = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S$I', function (mantissaFormat, constantExponent) {
C$.c$$S$I$I.apply(this, [mantissaFormat, constantExponent, 100]);
}, 1);

Clazz.newMeth(C$, 'c$$S$I$I', function (mantissaFormat, constantExponent, exponentScale) {
Clazz.super_(C$, this,1);
this._decimalFormat = Clazz.new_((I$[1]||$incl$(1)).c$$S,[mantissaFormat]);
this._constantExponent = constantExponent;
this._simpleMantissaFormat = true;
this._simpleExponentFormat = true;
this._exponentScale = exponentScale;
}, 1);

Clazz.newMeth(C$, 'setSimpleMantissaFormat$Z', function (b) {
this._simpleMantissaFormat = b;
});

Clazz.newMeth(C$, 'isSimpleMantissaFormat', function () {
return this._simpleMantissaFormat;
});

Clazz.newMeth(C$, 'setSimpleExponentFormat$Z', function (b) {
this._simpleExponentFormat = b;
});

Clazz.newMeth(C$, 'isSimpleExponentFormat', function () {
return this._simpleExponentFormat;
});

Clazz.newMeth(C$, 'format$D$StringBuffer$java_text_FieldPosition', function (number, toAppendTo, pos) {
var valueString = null;
if (number == 0  && this._simpleMantissaFormat ) {
valueString = "0";
} else if ((this._constantExponent == 0 || this._constantExponent == 1 ) && this._simpleExponentFormat ) {
valueString = C$.SIMPLE_FORMAT.format$D(number);
} else {
var mantissa = number / Math.pow(10, this._constantExponent);
var mantissaString = this._decimalFormat.format$D(mantissa);
var args = Clazz.array(java.lang.Object, -1, [mantissaString,  new Integer(this._constantExponent), new Integer(this._exponentScale)]);
valueString = (I$[2]||$incl$(2)).format$S$OA("<html>{0} x 10<sup style=\"font-size:{2}%\"> {1}</sup></html>", args);
}toAppendTo.append$S(valueString);
return toAppendTo;
});

Clazz.newMeth(C$, 'format$J$StringBuffer$java_text_FieldPosition', function (number, toAppendTo, pos) {
return this.format$D$StringBuffer$java_text_FieldPosition(number, toAppendTo, pos);
});

Clazz.newMeth(C$, 'parse$S$java_text_ParsePosition', function (source, parsePosition) {
throw Clazz.new_(Clazz.load('java.lang.UnsupportedOperationException').c$$S,["not supported"]);
});

Clazz.newMeth(C$, 'main', function (args) {
var zero = 0;
var value = 4.23E7;
var p1 = "0.00";
var p2 = "0.0";
var p3 = "#.0";
var p4 = "0";
var f1 = Clazz.new_(C$.c$$S$I$I,[p1, 5, 80]);
f1.setSimpleMantissaFormat$Z(false);
var f2 = Clazz.new_(C$.c$$S$I,[p2, 5]);
var f3 = Clazz.new_(C$.c$$S$I,[p3, 5]);
var f4 = Clazz.new_(C$.c$$S$I,[p4, 5]);
var f5 = Clazz.new_(C$.c$$S$I,[p4, 1]);
var f6 = Clazz.new_(C$.c$$S$I,[p4, 0]);
var tests = Clazz.array((I$[3]||$incl$(3)), -1, [f1, f2, f3, f4, f5, f6]);
var frame = Clazz.new_((I$[4]||$incl$(4)));
frame.setDefaultCloseOperation$I(3);
var panel = Clazz.new_((I$[5]||$incl$(5)));
var layout = Clazz.new_((I$[6]||$incl$(6)).c$$javax_swing_JPanel,[panel]);
panel.setLayout$java_awt_LayoutManager(layout);
layout.setInsets$java_awt_Insets(Clazz.new_((I$[7]||$incl$(7)).c$$I$I$I$I,[5, 10, 5, 10]));
for (var row = 0; row < tests.length; row++) {
var label = Clazz.new_((I$[8]||$incl$(8)).c$$S,[tests[row].format$D(4.23E7)]);
layout.addComponent$java_awt_Component$I$I(label, row, 0);
System.out.println$S("value=" + new Double(0.0).toString() + " formatted=" + tests[row].format$D(0.0) );
System.out.println$S("value=" + new Double(4.23E7).toString() + " formatted=" + tests[row].format$D(4.23E7) );
}
frame.getContentPane().add$java_awt_Component(panel);
frame.pack();
(I$[9]||$incl$(9)).centerWindowOnScreen$java_awt_Window(frame);
frame.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:51
