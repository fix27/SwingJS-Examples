(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.messages"),I$=[['edu.colorado.phet.common.phetcommon.simsharing.messages.ParameterKeys']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Parameter");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.name = null;
this.value = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterValue', function (name, value) {
C$.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$S.apply(this, [name, value == null  ? "null" : value.toString()]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$Z', function (name, value) {
C$.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$S.apply(this, [name, value + ""]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$D', function (name, value) {
C$.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$S.apply(this, [name, new Double(value).toString() + ""]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$J$I', function (name, value, unused) {
C$.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$S.apply(this, [name, value + ""]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$S', function (name, value) {
C$.$init$.apply(this);
Clazz.assert(C$, this, function(){return !name.toString().contains$CharSequence("\u0009")});
this.name = name;
this.value = (value == null ) ? "null" : value.$replace("\u0009", "\\t");
Clazz.assert(C$, this, function(){return !this.value.contains$CharSequence("\u0009")});
}, 1);

Clazz.newMeth(C$, 'toString', function () {
return this.name + " = " + this.value ;
});

Clazz.newMeth(C$, 'equals$O', function (o) {
if (this === o ) {
return true;
}if (o == null  || this.getClass() !== o.getClass()  ) {
return false;
}var parameter = o;
if (this.name != null  ? !this.name.equals$O(parameter.name) : parameter.name != null ) {
return false;
}if (this.value != null  ? !this.value.equals$O(parameter.value) : parameter.value != null ) {
return false;
}return true;
});

Clazz.newMeth(C$, 'hashCode', function () {
var result = this.name != null  ? this.name.hashCode() : 0;
result = 31 * result + (this.value != null  ? this.value.hashCode() : 0);
return result;
});

Clazz.newMeth(C$, 'main', function (args) {
System.out.println$O(Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterValue,[(I$[1]||$incl$(1)).averageX, null]));
System.out.println$O(Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$S,[(I$[1]||$incl$(1)).averageX, null]));
System.out.println$O(Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$S,[(I$[1]||$incl$(1)).averageX, "something\u0009exciting!"]));
System.out.println$O(Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$S,[(I$[1]||$incl$(1)).averageX, "something\\texciting!"]));
}, 1);
C$.$_ASSERT_ENABLED_ = ClassLoader.$getClassAssertionStatus(C$);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:50
