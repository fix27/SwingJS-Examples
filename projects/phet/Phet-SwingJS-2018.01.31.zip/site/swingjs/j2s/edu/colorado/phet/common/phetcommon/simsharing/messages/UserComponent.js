(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.messages"),I$=[['edu.colorado.phet.common.phetcommon.util.PhetUtilities']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "UserComponent", null, null, 'edu.colorado.phet.common.phetcommon.simsharing.messages.IUserComponent');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.id = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (id) {
C$.$init$.apply(this);
this.id = id;
}, 1);

Clazz.newMeth(C$, 'c$$I', function (id) {
C$.c$$S.apply(this, [String.valueOf(id)]);
}, 1);

Clazz.newMeth(C$, 'c$$Class', function (theClass) {
C$.c$$S.apply(this, [C$.toId$Class(theClass)]);
}, 1);

Clazz.newMeth(C$, 'c$$O', function (object) {
C$.c$$Class.apply(this, [object.getClass()]);
}, 1);

Clazz.newMeth(C$, 'toString', function () {
return this.id;
});

Clazz.newMeth(C$, 'toId$Class', function (theClass) {
var basename = (I$[1]||$incl$(1)).getBasename$Class(theClass);
if (basename.length$() == 1) {
return basename.toLowerCase();
} else {
return Character.toLowerCase(basename.charAt(0)) + basename.substring(1);
}}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:51
