(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model"),I$=[['java.util.ArrayList']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "CommandQueue", null, null, 'edu.colorado.phet.common.phetcommon.model.Command');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.al = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.al = Clazz.new_((I$[1]||$incl$(1)));
}, 1);

Clazz.newMeth(C$, 'size', function () {
return this.al.size();
});

Clazz.newMeth(C$, 'doIt', function () {
while (!this.al.isEmpty()){
p$.commandAt$I.apply(this, [0]).doIt();
this.al.remove$I(0);
}
});

Clazz.newMeth(C$, 'commandAt$I', function (i) {
return this.al.get$I(i);
});

Clazz.newMeth(C$, 'addCommand$edu_colorado_phet_common_phetcommon_model_Command', function (c) {
this.al.add$TE(c);
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:47
