(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.clock"),I$=[['edu.colorado.phet.common.phetcommon.util.EventChannel','edu.colorado.phet.common.phetcommon.model.clock.ClockListener','edu.colorado.phet.common.phetcommon.model.clock.ClockEvent']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "VariableConstantTickClock", null, null, ['edu.colorado.phet.common.phetcommon.model.clock.IClock', 'edu.colorado.phet.common.phetcommon.model.clock.ClockListener']);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.wrappedClock = null;
this.dt = 0;
this.clockEventChannel = null;
this.clockListenerProxy = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.clockEventChannel = Clazz.new_((I$[1]||$incl$(1)).c$$Class,[Clazz.getClass((I$[2]||$incl$(2)),['clockPaused$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent','clockStarted$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent','clockTicked$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent','simulationTimeChanged$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent','simulationTimeReset$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent'])]);
this.clockListenerProxy = this.clockEventChannel.getListenerProxy();
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_model_clock_IClock$D', function (clock, dt) {
C$.$init$.apply(this);
this.wrappedClock = clock;
this.wrappedClock.addClockListener$edu_colorado_phet_common_phetcommon_model_clock_ClockListener(this);
this.dt = dt;
}, 1);

Clazz.newMeth(C$, 'setDt$D', function (dt) {
this.dt = dt;
});

Clazz.newMeth(C$, 'clockTicked$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
var proxyEvent = Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[this]);
this.clockListenerProxy.clockTicked$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(proxyEvent);
});

Clazz.newMeth(C$, 'clockStarted$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
var proxyEvent = Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[this]);
this.clockListenerProxy.clockStarted$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(proxyEvent);
});

Clazz.newMeth(C$, 'clockPaused$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
var proxyEvent = Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[this]);
this.clockListenerProxy.clockPaused$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(proxyEvent);
});

Clazz.newMeth(C$, 'simulationTimeChanged$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
var proxyEvent = Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[this]);
this.clockListenerProxy.simulationTimeChanged$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(proxyEvent);
});

Clazz.newMeth(C$, 'simulationTimeReset$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
var proxyEvent = Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[this]);
this.clockListenerProxy.simulationTimeReset$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(proxyEvent);
});

Clazz.newMeth(C$, 'getSimulationTimeChange', function () {
return this.dt;
});

Clazz.newMeth(C$, 'addClockListener$edu_colorado_phet_common_phetcommon_model_clock_ClockListener', function (clockListener) {
this.clockEventChannel.addListener$java_util_EventListener(clockListener);
});

Clazz.newMeth(C$, 'removeClockListener$edu_colorado_phet_common_phetcommon_model_clock_ClockListener', function (clockListener) {
this.clockEventChannel.removeListener$java_util_EventListener(clockListener);
});

Clazz.newMeth(C$, 'start', function () {
this.wrappedClock.start();
});

Clazz.newMeth(C$, 'pause', function () {
this.wrappedClock.pause();
});

Clazz.newMeth(C$, 'isPaused', function () {
return this.wrappedClock.isPaused();
});

Clazz.newMeth(C$, 'isRunning', function () {
return this.wrappedClock.isRunning();
});

Clazz.newMeth(C$, 'resetSimulationTime', function () {
this.wrappedClock.resetSimulationTime();
});

Clazz.newMeth(C$, 'getWallTime', function () {
return this.wrappedClock.getWallTime();
});

Clazz.newMeth(C$, 'getWallTimeChange', function () {
return this.wrappedClock.getWallTimeChange();
});

Clazz.newMeth(C$, 'getSimulationTime', function () {
return this.wrappedClock.getSimulationTime();
});

Clazz.newMeth(C$, 'setSimulationTime$D', function (simulationTime) {
this.wrappedClock.setSimulationTime$D(simulationTime);
});

Clazz.newMeth(C$, 'stepClockWhilePaused', function () {
this.wrappedClock.stepClockWhilePaused();
});

Clazz.newMeth(C$, 'stepClockBackWhilePaused', function () {
this.wrappedClock.stepClockBackWhilePaused();
});

Clazz.newMeth(C$, 'containsClockListener$edu_colorado_phet_common_phetcommon_model_clock_ClockListener', function (clockListener) {
return this.wrappedClock.containsClockListener$edu_colorado_phet_common_phetcommon_model_clock_ClockListener(clockListener);
});

Clazz.newMeth(C$, 'removeAllClockListeners', function () {
this.clockEventChannel.removeAllListeners();
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:48
