(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.messages"),I$=[];
var C$=Clazz.newInterface(P$, "IMessageType");
})();
//Created 2018-01-31 11:02:50
