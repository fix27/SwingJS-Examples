(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.application"),I$=[['edu.colorado.phet.common.phetcommon.resources.PhetCommonResources','javax.swing.JLabel','edu.colorado.phet.common.phetcommon.view.util.PhetFont','javax.swing.ImageIcon','edu.colorado.phet.common.phetcommon.view.VerticalLayoutPanel','javax.swing.border.CompoundBorder','javax.swing.border.LineBorder','java.awt.Color','javax.swing.border.EmptyBorder','javax.swing.Box','java.awt.event.MouseAdapter','edu.colorado.phet.common.phetcommon.view.util.SwingUtils','javax.swing.Timer','edu.colorado.phet.common.phetcommon.application.KSUCreditsWindow$2']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "KSUCreditsWindow", null, 'javax.swing.JWindow');
C$.TRANSLATED_BY = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.TRANSLATED_BY = (I$[1]||$incl$(1)).getString$S("Common.About.CreditsDialog.TranslationCreditsTitle");
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Frame', function (parent) {
C$.superclazz.c$$java_awt_Frame.apply(this, [parent]);
C$.$init$.apply(this);
var label = Clazz.new_((I$[2]||$incl$(2)).c$$S,[C$.TRANSLATED_BY]);
label.setFont$java_awt_Font(Clazz.new_((I$[3]||$incl$(3)).c$$I,[18]));
var logo = Clazz.new_((I$[2]||$incl$(2)).c$$javax_swing_Icon,[Clazz.new_((I$[4]||$incl$(4)).c$$java_awt_Image,[(I$[1]||$incl$(1)).getImage$S("logos/ECSME-KSU-logos.jpg")])]);
var panel = Clazz.new_((I$[5]||$incl$(5)));
var margin = 12;
panel.setBorder$javax_swing_border_Border(Clazz.new_((I$[6]||$incl$(6)).c$$javax_swing_border_Border$javax_swing_border_Border,[Clazz.new_((I$[7]||$incl$(7)).c$$java_awt_Color$I,[(I$[8]||$incl$(8)).BLACK, 1]), Clazz.new_((I$[9]||$incl$(9)).c$$I$I$I$I,[margin, margin, margin, margin])]));
panel.add$java_awt_Component(label);
panel.add$java_awt_Component((I$[10]||$incl$(10)).createVerticalStrut$I(5));
panel.add$java_awt_Component(logo);
this.setContentPane$java_awt_Container(panel);
this.pack();
this.addMouseListener$java_awt_event_MouseListener(((
(function(){var C$=Clazz.newClass(P$, "KSUCreditsWindow$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (event) {
this.b$['edu.colorado.phet.common.phetcommon.application.KSUCreditsWindow'].dispose();
});
})()
), Clazz.new_((I$[11]||$incl$(11)), [this, null],P$.KSUCreditsWindow$1)));
}, 1);

Clazz.newMeth(C$, 'show$java_awt_Frame', function (parent) {
var window = Clazz.new_(C$.c$$java_awt_Frame,[parent]);
(I$[12]||$incl$(12)).centerInParent$java_awt_Component(window);
window.setVisible$Z(true);
var timer = Clazz.new_((I$[13]||$incl$(13)).c$$I$java_awt_event_ActionListener,[4000, ((
(function(){var C$=Clazz.newClass(P$, "KSUCreditsWindow$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.$finals.window.isDisplayable()) {
this.$finals.window.dispose();
}});
})()
), Clazz.new_((I$[14]||$incl$(14)).$init$, [this, {window: window}]))]);
timer.setRepeats$Z(false);
timer.start();
return window;
}, 1);

Clazz.newMeth(C$, 'main', function (args) {
var window = Clazz.new_(C$.c$$java_awt_Frame,[null]);
(I$[12]||$incl$(12)).centerWindowOnScreen$java_awt_Window(window);
window.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:44
