(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[['edu.colorado.phet.common.phetcommon.math.vector.Vector3F']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Bounds3F");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x = 0;
this.y = 0;
this.z = 0;
this.width = 0;
this.height = 0;
this.depth = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$F$F$F$F$F$F', function (x, y, z, width, height, depth) {
C$.$init$.apply(this);
this.x = x;
this.y = y;
this.z = z;
this.width = width;
this.height = height;
this.depth = depth;
}, 1);

Clazz.newMeth(C$, 'fromMinMax$F$F$F$F$F$F', function (minX, maxX, minY, maxY, minZ, maxZ) {
return Clazz.new_(C$.c$$F$F$F$F$F$F,[minX, minY, minZ, maxX - minX, maxY - minY, maxZ - minZ]);
}, 1);

Clazz.newMeth(C$, 'getDepth', function () {
return this.depth;
});

Clazz.newMeth(C$, 'getHeight', function () {
return this.height;
});

Clazz.newMeth(C$, 'getWidth', function () {
return this.width;
});

Clazz.newMeth(C$, 'getX', function () {
return this.x;
});

Clazz.newMeth(C$, 'getY', function () {
return this.y;
});

Clazz.newMeth(C$, 'getZ', function () {
return this.z;
});

Clazz.newMeth(C$, 'getMinX', function () {
return this.x;
});

Clazz.newMeth(C$, 'getMinY', function () {
return this.y;
});

Clazz.newMeth(C$, 'getMinZ', function () {
return this.z;
});

Clazz.newMeth(C$, 'getMaxX', function () {
return this.x + this.width;
});

Clazz.newMeth(C$, 'getMaxY', function () {
return this.y + this.height;
});

Clazz.newMeth(C$, 'getMaxZ', function () {
return this.z + this.depth;
});

Clazz.newMeth(C$, 'getPosition', function () {
return Clazz.new_((I$[1]||$incl$(1)).c$$F$F$F,[this.x, this.y, this.z]);
});

Clazz.newMeth(C$, 'getExtent', function () {
return Clazz.new_((I$[1]||$incl$(1)).c$$F$F$F,[this.x + this.width, this.y + this.height, this.z + this.depth]);
});

Clazz.newMeth(C$, 'getCenter', function () {
return this.getPosition().plus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.getExtent()).times$F(0.5);
});

Clazz.newMeth(C$, 'getCenterX', function () {
return this.getCenter().x;
});

Clazz.newMeth(C$, 'getCenterY', function () {
return this.getCenter().y;
});

Clazz.newMeth(C$, 'getCenterZ', function () {
return this.getCenter().z;
});

Clazz.newMeth(C$, 'intersectedBy$edu_colorado_phet_common_phetcommon_math_Ray3F', function (ray) {
var tmin;
var tmax;
var tymin;
var tymax;
var tzmin;
var tzmax;
var t0 = 1.0E-6;
var t1 = Infinity;
if (ray.dir.x >= 0 ) {
tmin = (this.getMinX() - ray.pos.x) / ray.dir.x;
tmax = (this.getMaxX() - ray.pos.x) / ray.dir.x;
} else {
tmin = (this.getMaxX() - ray.pos.x) / ray.dir.x;
tmax = (this.getMinX() - ray.pos.x) / ray.dir.x;
}if (ray.dir.y >= 0 ) {
tymin = (this.getMinY() - ray.pos.y) / ray.dir.y;
tymax = (this.getMaxY() - ray.pos.y) / ray.dir.y;
} else {
tymin = (this.getMaxY() - ray.pos.y) / ray.dir.y;
tymax = (this.getMinY() - ray.pos.y) / ray.dir.y;
}if ((tmin > tymax ) || (tymin > tmax ) ) {
return false;
}if (tymin > tmin ) {
tmin = tymin;
}if (tymax < tmax ) {
tmax = tymax;
}if (ray.dir.z >= 0 ) {
tzmin = (this.getMinZ() - ray.pos.z) / ray.dir.z;
tzmax = (this.getMaxZ() - ray.pos.z) / ray.dir.z;
} else {
tzmin = (this.getMaxZ() - ray.pos.z) / ray.dir.z;
tzmax = (this.getMinZ() - ray.pos.z) / ray.dir.z;
}if ((tmin > tzmax ) || (tzmin > tmax ) ) {
return false;
}if (tzmin > tmin ) {
tmin = tzmin;
}if (tzmax < tmax ) {
tmax = tzmax;
}return ((tmin < t1 ) && (tmax > t0 ) );
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:45
