(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[['java.util.ArrayList',['edu.colorado.phet.common.phetcommon.math.Function','.LinearFunction']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ModelViewTransform1D", function(){
Clazz.newInstance(this, arguments,0,C$);
});

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.$modelToView = null;
this.transformListeners = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.transformListeners = Clazz.new_((I$[1]||$incl$(1)));
}, 1);

Clazz.newMeth(C$, 'c$$D$D$I$I', function (minModel, maxModel, minView, maxView) {
C$.$init$.apply(this);
this.$modelToView = Clazz.new_((I$[2]||$incl$(2)).c$$D$D$D$D,[minModel, maxModel, minView, maxView]);
}, 1);

Clazz.newMeth(C$, 'toString', function () {
return this.$modelToView.toString();
});

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_ModelViewTransform1D', function (m) {
C$.c$$D$D$I$I.apply(this, [m.getMinModel(), m.getMaxModel(), m.getMinView(), m.getMaxView()]);
}, 1);

Clazz.newMeth(C$, 'setTransform$edu_colorado_phet_common_phetcommon_math_ModelViewTransform1D', function (m) {
this.$modelToView.setInput$D$D(m.getMinModel(), m.getMaxModel());
this.$modelToView.setOutput$D$D(m.getMinView(), m.getMaxView());
});

Clazz.newMeth(C$, 'getMinModel', function () {
return this.$modelToView.getMinInput();
});

Clazz.newMeth(C$, 'getMaxModel', function () {
return this.$modelToView.getMaxInput();
});

Clazz.newMeth(C$, 'getMinView', function () {
return (this.$modelToView.getMinOutput()|0);
});

Clazz.newMeth(C$, 'getMaxView', function () {
return (this.$modelToView.getMaxOutput()|0);
});

Clazz.newMeth(C$, 'modelToView$D', function (x) {
return (this.$modelToView.evaluate$D(x)|0);
});

Clazz.newMeth(C$, 'modelToViewDifferential$D', function (dModel) {
return this.modelToView$D(dModel) - this.modelToView$D(0);
});

Clazz.newMeth(C$, 'viewToModelDifferential$I', function (dView) {
return this.viewToModel$I(dView) - this.viewToModel$I(0);
});

Clazz.newMeth(C$, 'viewToModel$I', function (x) {
return this.$modelToView.createInverse().evaluate$D(x);
});

Clazz.newMeth(C$, 'addListener$edu_colorado_phet_common_phetcommon_math_ModelViewTransform1D_Observer', function (observer) {
this.transformListeners.add$TE(observer);
});

Clazz.newMeth(C$, 'update', function () {
for (var i = 0; i < this.transformListeners.size(); i++) {
var observer = this.transformListeners.get$I(i);
observer.transformChanged$edu_colorado_phet_common_phetcommon_math_ModelViewTransform1D(this);
}
});

Clazz.newMeth(C$, 'setModelRange$D$D', function (minModel, maxModel) {
if (this.$modelToView.getMinInput() != minModel  || this.$modelToView.getMinInput() != maxModel  ) {
this.$modelToView.setInput$D$D(minModel, maxModel);
this.update();
}});

Clazz.newMeth(C$, 'setViewRange$I$I', function (minView, maxView) {
if (this.$modelToView.getMinOutput() != minView  && this.$modelToView.getMaxOutput() != maxView  ) {
this.$modelToView.setOutput$D$D(minView, maxView);
this.update();
}});
;
(function(){var C$=Clazz.newInterface(P$.ModelViewTransform1D, "Observer", function(){
});
})()

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:46
