(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.resources"),I$=[['edu.colorado.phet.common.phetcommon.view.util.StringUtil']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "PhetProperties", null, 'java.util.Properties');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_util_Properties', function (properties) {
C$.superclazz.c$$java_util_Properties.apply(this, [properties]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getString$S', function (propertyName) {
return this.getString$S$Z(propertyName, true);
});

Clazz.newMeth(C$, 'getString$S$Z', function (propertyName, warnIfMissing) {
var s = C$.superclazz.prototype.getProperty$S.apply(this, [propertyName]);
if (s == null ) {
if (warnIfMissing) {
}s = propertyName;
}return s;
});

Clazz.newMeth(C$, 'getInt$S$I', function (key, defaultValue) {
return (I$[1]||$incl$(1)).asInt$S$I(this.getString$S(key), defaultValue);
});

Clazz.newMeth(C$, 'getDouble$S$D', function (key, defaultValue) {
return (I$[1]||$incl$(1)).asDouble$S$D(this.getString$S(key), defaultValue);
});

Clazz.newMeth(C$, 'getLong$S$J', function (key, defaultValue) {
return (I$[1]||$incl$(1)).asLong$S$J(this.getString$S(key), defaultValue);
});

Clazz.newMeth(C$, 'getChar$S$C', function (key, defaultValue) {
return (I$[1]||$incl$(1)).asChar$S$C(this.getString$S(key), defaultValue);
});

Clazz.newMeth(C$, 'getBoolean$S$Z', function (key, defaultValue) {
var value = defaultValue;
var s = this.getString$S(key);
if (s != null ) {
value = (I$[1]||$incl$(1)).asBoolean$S(s);
}return value;
});
})();
//Created 2018-01-31 11:02:49
