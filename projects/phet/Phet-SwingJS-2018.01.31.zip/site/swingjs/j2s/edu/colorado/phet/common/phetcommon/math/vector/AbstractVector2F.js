(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math.vector"),I$=[['edu.colorado.phet.common.phetcommon.math.vector.Vector2F','edu.colorado.phet.common.phetcommon.math.vector.Vector2D']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "AbstractVector2F", null, null, 'java.io.Serializable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'magnitude', function () {
return Math.sqrt(this.magnitudeSquared());
});

Clazz.newMeth(C$, 'magnitudeSquared', function () {
return this.getX() * this.getX() + this.getY() * this.getY();
});

Clazz.newMeth(C$, 'dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2F', function (v) {
var result = 0;
result += this.getX() * v.getX();
result += this.getY() * v.getY();
return result;
});

Clazz.newMeth(C$, 'getAngle', function () {
return Math.atan2(this.getY(), this.getX());
});

Clazz.newMeth(C$, 'distance$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2F', function (v) {
var dx = this.getX() - v.getX();
var dy = this.getY() - v.getY();
return Math.sqrt(dx * dx + dy * dy);
});

Clazz.newMeth(C$, 'getCrossProductScalar$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2F', function (v) {
return (this.magnitude() * v.magnitude() * Math.sin(this.getAngle() - v.getAngle()) );
});

Clazz.newMeth(C$, 'normalized', function () {
var magnitude = this.magnitude();
if (magnitude == 0 ) {
throw Clazz.new_(Clazz.load('java.lang.UnsupportedOperationException').c$$S,["Cannot normalize a zero-magnitude vector."]);
}return Clazz.new_((I$[1]||$incl$(1)).c$$F$F,[this.getX() / magnitude, this.getY() / magnitude]);
});

Clazz.newMeth(C$, 'getInstanceOfMagnitude$F', function (magnitude) {
return this.times$F(magnitude / this.magnitude());
});

Clazz.newMeth(C$, 'times$F', function (scale) {
return Clazz.new_((I$[1]||$incl$(1)).c$$F$F,[this.getX() * scale, this.getY() * scale]);
});

Clazz.newMeth(C$, 'plus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2F', function (v) {
return this.plus$F$F(v.getX(), v.getY());
});

Clazz.newMeth(C$, 'plus$java_awt_geom_Dimension2D', function (delta) {
return this.plus$F$F(delta.getWidth(), delta.getHeight());
});

Clazz.newMeth(C$, 'plus$F$F', function (x, y) {
return Clazz.new_((I$[1]||$incl$(1)).c$$F$F,[this.getX() + x, this.getY() + y]);
});

Clazz.newMeth(C$, 'getPerpendicularVector', function () {
return Clazz.new_((I$[1]||$incl$(1)).c$$F$F,[this.getY(), -this.getX()]);
});

Clazz.newMeth(C$, 'minus$F$F', function (x, y) {
return Clazz.new_((I$[1]||$incl$(1)).c$$F$F,[this.getX() - x, this.getY() - y]);
});

Clazz.newMeth(C$, 'minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2F', function (v) {
return this.minus$F$F(v.getX(), v.getY());
});

Clazz.newMeth(C$, 'getRotatedInstance$F', function (angle) {
return (I$[1]||$incl$(1)).createPolar$F$F(this.magnitude(), this.getAngle() + angle);
});

Clazz.newMeth(C$, 'to2F', function () {
return Clazz.new_((I$[2]||$incl$(2)).c$$D$D,[this.getX(), this.getY()]);
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:46
