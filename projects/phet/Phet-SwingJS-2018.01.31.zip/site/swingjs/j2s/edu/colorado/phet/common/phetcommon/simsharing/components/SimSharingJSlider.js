(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.components"),I$=[['edu.colorado.phet.common.phetcommon.simsharing.messages.ParameterKeys']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SimSharingJSlider", null, 'javax.swing.JSlider');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.userComponent = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent', function (userComponent) {
Clazz.super_(C$, this,1);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$I', function (userComponent, orientation) {
C$.superclazz.c$$I.apply(this, [orientation]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$I$I', function (userComponent, min, max) {
C$.superclazz.c$$I$I.apply(this, [min, max]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$I$I$I', function (userComponent, min, max, value) {
C$.superclazz.c$$I$I$I.apply(this, [min, max, value]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$I$I$I$I', function (userComponent, orientation, min, max, value) {
C$.superclazz.c$$I$I$I$I.apply(this, [orientation, min, max, value]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$javax_swing_BoundedRangeModel', function (userComponent, brm) {
C$.superclazz.c$$javax_swing_BoundedRangeModel.apply(this, [brm]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'enableMouseEvents', function () {
this.enableEvents$J(16);
});

Clazz.newMeth(C$, 'processMouseEvent$java_awt_event_MouseEvent', function (e) {
if (e.getID() == 501 && !this.isEnabled() ) {
p$.sendUserMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet.apply(this, [edu.colorado.phet.common.phetcommon.simsharing.messages.ParameterSet.parameterSetLong$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$J((I$[1]||$incl$(1)).value, this.getValue()).$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$Z((I$[1]||$incl$(1)).enabled, this.isEnabled()).$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$Z((I$[1]||$incl$(1)).interactive, this.isEnabled())]);
}C$.superclazz.prototype.processMouseEvent$java_awt_event_MouseEvent.apply(this, [e]);
});

Clazz.newMeth(C$, 'fireStateChanged', function () {
p$.sendUserMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet.apply(this, [edu.colorado.phet.common.phetcommon.simsharing.messages.ParameterSet.parameterSetLong$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$J((I$[1]||$incl$(1)).value, this.getValue())]);
C$.superclazz.prototype.fireStateChanged.apply(this, []);
});

Clazz.newMeth(C$, 'sendUserMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet', function (parameterSet) {
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:50
