(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.clock"),I$=[];
var C$=Clazz.newInterface(P$, "TimingStrategy", function(){
});
;
(function(){var C$=Clazz.newClass(P$.TimingStrategy, "Constant", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'edu.colorado.phet.common.phetcommon.model.clock.TimingStrategy');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.simulationTimeChange = 0;
this.timeChangeWhileStepping = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$D', function (simulationTimeChange) {
C$.c$$D$D.apply(this, [simulationTimeChange, simulationTimeChange]);
}, 1);

Clazz.newMeth(C$, 'c$$D$D', function (simulationTimeChange, timeChangeWhileStepping) {
C$.$init$.apply(this);
this.simulationTimeChange = simulationTimeChange;
this.timeChangeWhileStepping = timeChangeWhileStepping;
}, 1);

Clazz.newMeth(C$, 'getSimulationTimeChangeWT$J$J', function (lastWallTime, currentWallTime) {
return this.getSimulationTimeChange();
});

Clazz.newMeth(C$, 'getSimulationTimeChange', function () {
return this.simulationTimeChange;
});

Clazz.newMeth(C$, 'getSimulationTimeChangeForPausedClock', function () {
return this.timeChangeWhileStepping;
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.TimingStrategy, "Identity", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'edu.colorado.phet.common.phetcommon.model.clock.TimingStrategy');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.simulationTimeChangeForPausedClock = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$D', function (simulationTimeChangeForPausedClock) {
C$.$init$.apply(this);
this.simulationTimeChangeForPausedClock = simulationTimeChangeForPausedClock;
}, 1);

Clazz.newMeth(C$, 'getSimulationTimeChangeWT$J$J', function (lastWallTime, currentWallTime) {
return (currentWallTime - lastWallTime) / 1000.0;
});

Clazz.newMeth(C$, 'getSimulationTimeChangeForPausedClock', function () {
return this.simulationTimeChangeForPausedClock;
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.TimingStrategy, "Scaled", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'edu.colorado.phet.common.phetcommon.model.clock.TimingStrategy');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.scale = 0;
this.simulationTimeChangeForPausedClock = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$D$D', function (scale, simulationTimeChangeForPausedClock) {
C$.$init$.apply(this);
this.scale = scale;
this.simulationTimeChangeForPausedClock = simulationTimeChangeForPausedClock;
}, 1);

Clazz.newMeth(C$, 'getSimulationTimeChangeWT$J$J', function (lastWallTime, currentWallTime) {
System.out.println$S("TimingStrategy " + new Double(this.scale).toString() + " " + new Double(((currentWallTime - lastWallTime) * this.scale / 1000.0)).toString() );
return (currentWallTime - lastWallTime) * this.scale / 1000.0;
});

Clazz.newMeth(C$, 'getSimulationTimeChangeForPausedClock', function () {
return this.simulationTimeChangeForPausedClock;
});

Clazz.newMeth(C$);
})()
})();
//Created 2018-01-31 11:02:47
