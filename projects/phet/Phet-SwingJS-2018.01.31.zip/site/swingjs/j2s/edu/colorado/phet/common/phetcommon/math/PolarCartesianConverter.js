(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[];
var C$=Clazz.newClass(P$, "PolarCartesianConverter");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getX$D$D', function (radius, angle) {
return radius * Math.cos(angle);
}, 1);

Clazz.newMeth(C$, 'getY$D$D', function (radius, angle) {
return radius * Math.sin(angle);
}, 1);

Clazz.newMeth(C$, 'getRadius$D$D', function (x, y) {
return Math.sqrt((x * x) + (y * y));
}, 1);

Clazz.newMeth(C$, 'getAngle$D$D', function (x, y) {
return Math.atan2(y, x);
}, 1);
})();
//Created 2018-01-31 11:02:46
