(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model"),I$=[['java.util.ArrayList','edu.colorado.phet.common.phetcommon.model.SphereBucket$1$1',['edu.colorado.phet.common.phetcommon.model.IBucketSphere','.Adapter'],'edu.colorado.phet.common.phetcommon.math.vector.Vector2D',['java.awt.geom.Point2D','.Double']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SphereBucket", null, 'edu.colorado.phet.common.phetcommon.model.Bucket');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.containedParticles = null;
this.particleRadius = 0;
this.usableWidthProportion = 0;
this.yOffset = 0;
this.particleRemovalListener = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.containedParticles = Clazz.new_((I$[1]||$incl$(1)));
this.particleRemovalListener = ((
(function(){var C$=Clazz.newClass(P$, "SphereBucket$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load(['edu.colorado.phet.common.phetcommon.model.IBucketSphere','.Adapter']), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['grabbedByUser$TT'], function (particle) {
Clazz.assert(C$, this, function(){return this.b$['edu.colorado.phet.common.phetcommon.model.SphereBucket'].containedParticles.contains$O(particle)});
this.b$['edu.colorado.phet.common.phetcommon.model.SphereBucket'].containedParticles.remove$O(particle);
particle.removeListener$java_util_EventListener(this);
var initialPosition = particle.getDestination();
var r = particle.getRadius();
var d2 = r * r * 2.25 ;
particle.addPositionListener$edu_colorado_phet_common_phetcommon_util_SimpleObserver(((
(function(){var C$=Clazz.newClass(P$, "SphereBucket$1$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.SimpleObserver', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'update', function () {
if (this.$finals.initialPosition.distance2$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D(this.$finals.particle.getDestination()) > this.$finals.d2 ) {
this.b$['edu.colorado.phet.common.phetcommon.model.SphereBucket'].relayoutBucketParticles.apply(this.b$['edu.colorado.phet.common.phetcommon.model.SphereBucket'], []);
this.$finals.particle.removePositionListener$edu_colorado_phet_common_phetcommon_util_SimpleObserver(this);
}});
})()
), Clazz.new_((I$[2]||$incl$(2)).$init$, [this, {initialPosition: initialPosition, particle: particle, d2: d2}])));
});
C$.$_ASSERT_ENABLED_ = ClassLoader.$getClassAssertionStatus(C$);
})()
), Clazz.new_((I$[3]||$incl$(3)), [this, null],P$.SphereBucket$1));
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_geom_Point2D_Double$java_awt_geom_Dimension2D$java_awt_Color$S$D$D$D', function (position, size, baseColor, caption, particleRadius, usableWidthProportion, yOffset) {
C$.superclazz.c$$java_awt_geom_Point2D_Double$java_awt_geom_Dimension2D$java_awt_Color$S.apply(this, [position, size, baseColor, caption]);
C$.$init$.apply(this);
this.particleRadius = particleRadius;
this.usableWidthProportion = usableWidthProportion;
this.yOffset = yOffset;
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_geom_Point2D_Double$java_awt_geom_Dimension2D$java_awt_Color$S$D', function (position, size, baseColor, caption, particleRadius) {
C$.c$$java_awt_geom_Point2D_Double$java_awt_geom_Dimension2D$java_awt_Color$S$D$D$D.apply(this, [position, size, baseColor, caption, particleRadius, 1, 0]);
}, 1);

Clazz.newMeth(C$, 'reset', function () {
this.containedParticles.clear();
});

Clazz.newMeth(C$, 'removeParticle$TT', function (particle) {
if (!this.containedParticles.contains$O(particle)) {
System.err.println$S(this.getClass().getName() + " - Error: Particle not here, can't remove.");
}Clazz.assert(C$, this, function(){return this.containedParticles.contains$O(particle)});
this.containedParticles.remove$O(particle);
particle.removeListener$java_util_EventListener(this.particleRemovalListener);
});

Clazz.newMeth(C$, 'addParticleNearestOpen$TT$Z', function (particle, moveImmediately) {
var nearestOpenLocation = p$.getNearestOpenLocation$edu_colorado_phet_common_phetcommon_math_vector_Vector2D.apply(this, [particle.getPosition()]);
p$.addParticle$TT$java_awt_geom_Point2D$Z.apply(this, [particle, nearestOpenLocation, moveImmediately]);
});

Clazz.newMeth(C$, 'addParticleFirstOpen$TT$Z', function (particle, moveImmediately) {
var firstOpenLocation = p$.getFirstOpenLocation.apply(this, []);
p$.addParticle$TT$java_awt_geom_Point2D$Z.apply(this, [particle, firstOpenLocation, moveImmediately]);
});

Clazz.newMeth(C$, 'addParticle$TT$java_awt_geom_Point2D$Z', function (particle, locationInBucket, moveImmediately) {
if (moveImmediately) {
particle.setPositionAndDestination$edu_colorado_phet_common_phetcommon_math_vector_Vector2D(Clazz.new_((I$[4]||$incl$(4)).c$$java_awt_geom_Point2D,[locationInBucket]));
} else {
particle.setDestination$edu_colorado_phet_common_phetcommon_math_vector_Vector2D(Clazz.new_((I$[4]||$incl$(4)).c$$java_awt_geom_Point2D,[locationInBucket]));
}particle.addListener$java_util_EventListener(this.particleRemovalListener);
this.containedParticles.add$TE(particle);
});

Clazz.newMeth(C$, 'containsParticle$TT', function (particle) {
return this.containedParticles.contains$O(particle);
});

Clazz.newMeth(C$, 'getParticleList', function () {
return this.containedParticles;
});

Clazz.newMeth(C$, 'getFirstOpenLocation', function () {
var openLocation = Clazz.new_((I$[5]||$incl$(5)));
var placeableWidth = this.holeShape.getBounds2D().getWidth() * this.usableWidthProportion - 2 * this.particleRadius;
var offsetFromBucketEdge = (this.holeShape.getBounds2D().getWidth() - placeableWidth) / 2 + this.particleRadius;
var numParticlesInLayer = (Math.floor(placeableWidth / (this.particleRadius * 2))|0);
var row = 0;
var positionInLayer = 0;
var found = false;
while (!found){
var yPos = p$.getYPositionForLayer$I.apply(this, [row]);
var xPos = this.getPosition().getX() - this.holeShape.getBounds2D().getWidth() / 2 + offsetFromBucketEdge + positionInLayer * 2 * this.particleRadius ;
if (p$.isPositionOpen$D$D.apply(this, [xPos, yPos])) {
openLocation.x = xPos;
openLocation.y = yPos;
found = true;
continue;
} else {
positionInLayer++;
if (positionInLayer >= numParticlesInLayer) {
row++;
positionInLayer = 0;
numParticlesInLayer--;
offsetFromBucketEdge += this.particleRadius;
if (numParticlesInLayer == 0) {
numParticlesInLayer = 1;
offsetFromBucketEdge -= this.particleRadius;
}}}}
return openLocation;
});

Clazz.newMeth(C$, 'getNearestOpenLocation$edu_colorado_phet_common_phetcommon_math_vector_Vector2D', function (currentLocation) {
var highestOccupiedLayer = 0;
for (var particle, $particle = this.containedParticles.iterator(); $particle.hasNext()&&((particle=$particle.next()),1);) {
var layer = p$.getLayerForYPosition$D.apply(this, [particle.getPosition().getY()]);
if (layer > highestOccupiedLayer) {
highestOccupiedLayer = layer;
}}
var openLocationsInRow = Clazz.new_((I$[1]||$incl$(1)));
var placeableWidth = this.holeShape.getBounds2D().getWidth() * this.usableWidthProportion - 2 * this.particleRadius;
var offsetFromBucketEdge = (this.holeShape.getBounds2D().getWidth() - placeableWidth) / 2 + this.particleRadius;
var numParticlesInLayer = (Math.floor(placeableWidth / (this.particleRadius * 2))|0);
for (var layer = 0; layer <= highestOccupiedLayer + 1; layer++) {
for (var positionInLayer = 0; positionInLayer < numParticlesInLayer; positionInLayer++) {
var yPos = p$.getYPositionForLayer$I.apply(this, [layer]);
var xPos = this.getPosition().getX() - this.holeShape.getBounds2D().getWidth() / 2 + offsetFromBucketEdge + positionInLayer * 2 * this.particleRadius ;
if (p$.isPositionOpen$D$D.apply(this, [xPos, yPos])) {
if (layer == 0 || p$.countSupportingParticles$java_awt_geom_Point2D.apply(this, [Clazz.new_((I$[5]||$incl$(5)).c$$D$D,[xPos, yPos])]) == 2 ) {
openLocationsInRow.add$TE(Clazz.new_((I$[5]||$incl$(5)).c$$D$D,[xPos, yPos]));
}}}
numParticlesInLayer--;
offsetFromBucketEdge += this.particleRadius;
if (numParticlesInLayer == 0) {
numParticlesInLayer = 1;
offsetFromBucketEdge -= this.particleRadius;
}}
Clazz.assert(C$, this, function(){return !openLocationsInRow.isEmpty()});
var closestOpenLocation = openLocationsInRow.get$I(0);
for (var openLocation, $openLocation = openLocationsInRow.iterator(); $openLocation.hasNext()&&((openLocation=$openLocation.next()),1);) {
if (Math.abs(openLocation.getX() - currentLocation.getX()) < Math.abs(closestOpenLocation.getX() - currentLocation.getX()) ) {
closestOpenLocation = openLocation;
}}
return closestOpenLocation;
});

Clazz.newMeth(C$, 'getLayerForYPosition$D', function (yPosition) {
return (Math.round((yPosition - this.getPosition().getY() - this.yOffset ) / (this.particleRadius * 2 * 0.866 ))|0);
});

Clazz.newMeth(C$, 'getYPositionForLayer$I', function (row) {
return this.getPosition().getY() + row * this.particleRadius * 2 * 0.866  + this.yOffset;
});

Clazz.newMeth(C$, 'relayoutBucketParticles', function () {
var copyOfContainedParticles = Clazz.new_((I$[1]||$incl$(1)).c$$java_util_Collection,[this.containedParticles]);
for (var containedParticle, $containedParticle = copyOfContainedParticles.iterator(); $containedParticle.hasNext()&&((containedParticle=$containedParticle.next()),1);) {
if (p$.isDangling$TT.apply(this, [containedParticle])) {
this.removeParticle$TT(containedParticle);
this.addParticleNearestOpen$TT$Z(containedParticle, false);
p$.relayoutBucketParticles.apply(this, []);
}}
});

Clazz.newMeth(C$, 'isDangling$TT', function (particle) {
var onBottomRow = particle.getDestination().getY() == p$.getYPositionForLayer$I.apply(this, [0]) ;
return !onBottomRow && p$.countSupportingParticles$TT.apply(this, [particle]) < 2 ;
});

Clazz.newMeth(C$, 'countSupportingParticles$TT', function (p) {
var count = 0;
var d2 = p.getRadius() * 3;
d2 *= d2;
var pt = p.getDestination();
var y = pt.getY();
for (var i = this.containedParticles.size(); --i >= 0; ) {
var particle = this.containedParticles.get$I(i);
var pdest;
if (particle !== p  && (pdest = particle.getDestination()).getY() < y   && pdest.distance2$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D(pt) < d2  ) {
count++;
}}
return count;
});

Clazz.newMeth(C$, 'countSupportingParticles$java_awt_geom_Point2D', function (particleLocation) {
var count = 0;
var r;
var y = particleLocation.getY();
var dest;
for (var i = this.containedParticles.size(); --i >= 0; ) {
var particle = this.containedParticles.get$I(i);
if (!particle.getPosition().equals$O(particle) && (dest = particle.getDestination()).getY() < y   && dest.distance2p$java_awt_geom_Point2D(particleLocation) < (r = particle.getRadius()) * r * 9   ) {
count++;
}}
return count;
});

Clazz.newMeth(C$, 'isPositionOpen$D$D', function (x, y) {
var positionOpen = true;
for (var particle, $particle = this.containedParticles.iterator(); $particle.hasNext()&&((particle=$particle.next()),1);) {
var position = particle.getDestination();
if (position.getX() == x  && position.getY() == y  ) {
positionOpen = false;
break;
}}
return positionOpen;
});
C$.$_ASSERT_ENABLED_ = ClassLoader.$getClassAssertionStatus(C$);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:47
