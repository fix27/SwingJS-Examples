(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[['java.lang.StringBuffer']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Dimension3D");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.width = 0;
this.height = 0;
this.depth = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$D$D$D.apply(this, [0, 0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$D$D$D', function (width, height, depth) {
C$.$init$.apply(this);
this.width = width;
this.height = height;
this.depth = depth;
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_Dimension3D', function (d) {
C$.c$$D$D$D.apply(this, [d.getWidth(), d.getHeight(), d.getDepth()]);
}, 1);

Clazz.newMeth(C$, 'getWidth', function () {
return this.width;
});

Clazz.newMeth(C$, 'getHeight', function () {
return this.height;
});

Clazz.newMeth(C$, 'getDepth', function () {
return this.depth;
});

Clazz.newMeth(C$, 'setSize$D$D$D', function (width, height, depth) {
this.width = width;
this.height = height;
this.depth = depth;
});

Clazz.newMeth(C$, 'equals$O', function (o) {
var equals = false;
if (o != null  && Clazz.instanceOf(o, "edu.colorado.phet.common.phetcommon.math.Dimension3D") ) {
var d = o;
equals = (d.getWidth() == this.width  && d.getHeight() == this.height   && d.getDepth() == this.depth  );
}return equals;
});

Clazz.newMeth(C$, 'toString', function () {
var result = Clazz.new_((I$[1]||$incl$(1)));
result.append$S(C$.superclazz.prototype.toString.apply(this, []).replaceAll$S$S(".*\\.", ""));
result.append$C("[");
result.append$D(this.width);
result.append$S(",");
result.append$D(this.height);
result.append$S(",");
result.append$D(this.depth);
result.append$C("]");
return result.toString();
});
})();
//Created 2018-01-31 11:02:45
