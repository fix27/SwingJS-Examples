(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.state"),I$=[['edu.colorado.phet.common.phetcommon.view.util.BufferedImageUtils','java.awt.image.BufferedImage']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ImageFactory");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.image = null;
this.count = 0;
this.numTimes = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.numTimes = 10;
}, 1);

Clazz.newMeth(C$, 'getThumbnail$edu_colorado_phet_common_phetcommon_view_PhetFrame$I', function (frame, width) {
return (I$[1]||$incl$(1)).multiScaleToWidth$java_awt_image_BufferedImage$I(this.toImage$javax_swing_JFrame(frame), width);
});

Clazz.newMeth(C$, 'toImage$javax_swing_JFrame', function (frame) {
this.count++;
if (this.image == null  || this.image.getWidth() != frame.getWidth()  || this.image.getHeight() != frame.getHeight() ) {
this.image = Clazz.new_((I$[2]||$incl$(2)).c$$I$I$I,[frame.getWidth(), frame.getHeight(), 1]);
System.out.println$S("new image created");
}if (this.count % this.numTimes == 0) {
var g2 = this.image.createGraphics();
frame.getContentPane().paint$java_awt_Graphics(g2);
g2.dispose();
}return this.image;
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:51
