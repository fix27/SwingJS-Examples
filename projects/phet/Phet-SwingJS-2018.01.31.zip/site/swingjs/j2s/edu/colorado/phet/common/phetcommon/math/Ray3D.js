(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[['edu.colorado.phet.common.phetcommon.math.PlaneD',['edu.colorado.phet.common.phetcommon.util.Option','.None'],['edu.colorado.phet.common.phetcommon.util.Option','.Some']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Ray3D");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.pos = null;
this.dir = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D', function (pos, dir) {
C$.$init$.apply(this);
this.pos = pos;
this.dir = dir.magnitude() == 1  ? dir : dir.normalized();
}, 1);

Clazz.newMeth(C$, 'shifted$D', function (distance) {
return Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D,[this.pointAtDistance$D(distance), this.dir]);
});

Clazz.newMeth(C$, 'pointAtDistance$D', function (distance) {
return this.pos.plus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3D(this.dir.times$D(distance));
});

Clazz.newMeth(C$, 'distanceToPlane$edu_colorado_phet_common_phetcommon_math_PlaneD', function (plane) {
return (plane.distance - this.pos.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3D(plane.normal)) / this.dir.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3D(plane.normal);
});

Clazz.newMeth(C$, 'toString', function () {
return this.pos.toString() + " => " + this.dir.toString() ;
});

Clazz.newMeth(C$, 'intersectWithTriangle$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D', function (a, b, c) {
var plane = (I$[1]||$incl$(1)).fromTriangle$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D(a, b, c);
if (plane == null ) {
return Clazz.new_((I$[2]||$incl$(2)));
}var planePoint = plane.intersectWithRay$edu_colorado_phet_common_phetcommon_math_Ray3D(this);
var hit = C$.approximateCoplanarPointInTriangle$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D(a, b, c, planePoint);
return hit ? Clazz.new_((I$[3]||$incl$(3)).c$$TT,[planePoint]) : Clazz.new_((I$[2]||$incl$(2)));
});

Clazz.newMeth(C$, 'approximateCoplanarPointInTriangle$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D', function (a, b, c, point) {
var areaA = C$.triangleXYArea$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D(point, b, c);
var areaB = C$.triangleXYArea$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D(point, c, a);
var areaC = C$.triangleXYArea$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D(point, a, b);
var insideArea = C$.triangleXYArea$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D(a, b, c);
return areaA + areaB + areaC  <= insideArea * 1.02 ;
}, 1);

Clazz.newMeth(C$, 'triangleXYArea$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D', function (a, b, c) {
return Math.abs(((a.getX() - c.getX()) * (b.getY() - c.getY()) - (b.getX() - c.getX()) * (a.getY() - c.getY())) / 2);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:46
