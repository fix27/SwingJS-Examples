(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.messages"),I$=[];
var C$=Clazz.newClass(P$, "UserMessage", null, 'edu.colorado.phet.common.phetcommon.simsharing.SimSharingMessage');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IMessageType$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponentType$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserAction$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet', function (messageType, userComponent, userComponentType, action, parameters) {
C$.superclazz.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IMessageType$TT$TU$TV$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet.apply(this, [messageType, userComponent, userComponentType, action, parameters]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:51
