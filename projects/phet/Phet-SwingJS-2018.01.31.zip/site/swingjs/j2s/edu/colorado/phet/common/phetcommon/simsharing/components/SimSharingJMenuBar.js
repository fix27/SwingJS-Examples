(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.components"),I$=[['edu.colorado.phet.common.phetcommon.resources.PhetCommonResources','java.awt.GradientPaint','java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SimSharingJMenuBar", null, 'javax.swing.JMenuBar');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.networkTransmitImage = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.networkTransmitImage = (I$[1]||$incl$(1)).getImage$S("status/network/network-transmit-2.png");
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics', function (g) {
C$.superclazz.prototype.paintComponent$java_awt_Graphics.apply(this, [g]);
var g2 = g;
var fractionToStartIndicator = 0.7;
g2.setPaint$java_awt_Paint(Clazz.new_((I$[2]||$incl$(2)).c$$F$F$java_awt_Color$F$F$java_awt_Color,[this.getWidth() * fractionToStartIndicator, 0, Clazz.new_((I$[3]||$incl$(3)).c$$I$I$I$I,[0, 0, 0, 0]), this.getWidth(), 0, Clazz.new_((I$[3]||$incl$(3)).c$$I$I$I$I,[0, 255, 0, 150])]));
g2.fillRect$I$I$I$I(((this.getWidth() * fractionToStartIndicator)|0), 0, (this.getWidth()/2|0), this.getHeight());
g2.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.networkTransmitImage, this.getWidth() - this.networkTransmitImage.getWidth() - 5 , (this.getHeight()/2|0) - (this.networkTransmitImage.getHeight()/2|0), null);
});
})();
//Created 2018-01-31 11:02:50
