(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.messages"),I$=[['java.util.ArrayList','java.util.Arrays','edu.colorado.phet.common.phetcommon.simsharing.messages.Parameter','edu.colorado.phet.common.phetcommon.util.ObservableList','edu.colorado.phet.common.phetcommon.simsharing.messages.ParameterKeys']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ParameterSet", null, null, 'Iterable');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.parameters = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$java_util_ArrayList.apply(this, [Clazz.new_((I$[1]||$incl$(1)))]);
}, 1);

Clazz.newMeth(C$, 'c$$java_util_ArrayList', function (parameters) {
C$.$init$.apply(this);
this.parameters = parameters;
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_Parameter', function (parameter) {
C$.c$$java_util_ArrayList.apply(this, [((
(function(){var C$=Clazz.newClass(P$, "ParameterSet$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.util.ArrayList'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
{
this.add$TE(this.$finals.parameter);
}
}, 1);
})()
), Clazz.new_((I$[1]||$incl$(1)), [this, {parameter: parameter}],P$.ParameterSet$1))]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterA', function (parameters) {
C$.c$$java_util_ArrayList.apply(this, [Clazz.new_((I$[1]||$incl$(1)).c$$java_util_Collection,[(I$[2]||$incl$(2)).asList$TTA(parameters)])]);
}, 1);

Clazz.newMeth(C$, 'parameterSet$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$D', function (name, value) {
return Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_Parameter,[Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$D,[name, value])]);
}, 1);

Clazz.newMeth(C$, 'parameterSet$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterValue', function (name, value) {
return Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_Parameter,[Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterValue,[name, value])]);
}, 1);

Clazz.newMeth(C$, 'parameterSet$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$Z', function (name, value) {
return Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_Parameter,[Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$Z,[name, value])]);
}, 1);

Clazz.newMeth(C$, 'parameterSetLong$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$J', function (name, value) {
return Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_Parameter,[Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$J$I,[name, value, 0])]);
}, 1);

Clazz.newMeth(C$, 'parameterSet$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$S', function (name, value) {
return Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_Parameter,[Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$S,[name, value])]);
}, 1);

Clazz.newMeth(C$, 'getValue$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey', function (name) {
return this.get$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey(name).value;
});

Clazz.newMeth(C$, 'get$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey', function (name) {
for (var parameter, $parameter = this.parameters.iterator(); $parameter.hasNext()&&((parameter=$parameter.next()),1);) {
if (parameter.name.equals$O(name)) {
return parameter;
}}
return null;
});

Clazz.newMeth(C$, 'containsKey$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey', function (name) {
return this.get$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey(name) != null ;
});

Clazz.newMeth(C$, 'toString$S', function (delimiter) {
return Clazz.new_((I$[4]||$incl$(4)).c$$java_util_Collection,[this.parameters]).mkString$S(delimiter);
});

Clazz.newMeth(C$, '$with$edu_colorado_phet_common_phetcommon_simsharing_messages_Parameter', function (parameter) {
if (p$.containsKey$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey.apply(this, [parameter.name])) {
if (!p$.getValue$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey.apply(this, [parameter.name]).equals$O(parameter.value)) {
throw Clazz.new_(Clazz.load('java.lang.RuntimeException').c$$S,["Parameter name already contained with different value: " + this.get$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey(parameter.name) + ", newValue = " + parameter.value ]);
} else {
return this;
}} else {
return Clazz.new_(C$.c$$java_util_ArrayList,[((
(function(){var C$=Clazz.newClass(P$, "ParameterSet$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.util.ArrayList'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
{
this.add$TE(this.$finals.parameter);
}
}, 1);
})()
), Clazz.new_((I$[1]||$incl$(1)).c$$java_util_Collection, [this, {parameter: parameter}, this.parameters],P$.ParameterSet$2))]);
}});

Clazz.newMeth(C$, '$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterValue', function (name, value) {
return this.$with$edu_colorado_phet_common_phetcommon_simsharing_messages_Parameter(Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterValue,[name, value]));
});

Clazz.newMeth(C$, '$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$Z', function (name, value) {
return this.$with$edu_colorado_phet_common_phetcommon_simsharing_messages_Parameter(Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$Z,[name, value]));
});

Clazz.newMeth(C$, '$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$D', function (name, value) {
return this.$with$edu_colorado_phet_common_phetcommon_simsharing_messages_Parameter(Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$D,[name, value]));
});

Clazz.newMeth(C$, '$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$S', function (name, value) {
return this.$with$edu_colorado_phet_common_phetcommon_simsharing_messages_Parameter(Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$S,[name, value]));
});

Clazz.newMeth(C$, '$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$I', function (name, value) {
return this.$with$edu_colorado_phet_common_phetcommon_simsharing_messages_Parameter(Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$D,[name, value]));
});

Clazz.newMeth(C$, '$with$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterA', function (parameters) {
var p = this;
for (var parameter, $parameter = 0, $$parameter = parameters; $parameter<$$parameter.length&&((parameter=$$parameter[$parameter]),1);$parameter++) {
p = p.$with$edu_colorado_phet_common_phetcommon_simsharing_messages_Parameter(parameter);
}
return p;
});

Clazz.newMeth(C$, '$with$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet', function (param) {
return this.$with$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterA(param.parameters.toArray$TTA(Clazz.array((I$[3]||$incl$(3)), [param.parameters.size()])));
});

Clazz.newMeth(C$, 'iterator', function () {
return this.parameters.iterator();
});

Clazz.newMeth(C$, 'main', function (args) {
var set1 = C$.parameterSetLong$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$J((I$[5]||$incl$(5)).value, 1).$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$I((I$[5]||$incl$(5)).x, 2).$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$I((I$[5]||$incl$(5)).y, 2);
var set2 = ((
(function(){var C$=Clazz.newClass(P$, "ParameterSet$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('edu.colorado.phet.common.phetcommon.simsharing.messages.ParameterSet'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
{
this.$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$I((I$[5]||$incl$(5)).value, 1);
this.$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$I((I$[5]||$incl$(5)).x, 2);
this.$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$I((I$[5]||$incl$(5)).y, 2);
}
}, 1);
})()
), Clazz.new_(C$, [this, null],P$.ParameterSet$3));
var delimiter = " ";
Clazz.assert(C$, this, function(){return (set1.toString$S(" ").equals$O(set2.toString$S(" ")))});
System.out.print$S("test passed, happy days!");
}, 1);
C$.$_ASSERT_ENABLED_ = ClassLoader.$getClassAssertionStatus(C$);
})();
//Created 2018-01-31 11:02:51
