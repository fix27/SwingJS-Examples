(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.application"),I$=[['Thread','java.io.BufferedReader','java.io.InputStreamReader','edu.colorado.phet.common.phetcommon.resources.PhetProperties']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SoftwareAgreement");
C$.instance = null;
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.version = 0;
this.content = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
var p = p$.readProperties.apply(this, []);
this.version = p.getInt$S$I("version", -1);
try {
this.content = p$.readContent.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.io.IOException")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'readContent', function () {
var inStream = (I$[1]||$incl$(1)).currentThread().getContextClassLoader().getResourceAsStream$S("software-agreement.htm");
var bufferedReader = Clazz.new_((I$[2]||$incl$(2)).c$$java_io_Reader,[Clazz.new_((I$[3]||$incl$(3)).c$$java_io_InputStream,[inStream])]);
var s = "";
var line = bufferedReader.readLine();
while (line != null ){
s += line + "\n";
line = bufferedReader.readLine();
}
return s;
});

Clazz.newMeth(C$, 'getInstance', function () {
if (C$.instance == null ) {
C$.instance = Clazz.new_(C$);
}return C$.instance;
}, 1);

Clazz.newMeth(C$, 'getVersion', function () {
return this.version;
});

Clazz.newMeth(C$, 'getContent', function () {
return this.content;
});

Clazz.newMeth(C$, 'readProperties', function () {
var p = Clazz.new_((I$[4]||$incl$(4)));
var inStream = (I$[1]||$incl$(1)).currentThread().getContextClassLoader().getResourceAsStream$S("software-agreement.properties");
if (inStream != null ) {
try {
p.load$java_io_InputStream(inStream);
} catch (e) {
if (Clazz.exceptionOf(e, "java.io.IOException")){
System.err.println$S("exception reading software agreement: software-agreement.properties");
e.printStackTrace();
} else {
throw e;
}
}
} else {
System.err.println$S("missing software agreement: software-agreement.properties");
}return p;
});
})();
//Created 2018-01-31 11:02:45
