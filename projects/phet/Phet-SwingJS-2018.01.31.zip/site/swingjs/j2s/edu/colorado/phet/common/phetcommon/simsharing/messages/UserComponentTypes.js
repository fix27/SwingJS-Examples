(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.messages"),I$=[];
var C$=Clazz.newClass(P$, "UserComponentTypes", null, 'Enum', 'edu.colorado.phet.common.phetcommon.simsharing.messages.IUserComponentType');

C$.$clinit$ = function() {Clazz.load(C$, 1);
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "unknown", 0, []);
Clazz.newEnumConst($vals, C$.c$, "button", 1, []);
Clazz.newEnumConst($vals, C$.c$, "checkBox", 2, []);
Clazz.newEnumConst($vals, C$.c$, "menuItem", 3, []);
Clazz.newEnumConst($vals, C$.c$, "radioButton", 4, []);
Clazz.newEnumConst($vals, C$.c$, "spinner", 5, []);
Clazz.newEnumConst($vals, C$.c$, "checkBoxMenuItem", 6, []);
Clazz.newEnumConst($vals, C$.c$, "icon", 7, []);
Clazz.newEnumConst($vals, C$.c$, "menu", 8, []);
Clazz.newEnumConst($vals, C$.c$, "tab", 9, []);
Clazz.newEnumConst($vals, C$.c$, "sprite", 10, []);
Clazz.newEnumConst($vals, C$.c$, "popupMenuItem", 11, []);
Clazz.newEnumConst($vals, C$.c$, "toggleButton", 12, []);
Clazz.newEnumConst($vals, C$.c$, "slider", 13, []);
Clazz.newEnumConst($vals, C$.c$, "jmolViewer", 14, []);
Clazz.newEnumConst($vals, C$.c$, "comboBox", 15, []);
Clazz.newEnumConst($vals, C$.c$, "popup", 16, []);
Clazz.newEnumConst($vals, C$.c$, "dialog", 17, []);
Clazz.newEnumConst($vals, C$.c$, "popupCheckBoxMenuItem", 18, []);
Clazz.newEnumConst($vals, C$.c$, "textField", 19, []);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values', function() { return $vals }, 1);
})();
//Created 2018-01-31 11:02:51
