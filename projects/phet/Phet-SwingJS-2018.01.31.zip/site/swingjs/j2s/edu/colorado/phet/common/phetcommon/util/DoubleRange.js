(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.util"),I$=[];
var C$=Clazz.newClass(P$, "DoubleRange");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._min = 0;
this._max = 0;
this._default = 0;
this._significantDecimalPlaces = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$D$D', function (min, max) {
C$.c$$D$D$D$I.apply(this, [min, max, min, 2147483647]);
}, 1);

Clazz.newMeth(C$, 'c$$D$D$D', function (min, max, defaultValue) {
C$.c$$D$D$D$I.apply(this, [min, max, defaultValue, 2147483647]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_util_IntegerRange', function (range) {
C$.c$$D$D$D.apply(this, [range.getMin(), range.getMax(), range.getDefault()]);
}, 1);

Clazz.newMeth(C$, 'c$$D$D$D$I', function (min, max, defaultValue, significantDecimalPlaces) {
C$.$init$.apply(this);
if (!(min <= max )) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["min must be <= max: min = " + new Double(min).toString() + ", max = " + new Double(max).toString() ]);
}if (defaultValue < min  || defaultValue > max  ) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["defaultValue out of range: min = " + new Double(min).toString() + ", max = " + new Double(max).toString() + ", defaultValue = " + new Double(defaultValue).toString() ]);
}if (significantDecimalPlaces < 0) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["significantDecimalPlaces < 0: " + significantDecimalPlaces]);
}this._min = min;
this._max = max;
this._default = defaultValue;
this._significantDecimalPlaces = significantDecimalPlaces;
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_util_DoubleRange', function (range) {
C$.c$$D$D$D$I.apply(this, [range.getMin(), range.getMax(), range.getDefault(), range.getSignificantDecimalPlaces()]);
}, 1);

Clazz.newMeth(C$, 'getMin', function () {
return this._min;
});

Clazz.newMeth(C$, 'getMax', function () {
return this._max;
});

Clazz.newMeth(C$, 'getDefault', function () {
return this._default;
});

Clazz.newMeth(C$, 'getSignificantDecimalPlaces', function () {
return this._significantDecimalPlaces;
});

Clazz.newMeth(C$, 'contains$D', function (value) {
return (value >= this._min  && value <= this._max  );
});

Clazz.newMeth(C$, 'containsExclusive$D', function (value) {
return (value > this._min  && value < this._max  );
});

Clazz.newMeth(C$, 'getLength', function () {
return this._max - this._min;
});

Clazz.newMeth(C$, 'isZero', function () {
return (this._max - this._min == 0 );
});

Clazz.newMeth(C$, 'intersects$edu_colorado_phet_common_phetcommon_util_DoubleRange', function (xRange) {
return (this._max >= xRange.getMin()  && xRange.getMax() >= this._min  );
});

Clazz.newMeth(C$, 'intersectsExclusive$edu_colorado_phet_common_phetcommon_util_DoubleRange', function (xRange) {
return (this._max > xRange.getMin()  && xRange.getMax() > this._min  );
});

Clazz.newMeth(C$, 'getCenter', function () {
return (this._max + this._min) / 2;
});

Clazz.newMeth(C$, 'toString', function () {
return "min=" + new Double(this._min).toString() + ", max=" + new Double(this._max).toString() + ", default=" + new Double(this._default).toString() + ", significantDecimalPlaces=" + this._significantDecimalPlaces ;
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:51
