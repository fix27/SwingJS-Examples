(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.event"),I$=[];
var C$=Clazz.newClass(P$, "ValueNotifier", null, 'edu.colorado.phet.common.phetcommon.model.event.Notifier');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.value = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['c$$TT'], function (value) {
Clazz.super_(C$, this,1);
this.value = value;
}, 1);

Clazz.newMeth(C$, 'updateListeners', function () {
this.updateListeners$TT(this.value);
});

Clazz.newMeth(C$, 'getValue', function () {
return this.value;
});

Clazz.newMeth(C$, ['setValue$TT'], function (value) {
this.value = value;
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:48
