(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.state"),I$=[['javax.imageio.ImageIO','java.io.ByteArrayInputStream','java.io.ByteArrayOutputStream','java.util.Arrays']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SerializableBufferedImage", null, null, 'edu.colorado.phet.common.phetcommon.util.IProguardKeepClass');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.byteArray = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_image_BufferedImage', function (bufferedImage) {
C$.c$$java_awt_image_BufferedImage$S.apply(this, [bufferedImage, "JPG"]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_image_BufferedImage$S', function (bufferedImage, format) {
C$.$init$.apply(this);
this.byteArray = C$.toByteArray$java_awt_image_BufferedImage$S(bufferedImage, format);
}, 1);

Clazz.newMeth(C$, 'toBufferedImage', function () {
return C$.fromByteArray$BA(this.byteArray);
});

Clazz.newMeth(C$, 'fromByteArray$BA', function (byteArray) {
try {
return (I$[1]||$incl$(1)).read$java_io_InputStream(Clazz.new_((I$[2]||$incl$(2)).c$$BA,[byteArray]));
} catch (e) {
if (Clazz.exceptionOf(e, "java.io.IOException")){
throw Clazz.new_(Clazz.load('java.lang.RuntimeException').c$$Throwable,[e]);
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'toByteArray$java_awt_image_BufferedImage$S', function (bufferedImage, format) {
try {
return ((
(function(){var C$=Clazz.newClass(P$, "SerializableBufferedImage$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.io.ByteArrayOutputStream'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
{
(I$[1]||$incl$(1)).write$java_awt_image_RenderedImage$S$java_io_OutputStream(this.$finals.bufferedImage, this.$finals.format, this);
}
}, 1);
})()
), Clazz.new_((I$[3]||$incl$(3)), [this, {bufferedImage: bufferedImage, format: format}],P$.SerializableBufferedImage$1)).toByteArray();
} catch (e) {
if (Clazz.exceptionOf(e, "java.io.IOException")){
throw Clazz.new_(Clazz.load('java.lang.RuntimeException').c$$Throwable,[e]);
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'toString', function () {
return "SerializableBufferedImage{byteArray=" + (I$[4]||$incl$(4)).toString$BA(this.byteArray) + '}' ;
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:51
