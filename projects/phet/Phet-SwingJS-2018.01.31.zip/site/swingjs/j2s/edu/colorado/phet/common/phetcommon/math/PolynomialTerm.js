(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[['java.util.regex.Pattern']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "PolynomialTerm");
C$.ZERO = null;
C$.EXPR_PATTERN = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.ZERO = Clazz.new_(C$.c$$I$I,[0, 0]);
C$.EXPR_PATTERN = (I$[1]||$incl$(1)).compile$S("([+\\-])? *(\\d+)x\\^(\\d+)");
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.power = 0;
this.coeff = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I$I', function (power, coeff) {
C$.$init$.apply(this);
this.power = power;
this.coeff = coeff;
if (power < 0) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException'));
}}, 1);

Clazz.newMeth(C$, 'c$$I', function (constant) {
C$.c$$I$I.apply(this, [0, constant]);
}, 1);

Clazz.newMeth(C$, 'parsePolynomialTerm$S', function (expression) {
var matcher = C$.EXPR_PATTERN.matcher$CharSequence(expression);
if (matcher.find()) {
var sign = 1;
var signString = matcher.group$I(1);
if (signString != null  && signString.equals$O("-") ) {
sign = -1;
}var coeff = Integer.parseInt(matcher.group$I(2));
var power = Integer.parseInt(matcher.group$I(3));
return Clazz.new_(C$.c$$I$I,[power, coeff * sign]);
} else {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException'));
}}, 1);

Clazz.newMeth(C$, 'getPower', function () {
return this.power;
});

Clazz.newMeth(C$, 'getCoeff', function () {
return this.coeff;
});

Clazz.newMeth(C$, 'derive$I', function (numDer) {
var term = this;
for (var i = 0; i < numDer; i++) {
term = term.derive();
}
return term;
});

Clazz.newMeth(C$, 'derive', function () {
if (this.power == 0) {
return C$.ZERO;
} else {
return Clazz.new_(C$.c$$I$I,[this.power - 1, this.coeff * this.power]);
}});

Clazz.newMeth(C$, 'eval$D', function (x) {
return Math.pow(x, this.power) * this.coeff;
});

Clazz.newMeth(C$, 'times$edu_colorado_phet_common_phetcommon_math_PolynomialTerm', function (that) {
return Clazz.new_(C$.c$$I$I,[this.power + that.power, this.coeff * that.coeff]);
});

Clazz.newMeth(C$, 'plus$edu_colorado_phet_common_phetcommon_math_PolynomialTerm', function (that) {
if (this.power == that.power) {
return Clazz.new_(C$.c$$I$I,[this.power, this.coeff + that.coeff]);
} else {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException'));
}});

Clazz.newMeth(C$, 'toString', function () {
return this.coeff + "x^" + this.power ;
});

Clazz.newMeth(C$, 'equals$O', function (o) {
if (this === o ) {
return true;
}if (o == null  || this.getClass() !== o.getClass()  ) {
return false;
}var that = o;
if (this.coeff != that.coeff) {
return false;
}if (this.power != that.power) {
return false;
}return true;
});

Clazz.newMeth(C$, 'hashCode', function () {
var result;
result = this.power;
result = 31 * result + this.coeff;
return result;
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:46
