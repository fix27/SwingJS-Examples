(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.resources"),I$=[['java.text.MessageFormat','java.text.SimpleDateFormat','java.util.Date']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "PhetVersion");
C$.FORMAT_TIMESTAMP = null;
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.major = null;
this.minor = null;
this.dev = null;
this.revision = null;
this.timestamp = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S$S$S$S$S', function (major, minor, dev, revision, timestamp) {
C$.$init$.apply(this);
this.major = C$.cleanup$S(major);
this.minor = C$.cleanup$S(minor);
this.dev = C$.cleanup$S(dev);
this.revision = C$.cleanup$S(revision);
this.timestamp = C$.cleanup$S(timestamp);
}, 1);

Clazz.newMeth(C$, 'getMajor', function () {
return this.major;
});

Clazz.newMeth(C$, 'getMajorAsInt', function () {
return C$.getAsInt$S(this.getMajor());
});

Clazz.newMeth(C$, 'getMinor', function () {
return this.minor;
});

Clazz.newMeth(C$, 'getMinorAsInt', function () {
return C$.getAsInt$S(this.getMinor());
});

Clazz.newMeth(C$, 'getDev', function () {
return this.dev;
});

Clazz.newMeth(C$, 'getDevAsInt', function () {
return C$.getAsInt$S(this.getDev());
});

Clazz.newMeth(C$, 'getRevision', function () {
return this.revision;
});

Clazz.newMeth(C$, 'getRevisionAsInt', function () {
return C$.getAsInt$S(this.getRevision());
});

Clazz.newMeth(C$, 'isDevVersion', function () {
return this.getDevAsInt() != 0;
});

Clazz.newMeth(C$, 'formatForTitleBar', function () {
return p$.isDevVersion.apply(this, []) ? this.formatMajorMinorDev() : this.formatMajorMinor();
});

Clazz.newMeth(C$, 'formatForAboutDialog', function () {
var args = Clazz.array(java.lang.Object, -1, [this.major, this.minor, this.dev, this.revision, this.formatTimestamp()]);
return (I$[1]||$incl$(1)).format$S$OA("{0}.{1}.{2} ({3})", args);
});

Clazz.newMeth(C$, 'formatTimestamp', function () {
var s = "?";
if (this.timestamp != null  && this.timestamp.length$() > 0 ) {
if (C$.FORMAT_TIMESTAMP == null ) C$.FORMAT_TIMESTAMP = Clazz.new_((I$[2]||$incl$(2)).c$$S,["MMM d, yyyy"]);
var seconds = this.getTimestampSeconds();
if (seconds > 0) {
var date = Clazz.new_((I$[3]||$incl$(3)),[seconds * 1000]);
s = C$.FORMAT_TIMESTAMP.format$java_util_Date(date);
}}return s;
});

Clazz.newMeth(C$, 'formatMajorMinorDev', function () {
var args = Clazz.array(java.lang.Object, -1, [this.major, this.minor, this.dev]);
return (I$[1]||$incl$(1)).format$S$OA("{0}.{1}.{2}", args);
});

Clazz.newMeth(C$, 'formatMajorMinor', function () {
var args = Clazz.array(java.lang.Object, -1, [this.major, this.minor]);
return (I$[1]||$incl$(1)).format$S$OA("{0}.{1}", args);
});

Clazz.newMeth(C$, 'toString', function () {
return this.formatForAboutDialog();
});

Clazz.newMeth(C$, 'equals$O', function (o) {
if (this === o ) {
return true;
}if (o == null  || this.getClass() !== o.getClass()  ) {
return false;
}var that = o;
return this.dev.equals$O(that.dev) && this.major.equals$O(that.major) && this.minor.equals$O(that.minor) && this.revision.equals$O(that.revision)  ;
});

Clazz.newMeth(C$, 'hashCode', function () {
var result;
result = this.major.hashCode();
result = 31 * result + this.minor.hashCode();
result = 31 * result + this.dev.hashCode();
result = 31 * result + this.revision.hashCode();
return result;
});

Clazz.newMeth(C$, 'cleanup$S', function (input) {
var output = input;
if (input == null ) {
output = "?";
}return output;
}, 1);

Clazz.newMeth(C$, 'getAsInt$S', function (number) {
var i = 0;
try {
i = Integer.parseInt(number);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.NumberFormatException")){
e.printStackTrace();
i = -1;
} else {
throw e;
}
}
return i;
}, 1);

Clazz.newMeth(C$, 'isGreaterThan$edu_colorado_phet_common_phetcommon_resources_PhetVersion', function (version) {
return this.getRevisionAsInt() > version.getRevisionAsInt();
});

Clazz.newMeth(C$, 'getTimestampSeconds', function () {
var seconds = 0;
try {
seconds = Long.parseLong(this.timestamp);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.NumberFormatException")){
System.err.println$S("PhetVersion.getTimestampSeconds: timestamp is invalid, ignoring: " + this.timestamp);
seconds = 0;
} else {
throw e;
}
}
return seconds;
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:49
