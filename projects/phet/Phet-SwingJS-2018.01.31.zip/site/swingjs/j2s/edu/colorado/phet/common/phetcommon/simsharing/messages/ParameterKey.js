(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.messages"),I$=[];
var C$=Clazz.newClass(P$, "ParameterKey", null, null, 'edu.colorado.phet.common.phetcommon.simsharing.messages.IParameterKey');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.id = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (id) {
C$.$init$.apply(this);
this.id = id;
}, 1);

Clazz.newMeth(C$, 'toString', function () {
return this.id;
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:50
