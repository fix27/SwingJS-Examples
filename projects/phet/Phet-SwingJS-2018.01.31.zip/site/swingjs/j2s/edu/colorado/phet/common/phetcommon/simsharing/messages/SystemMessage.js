(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.messages"),I$=[];
var C$=Clazz.newClass(P$, "SystemMessage", null, 'edu.colorado.phet.common.phetcommon.simsharing.SimSharingMessage');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IMessageType$edu_colorado_phet_common_phetcommon_simsharing_messages_ISystemComponent$edu_colorado_phet_common_phetcommon_simsharing_messages_ISystemComponentType$edu_colorado_phet_common_phetcommon_simsharing_messages_ISystemAction$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet', function (messageType, component, componentType, systemAction, parameters) {
C$.superclazz.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IMessageType$TT$TU$TV$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet.apply(this, [messageType, component, componentType, systemAction, parameters]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:51
