(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.property"),I$=[];
var C$=Clazz.newClass(P$, "ConstrainedProperty", null, 'edu.colorado.phet.common.phetcommon.model.property.Property');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['c$$TT'], function (value) {
C$.superclazz.c$$TT.apply(this, [value]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, ['set$TT'], function (value) {
if (this.isValid$TT(value)) {
C$.superclazz.prototype.set$TT.apply(this, [value]);
} else {
this.handleInvalidValue$TT(value);
}});

Clazz.newMeth(C$, ['handleInvalidValue$TT'], function (value) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["illegal value: " + value.toString()]);
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:48
