(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[['edu.colorado.phet.common.phetcommon.math.PlaneF',['edu.colorado.phet.common.phetcommon.util.Option','.None'],['edu.colorado.phet.common.phetcommon.util.Option','.Some'],['edu.colorado.phet.common.phetcommon.math.Triangle3F','.TriangleIntersectionResult']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Triangle3F", function(){
Clazz.newInstance(this, arguments,0,C$);
});

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.a = null;
this.b = null;
this.c = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F', function (a, b, c) {
C$.$init$.apply(this);
this.a = a;
this.b = b;
this.c = c;
}, 1);

Clazz.newMeth(C$, 'getPlane', function () {
return (I$[1]||$incl$(1)).fromTriangle$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F(this.a, this.b, this.c);
});

Clazz.newMeth(C$, 'getNormal', function () {
return this.b.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.a).cross$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.c.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.a)).normalized();
});

Clazz.newMeth(C$, 'getArea', function () {
return Math.abs(((this.a.x - this.c.x) * (this.b.y - this.c.y) - (this.b.x - this.c.x) * (this.a.y - this.c.y)) / 2.0);
});

Clazz.newMeth(C$, 'intersectWith$edu_colorado_phet_common_phetcommon_math_Ray3F', function (ray) {
var plane = this.getPlane();
if (plane == null ) {
return Clazz.new_((I$[2]||$incl$(2)));
}var planePoint = plane.intersectWithRay$edu_colorado_phet_common_phetcommon_math_Ray3F(ray);
var v0 = this.c.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.a);
var v1 = this.b.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.a);
var v2 = planePoint.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.a);
var dot00 = v0.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(v0);
var dot01 = v0.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(v1);
var dot02 = v0.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(v2);
var dot11 = v1.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(v1);
var dot12 = v1.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(v2);
var p = 1 / (dot00 * dot11 - dot01 * dot01);
var u = (dot11 * dot02 - dot01 * dot12) * p;
var v = (dot00 * dot12 - dot01 * dot02) * p;
var hit = (u >= 0 ) && (v >= 0 ) && (u + v <= 1 )  ;
if (hit) {
return Clazz.new_((I$[3]||$incl$(3)).c$$TT,[Clazz.new_((I$[4]||$incl$(4)).c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F,[planePoint, plane.normal.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(ray.dir) > 0  ? plane.normal.negated() : plane.normal])]);
} else {
return Clazz.new_((I$[2]||$incl$(2)));
}});
;
(function(){var C$=Clazz.newClass(P$.Triangle3F, "TriangleIntersectionResult", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.point = null;
this.normal = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F', function (point, normal) {
C$.$init$.apply(this);
this.point = point;
this.normal = normal;
}, 1);

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:46
