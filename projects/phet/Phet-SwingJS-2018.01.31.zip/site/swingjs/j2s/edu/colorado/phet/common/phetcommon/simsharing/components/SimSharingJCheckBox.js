(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.components"),I$=[['java.util.ArrayList','edu.colorado.phet.common.phetcommon.simsharing.messages.ParameterKeys','edu.colorado.phet.common.phetcommon.simsharing.messages.ParameterSet','edu.colorado.phet.common.phetcommon.simsharing.messages.UserComponent','edu.colorado.phet.common.phetcommon.simsharing.components.SimSharingJCheckBox$2$1','javax.swing.JPanel','javax.swing.JFrame']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SimSharingJCheckBox", null, 'javax.swing.JCheckBox');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.userComponent = null;
this.customParameterFunctions = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.customParameterFunctions = Clazz.new_((I$[1]||$incl$(1)));
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent', function (userComponent) {
Clazz.super_(C$, this,1);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$javax_swing_Icon', function (userComponent, icon) {
C$.superclazz.c$$javax_swing_Icon.apply(this, [icon]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$javax_swing_Icon$Z', function (userComponent, icon, selected) {
C$.superclazz.c$$javax_swing_Icon$Z.apply(this, [icon, selected]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$S', function (userComponent, text) {
C$.superclazz.c$$S.apply(this, [text]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$javax_swing_Action', function (userComponent, a) {
C$.superclazz.c$$javax_swing_Action.apply(this, [a]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$S$Z', function (userComponent, text, selected) {
C$.superclazz.c$$S$Z.apply(this, [text, selected]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$S$javax_swing_Icon', function (userComponent, text, icon) {
C$.superclazz.c$$S$javax_swing_Icon.apply(this, [text, icon]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$S$javax_swing_Icon$Z', function (userComponent, text, icon, selected) {
C$.superclazz.c$$S$javax_swing_Icon$Z.apply(this, [text, icon, selected]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'enableMouseEvents', function () {
this.enableEvents$J(16);
});

Clazz.newMeth(C$, 'processMouseEvent$java_awt_event_MouseEvent', function (e) {
if (e.getID() == 501 && !this.isEnabled() ) {
p$.sendUserMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet.apply(this, [p$.getParameters.apply(this, []).$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$Z((I$[2]||$incl$(2)).enabled, this.isEnabled()).$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$Z((I$[2]||$incl$(2)).interactive, this.isEnabled())]);
}C$.superclazz.prototype.processMouseEvent$java_awt_event_MouseEvent.apply(this, [e]);
});

Clazz.newMeth(C$, 'fireActionPerformed$java_awt_event_ActionEvent', function (event) {
p$.sendUserMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet.apply(this, [p$.getParameters.apply(this, [])]);
C$.superclazz.prototype.fireActionPerformed$java_awt_event_ActionEvent.apply(this, [event]);
});

Clazz.newMeth(C$, 'getParameters', function () {
return Clazz.new_((I$[3]||$incl$(3))).$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$Z((I$[2]||$incl$(2)).isSelected, this.isSelected()).$with$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet(this.getCustomParameters());
});

Clazz.newMeth(C$, 'getCustomParameters', function () {
var parameterSet = Clazz.new_((I$[3]||$incl$(3)));
for (var function, $function = this.customParameterFunctions.iterator(); $function.hasNext()&&((function=$function.next()),1);) {
parameterSet.$with$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet($function.$apply());
}
return parameterSet;
});

Clazz.newMeth(C$, 'addCustomParametersFunction$edu_colorado_phet_common_phetcommon_util_function_Function0', function ($function) {
this.customParameterFunctions.add$TE($function);
});

Clazz.newMeth(C$, 'sendUserMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet', function (parameterSet) {
});

Clazz.newMeth(C$, 'main', function (args) {
var checkBox1 = ((
(function(){var C$=Clazz.newClass(P$, "SimSharingJCheckBox$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('edu.colorado.phet.common.phetcommon.simsharing.components.SimSharingJCheckBox'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getCustomParameters', function () {
return (I$[3]||$incl$(3)).parameterSet$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$S((I$[2]||$incl$(2)).text, "I use subclassing.");
});
})()
), Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$S, [this, null, Clazz.new_((I$[4]||$incl$(4)).c$$S,["checkBox1"]), "subclassing"],P$.SimSharingJCheckBox$1));
var checkBox2 = ((
(function(){var C$=Clazz.newClass(P$, "SimSharingJCheckBox$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('edu.colorado.phet.common.phetcommon.simsharing.components.SimSharingJCheckBox'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
{
this.addCustomParametersFunction$edu_colorado_phet_common_phetcommon_util_function_Function0(((
(function(){var C$=Clazz.newClass(P$, "SimSharingJCheckBox$2$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.Function0', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, '$apply', function () {
return (I$[3]||$incl$(3)).parameterSet$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$S((I$[2]||$incl$(2)).text, "I use mutation.");
});
})()
), Clazz.new_((I$[5]||$incl$(5)).$init$, [this, null])));
}
}, 1);
})()
), Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$S, [this, null, Clazz.new_((I$[4]||$incl$(4)).c$$S,["checkBox2"]), "mutation"],P$.SimSharingJCheckBox$2));
var frame = ((
(function(){var C$=Clazz.newClass(P$, "SimSharingJCheckBox$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.JFrame'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
{
this.setContentPane$java_awt_Container(((
(function(){var C$=Clazz.newClass(P$, "SimSharingJCheckBox$3$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.JPanel'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
{
this.add$java_awt_Component(this.$finals.checkBox1);
this.add$java_awt_Component(this.$finals.checkBox2);
}
}, 1);
})()
), Clazz.new_((I$[6]||$incl$(6)), [this, {checkBox1: this.$finals.checkBox1, checkBox2: this.$finals.checkBox2}],P$.SimSharingJCheckBox$3$1)));
this.pack();
this.setDefaultCloseOperation$I(3);
}
}, 1);
})()
), Clazz.new_((I$[7]||$incl$(7)), [this, {checkBox1: checkBox1, checkBox2: checkBox2}],P$.SimSharingJCheckBox$3));
frame.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:50
