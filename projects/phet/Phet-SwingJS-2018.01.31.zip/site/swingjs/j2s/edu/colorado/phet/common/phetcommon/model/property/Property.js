(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.property"),I$=[['edu.colorado.phet.common.phetcommon.model.property.Property$1','edu.colorado.phet.common.phetcommon.model.property.Property$2','edu.colorado.phet.common.phetcommon.model.property.Property$3']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Property", null, 'edu.colorado.phet.common.phetcommon.model.property.SettableProperty');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.value = null;
this.initialValue = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['c$$TT'], function (value) {
C$.superclazz.c$$TT.apply(this, [value]);
C$.$init$.apply(this);
this.initialValue = value;
this.value = value;
}, 1);

Clazz.newMeth(C$, 'reset', function () {
this.set$TT(this.initialValue);
});

Clazz.newMeth(C$, 'get', function () {
return this.value;
});

Clazz.newMeth(C$, ['set$TT'], function (value) {
var notifier;
{
this.value = value;
notifier = this.getChangeNotifier();
}notifier.run();
});

Clazz.newMeth(C$, 'getInitialValue', function () {
return this.initialValue;
});

Clazz.newMeth(C$, 'main', function (args) {
var enabled = Clazz.new_(C$.c$$TT,[new Boolean(true)]);
enabled.addObserver$edu_colorado_phet_common_phetcommon_util_SimpleObserver(((
(function(){var C$=Clazz.newClass(P$, "Property$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.SimpleObserver', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'update', function () {
System.out.println$S("SimpleObserver enabled=" + this.$finals.enabled.get());
});
})()
), Clazz.new_((I$[1]||$incl$(1)).$init$, [this, {enabled: enabled}])));
enabled.addObserver$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1(((
(function(){var C$=Clazz.newClass(P$, "Property$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.VoidFunction1', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['$apply$Boolean','$apply$TT'], function (newValue) {
System.out.println$S("VoidFunction1 newValue=" + newValue);
});
})()
), Clazz.new_((I$[2]||$incl$(2)).$init$, [this, null])));
enabled.addObserver$edu_colorado_phet_common_phetcommon_model_property_ChangeObserver(((
(function(){var C$=Clazz.newClass(P$, "Property$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.model.property.ChangeObserver', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['update$Boolean$Boolean','update$TT$TT'], function (newValue, oldValue) {
System.out.println$S("newValue = " + newValue + ", oldValue = " + oldValue );
});
})()
), Clazz.new_((I$[3]||$incl$(3)).$init$, [this, null])));
enabled.set$TT(new Boolean(!(enabled.get()).booleanValue()));
}, 1);

Clazz.newMeth(C$, ['property$TT'], function (value) {
return Clazz.new_(C$.c$$TT,[value]);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:48
