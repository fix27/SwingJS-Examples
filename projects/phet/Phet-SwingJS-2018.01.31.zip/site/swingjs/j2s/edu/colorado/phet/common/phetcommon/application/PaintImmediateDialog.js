(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.application"),I$=[['edu.colorado.phet.common.phetcommon.application.PaintImmediateDialog$PaintImmediateTimer$1',['edu.colorado.phet.common.phetcommon.application.PaintImmediateDialog','.PaintImmediateTimer'],'java.awt.event.WindowAdapter']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "PaintImmediateDialog", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'javax.swing.JDialog');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.timer = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
p$.initPaintImmediateDialog.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Frame', function (frame) {
C$.superclazz.c$$java_awt_Frame.apply(this, [frame]);
C$.$init$.apply(this);
p$.initPaintImmediateDialog.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Frame$S', function (frame, title) {
C$.superclazz.c$$java_awt_Frame$S.apply(this, [frame, title]);
C$.$init$.apply(this);
p$.initPaintImmediateDialog.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Dialog', function (owner) {
C$.superclazz.c$$java_awt_Dialog.apply(this, [owner]);
C$.$init$.apply(this);
p$.initPaintImmediateDialog.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Dialog$S', function (owner, title) {
C$.superclazz.c$$java_awt_Dialog$S.apply(this, [owner, title]);
C$.$init$.apply(this);
p$.initPaintImmediateDialog.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Frame$Z', function (owner, modal) {
C$.superclazz.c$$java_awt_Frame$Z.apply(this, [owner, modal]);
C$.$init$.apply(this);
p$.initPaintImmediateDialog.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Dialog$Z', function (owner, modal) {
C$.superclazz.c$$java_awt_Dialog$Z.apply(this, [owner, modal]);
C$.$init$.apply(this);
p$.initPaintImmediateDialog.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Frame$S$Z', function (owner, title, modal) {
C$.superclazz.c$$java_awt_Frame$S$Z.apply(this, [owner, title, modal]);
C$.$init$.apply(this);
p$.initPaintImmediateDialog.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Dialog$S$Z', function (owner, title, modal) {
C$.superclazz.c$$java_awt_Dialog$S$Z.apply(this, [owner, title, modal]);
C$.$init$.apply(this);
p$.initPaintImmediateDialog.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'initPaintImmediateDialog', function () {
this.timer = Clazz.new_((I$[2]||$incl$(2)).c$$javax_swing_JDialog,[this]);
this.addWindowListener$java_awt_event_WindowListener(((
(function(){var C$=Clazz.newClass(P$, "PaintImmediateDialog$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.WindowAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'windowOpened$java_awt_event_WindowEvent', function (e) {
this.b$['edu.colorado.phet.common.phetcommon.application.PaintImmediateDialog'].timer.start();
});

Clazz.newMeth(C$, 'windowClosed$java_awt_event_WindowEvent', function (e) {
this.b$['edu.colorado.phet.common.phetcommon.application.PaintImmediateDialog'].timer.stop();
});
})()
), Clazz.new_((I$[3]||$incl$(3)), [this, null],P$.PaintImmediateDialog$1)));
});
;
(function(){var C$=Clazz.newClass(P$.PaintImmediateDialog, "PaintImmediateTimer", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'javax.swing.Timer');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$javax_swing_JDialog', function (dialog) {
C$.superclazz.c$$I$java_awt_event_ActionListener.apply(this, [250, ((
(function(){var C$=Clazz.newClass(P$, "PaintImmediateDialog$PaintImmediateTimer$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var component = this.$finals.dialog.getContentPane();
component.paintImmediately$I$I$I$I(0, 0, component.getWidth(), component.getHeight());
if (false) {
System.out.println$S("PaintImmediateTimer: paintImmediately");
}});
})()
), Clazz.new_((I$[1]||$incl$(1)).$init$, [this, {dialog: dialog}]))]);
C$.$init$.apply(this);
this.setRepeats$Z(true);
}, 1);

Clazz.newMeth(C$, 'start', function () {
if (true) {
C$.superclazz.prototype.start.apply(this, []);
if (false) {
System.out.println$S("PaintImmediateTimer: timer started");
}}});

Clazz.newMeth(C$, 'stop', function () {
if (true) {
C$.superclazz.prototype.stop.apply(this, []);
if (false) {
System.out.println$S("PaintImmediateTimer: timer stopped");
}}});

Clazz.newMeth(C$);
})()
})();
//Created 2018-01-31 11:02:44
