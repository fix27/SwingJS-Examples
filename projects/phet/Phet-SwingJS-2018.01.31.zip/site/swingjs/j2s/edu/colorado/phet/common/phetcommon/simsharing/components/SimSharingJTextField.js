(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.components"),I$=[['edu.colorado.phet.common.phetcommon.simsharing.components.SimSharingJTextField$1','edu.colorado.phet.common.phetcommon.simsharing.messages.UserActions','edu.colorado.phet.common.phetcommon.simsharing.messages.ParameterKeys','java.awt.event.KeyEvent','edu.colorado.phet.common.phetcommon.simsharing.messages.ParameterSet','edu.colorado.phet.common.phetcommon.simsharing.messages.UserComponent','edu.colorado.phet.common.phetcommon.simsharing.components.SimSharingJTextField$2','edu.colorado.phet.common.phetcommon.simsharing.components.SimSharingJTextField$3','java.awt.event.KeyAdapter','javax.swing.JCheckBox','edu.colorado.phet.common.phetcommon.simsharing.components.SimSharingJTextField$5','edu.colorado.phet.common.phetcommon.simsharing.components.SimSharingJTextField$6','javax.swing.JPanel','javax.swing.JFrame']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SimSharingJTextField", null, 'javax.swing.JTextField');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.userComponent = null;
this.dummyActionListener = null;
this.focusMessagesEnabled = false;
this.keyPressedMessagesEnabled = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.dummyActionListener = ((
(function(){var C$=Clazz.newClass(P$, "SimSharingJTextField$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
});
})()
), Clazz.new_((I$[1]||$incl$(1)).$init$, [this, null]));
this.focusMessagesEnabled = true;
this.keyPressedMessagesEnabled = false;
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent', function (userComponent) {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$S', function (userComponent, text) {
C$.superclazz.c$$S.apply(this, [text]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$S$I', function (userComponent, text, columns) {
C$.superclazz.c$$S$I.apply(this, [text, columns]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$I', function (userComponent, columns) {
C$.superclazz.c$$I.apply(this, [columns]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$javax_swing_text_Document$S$I', function (userComponent, doc, text, columns) {
C$.superclazz.c$$javax_swing_text_Document$S$I.apply(this, [doc, text, columns]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'init', function () {
p$.enableFireActionPerformed.apply(this, []);
p$.enableMouseEvents.apply(this, []);
});

Clazz.newMeth(C$, 'setFocusMessagesEnabled$Z', function (enabled) {
this.focusMessagesEnabled = enabled;
});

Clazz.newMeth(C$, 'isFocusMessagesEnabled', function () {
return this.focusMessagesEnabled;
});

Clazz.newMeth(C$, 'setKeyPressedMessagesEnabled$Z', function (enabled) {
this.keyPressedMessagesEnabled = enabled;
});

Clazz.newMeth(C$, 'isKeyPressedMessagesEnabled', function () {
return this.keyPressedMessagesEnabled;
});

Clazz.newMeth(C$, 'enableFireActionPerformed', function () {
this.addActionListener$java_awt_event_ActionListener(this.dummyActionListener);
});

Clazz.newMeth(C$, 'removeActionListener$java_awt_event_ActionListener', function (l) {
if (l !== this.dummyActionListener ) {
C$.superclazz.prototype.removeActionListener$java_awt_event_ActionListener.apply(this, [l]);
}});

Clazz.newMeth(C$, 'enableMouseEvents', function () {
this.enableEvents$J(16);
});

Clazz.newMeth(C$, 'fireActionPerformed', function () {
p$.sendUserMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserAction$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet.apply(this, [(I$[2]||$incl$(2)).enterPressed, this.getParameters()]);
C$.superclazz.prototype.fireActionPerformed.apply(this, []);
});

Clazz.newMeth(C$, 'processFocusEvent$java_awt_event_FocusEvent', function (e) {
if (this.focusMessagesEnabled) {
if (e.getID() == 1005) {
p$.sendUserMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserAction$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet.apply(this, [(I$[2]||$incl$(2)).focusLost, this.getParameters()]);
} else if (e.getID() == 1004) {
p$.sendUserMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserAction$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet.apply(this, [(I$[2]||$incl$(2)).focusGained, this.getParameters()]);
}}C$.superclazz.prototype.processFocusEvent$java_awt_event_FocusEvent.apply(this, [e]);
});

Clazz.newMeth(C$, 'processKeyEvent$java_awt_event_KeyEvent', function (e) {
if (this.keyPressedMessagesEnabled && e.getID() == 401  && e.getKeyCode() != 10 ) {
p$.sendUserMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserAction$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet.apply(this, [(I$[2]||$incl$(2)).keyPressed, this.getParameters().$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$S((I$[3]||$incl$(3)).key, (I$[4]||$incl$(4)).getKeyText$I(e.getKeyCode()))]);
}C$.superclazz.prototype.processKeyEvent$java_awt_event_KeyEvent.apply(this, [e]);
});

Clazz.newMeth(C$, 'processMouseEvent$java_awt_event_MouseEvent', function (e) {
if (e.getID() == 501 && !this.isEnabled() ) {
p$.sendUserMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserAction$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet.apply(this, [(I$[2]||$incl$(2)).pressed, edu.colorado.phet.common.phetcommon.simsharing.messages.ParameterSet.parameterSet$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$Z((I$[3]||$incl$(3)).enabled, this.isEnabled()).$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$Z((I$[3]||$incl$(3)).interactive, this.isEnabled())]);
}C$.superclazz.prototype.processMouseEvent$java_awt_event_MouseEvent.apply(this, [e]);
});

Clazz.newMeth(C$, 'getParameters', function () {
return Clazz.new_((I$[5]||$incl$(5))).$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$S((I$[3]||$incl$(3)).text, this.getText());
});

Clazz.newMeth(C$, 'sendUserMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserAction$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet', function (action, parameterSet) {
});

Clazz.newMeth(C$, 'main', function (args) {
var textField = Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$S$I,[Clazz.new_((I$[6]||$incl$(6)).c$$S,["myTextField"]), "SimSharingJTextField", 20]);
textField.setKeyPressedMessagesEnabled$Z(true);
textField.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "SimSharingJTextField$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
System.out.println$S("actionPerformed");
});
})()
), Clazz.new_((I$[7]||$incl$(7)).$init$, [this, null])));
textField.addFocusListener$java_awt_event_FocusListener(((
(function(){var C$=Clazz.newClass(P$, "SimSharingJTextField$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.FocusListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'focusGained$java_awt_event_FocusEvent', function (e) {
System.out.println$S("focusGained");
});

Clazz.newMeth(C$, 'focusLost$java_awt_event_FocusEvent', function (e) {
System.out.println$S("focusLost");
});
})()
), Clazz.new_((I$[8]||$incl$(8)).$init$, [this, null])));
textField.addKeyListener$java_awt_event_KeyListener(((
(function(){var C$=Clazz.newClass(P$, "SimSharingJTextField$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.KeyAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'keyPressed$java_awt_event_KeyEvent', function (e) {
System.out.println$S("keyPressed");
});
})()
), Clazz.new_((I$[9]||$incl$(9)), [this, null],P$.SimSharingJTextField$4)));
var keyPressCheckBox = Clazz.new_((I$[10]||$incl$(10)).c$$S$Z,["keyPressed messages", textField.isKeyPressedMessagesEnabled()]);
keyPressCheckBox.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "SimSharingJTextField$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.$finals.textField.setKeyPressedMessagesEnabled$Z(this.$finals.keyPressCheckBox.isSelected());
});
})()
), Clazz.new_((I$[11]||$incl$(11)).$init$, [this, {textField: textField, keyPressCheckBox: keyPressCheckBox}])));
var focusCheckBox = Clazz.new_((I$[10]||$incl$(10)).c$$S$Z,["focus messages", textField.isFocusMessagesEnabled()]);
focusCheckBox.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "SimSharingJTextField$6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.$finals.textField.setFocusMessagesEnabled$Z(this.$finals.focusCheckBox.isSelected());
});
})()
), Clazz.new_((I$[12]||$incl$(12)).$init$, [this, {textField: textField, focusCheckBox: focusCheckBox}])));
var frame = ((
(function(){var C$=Clazz.newClass(P$, "SimSharingJTextField$7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.JFrame'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
{
this.setContentPane$java_awt_Container(((
(function(){var C$=Clazz.newClass(P$, "SimSharingJTextField$7$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.JPanel'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
{
this.add$java_awt_Component(this.$finals.keyPressCheckBox);
this.add$java_awt_Component(this.$finals.focusCheckBox);
this.add$java_awt_Component(this.$finals.textField);
}
}, 1);
})()
), Clazz.new_((I$[13]||$incl$(13)), [this, {keyPressCheckBox: this.$finals.keyPressCheckBox, focusCheckBox: this.$finals.focusCheckBox, textField: this.$finals.textField}],P$.SimSharingJTextField$7$1)));
this.pack();
this.setDefaultCloseOperation$I(3);
}
}, 1);
})()
), Clazz.new_((I$[14]||$incl$(14)), [this, {keyPressCheckBox: keyPressCheckBox, focusCheckBox: focusCheckBox, textField: textField}],P$.SimSharingJTextField$7));
frame.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:50
