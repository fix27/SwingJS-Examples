(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.resources"),I$=[['edu.colorado.phet.common.phetcommon.view.util.ImageLoader','edu.colorado.phet.common.phetgraphics.view.phetgraphics.GraphicLayerSet','java.awt.image.BufferedImage','edu.colorado.phet.common.phetcommon.Interface']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DefaultResourceLoader", null, 'edu.colorado.phet.common.phetcommon.resources.AbstractResourceLoader');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getImage$S', function (resource) {
if (resource == null  || resource.length$() == 0 ) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["null or zero-length resource name"]);
}var image = null;
try {
image = (I$[1]||$incl$(1)).loadBufferedImage$S(resource);
(I$[2]||$incl$(2)).graphicSourcesBH.put$TK$TV(image.getSource(), resource);
} catch (e) {
if (Clazz.exceptionOf(e, "java.io.IOException")){
e.printStackTrace();
image = Clazz.new_((I$[3]||$incl$(3)).c$$I$I$I,[1, 1, 1]);
} else {
throw e;
}
}
return image;
});

Clazz.newMeth(C$, 'getAudioClip$S', function (resource) {
if (resource == null  || resource.length$() == 0 ) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["null or zero-length resource name"]);
}return (I$[4]||$incl$(4)).getInstanceWithParams$S$ClassA$OA("edu.colorado.phet.common.phetcommon.audio.PhetAudioClip", Clazz.array(java.lang.Class, -1, [Clazz.getClass(java.lang.String)]), [resource]);
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:49
