(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.util"),I$=[];
var C$=Clazz.newClass(P$, "CommandLineUtils");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'contains$SA$S', function (args, arg) {
var found = false;
if (args != null  && arg != null  ) {
for (var i = 0; i < args.length; i++) {
if (arg.equals$O(args[i])) {
found = true;
break;
}}
}return found;
}, 1);
})();
//Created 2018-01-31 11:02:51
