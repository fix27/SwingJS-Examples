(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[];
var C$=Clazz.newClass(P$, "Complex");
C$.ZERO = null;
C$.I = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.ZERO = Clazz.new_(C$.c$$D$D,[0, 0]);
C$.I = Clazz.new_(C$.c$$D$D,[0, 1]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._real = 0;
this._imaginary = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$D$D', function (real, imaginary) {
C$.$init$.apply(this);
this._real = real;
this._imaginary = imaginary;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$D$D.apply(this, [0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_Complex', function (c) {
C$.c$$D$D.apply(this, [c._real, c._imaginary]);
}, 1);

Clazz.newMeth(C$, 'copy', function () {
return Clazz.new_(C$.c$$D$D,[this._real, this._imaginary]);
});

Clazz.newMeth(C$, 'getReal', function () {
return this._real;
});

Clazz.newMeth(C$, 'getImaginary', function () {
return this._imaginary;
});

Clazz.newMeth(C$, 'getPhase', function () {
return Math.atan2(this._imaginary, this._real);
});

Clazz.newMeth(C$, 'isZero', function () {
return (this._real == 0  && this._imaginary == 0  );
});

Clazz.newMeth(C$, 'getAdd$edu_colorado_phet_common_phetcommon_math_Complex', function (c) {
return this.getAdd$D$D(c._real, c._imaginary);
});

Clazz.newMeth(C$, 'getAdd$D$D', function (real, imaginary) {
return Clazz.new_(C$.c$$D$D,[this._real + real, this._imaginary + imaginary]);
});

Clazz.newMeth(C$, 'getAdd$D', function (real) {
return this.getAdd$D$D(real, 0);
});

Clazz.newMeth(C$, 'getSubtract$edu_colorado_phet_common_phetcommon_math_Complex', function (c) {
return this.getSubtract$D$D(c._real, c._imaginary);
});

Clazz.newMeth(C$, 'getSubtract$D$D', function (real, imaginary) {
return Clazz.new_(C$.c$$D$D,[this._real - real, this._imaginary - imaginary]);
});

Clazz.newMeth(C$, 'getSubtract$D', function (real) {
return this.getSubtract$D$D(real, 0);
});

Clazz.newMeth(C$, 'getMultiply$edu_colorado_phet_common_phetcommon_math_Complex', function (c) {
return this.getMultiply$D$D(c._real, c._imaginary);
});

Clazz.newMeth(C$, 'getMultiply$D$D', function (real, imaginary) {
return Clazz.new_(C$.c$$D$D,[this._real * real - this._imaginary * imaginary, this._real * imaginary + this._imaginary * real]);
});

Clazz.newMeth(C$, 'getMultiply$D', function (real) {
return this.getMultiply$D$D(real, 0);
});

Clazz.newMeth(C$, 'getDivide$edu_colorado_phet_common_phetcommon_math_Complex', function (c) {
return this.getDivide$D$D(c._real, c._imaginary);
});

Clazz.newMeth(C$, 'getDivide$D$D', function (real, imaginary) {
var q = real * real + imaginary * imaginary;
var g = this._real * real + this._imaginary * imaginary;
var h = this._imaginary * real - this._real * imaginary;
return Clazz.new_(C$.c$$D$D,[g / q, h / q]);
});

Clazz.newMeth(C$, 'getDivide$D', function (real) {
return this.getDivide$D$D(real, 0);
});

Clazz.newMeth(C$, 'getScale$D', function (scale) {
return Clazz.new_(C$.c$$D$D,[this._real * scale, this._imaginary * scale]);
});

Clazz.newMeth(C$, 'getAbs', function () {
return (Math.sqrt((this._real * this._real) + (this._imaginary * this._imaginary)));
});

Clazz.newMeth(C$, 'getCanonicalSquareRoot', function () {
var magnitude = this.getAbs();
return Clazz.new_(C$.c$$D$D,[Math.sqrt((magnitude + this._real) / 2), Math.signum(this._imaginary) * Math.sqrt((magnitude - this._real) / 2)]);
});

Clazz.newMeth(C$, 'getModulus', function () {
return this.getAbs();
});

Clazz.newMeth(C$, 'getOpposite', function () {
return Clazz.new_(C$.c$$D$D,[-this._real, -this._imaginary]);
});

Clazz.newMeth(C$, 'getComplexConjugate', function () {
return Clazz.new_(C$.c$$D$D,[this._real, -this._imaginary]);
});

Clazz.newMeth(C$, 'getExponentiateImaginary$D', function (theta) {
return Clazz.new_(C$.c$$D$D,[Math.cos(theta), Math.sin(theta)]);
}, 1);

Clazz.newMeth(C$, 'getExp$edu_colorado_phet_common_phetcommon_math_Complex', function (c) {
return C$.getExp$D$D(c._real, c._imaginary);
}, 1);

Clazz.newMeth(C$, 'getExp$D$D', function (real, imaginary) {
var multiplier = Math.exp(real);
return Clazz.new_(C$.c$$D$D,[multiplier * Math.cos(imaginary), multiplier * Math.sin(imaginary)]);
}, 1);

Clazz.newMeth(C$, 'equals$O', function (obj) {
var isEqual = false;
if (Clazz.instanceOf(obj, "edu.colorado.phet.common.phetcommon.math.Complex")) {
var c = obj;
isEqual = (this._real == c._real  && this._imaginary == c._imaginary  );
}return isEqual;
});

Clazz.newMeth(C$, 'toString', function () {
return "[" + new Double(this._real).toString() + "+" + new Double(this._imaginary).toString() + "i]" ;
});
})();
//Created 2018-01-31 11:02:45
