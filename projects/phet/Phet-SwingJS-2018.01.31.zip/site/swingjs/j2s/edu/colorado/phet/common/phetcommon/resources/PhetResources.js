(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.resources"),I$=[['edu.colorado.phet.common.phetcommon.resources.DefaultResourceLoader','edu.colorado.phet.common.phetcommon.resources.PhetProperties','java.util.Locale','edu.colorado.phet.common.phetcommon.resources.DummyConstantStringTester','java.text.MessageFormat','edu.colorado.phet.common.phetcommon.resources.PhetVersion']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "PhetResources");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.projectName = null;
this.locale = null;
this.localizedProperties = null;
this.projectProperties = null;
this.resourceLoader = null;
this.rootDirectoryName = null;
this.version = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (projectName) {
C$.c$$S$java_util_Locale$edu_colorado_phet_common_phetcommon_resources_IResourceLoader.apply(this, [projectName, C$.readLocale(), Clazz.new_((I$[1]||$incl$(1)))]);
}, 1);

Clazz.newMeth(C$, 'c$$S$java_util_Locale$edu_colorado_phet_common_phetcommon_resources_IResourceLoader', function (projectName, locale, resourceLoader) {
C$.$init$.apply(this);
this.projectName = projectName;
this.rootDirectoryName = "edu/colorado/phet/assets/" + projectName;
this.locale = locale;
this.resourceLoader = resourceLoader;
var projectPropertiesBundleName = projectName + ".properties";
if (resourceLoader.exists$S(this.rootDirectoryName + "/" + projectPropertiesBundleName )) {
this.projectProperties = this.getProperties$S(projectPropertiesBundleName);
} else {
this.projectProperties = Clazz.new_((I$[2]||$incl$(2)));
}var localizedPropertiesBundleName = "localization" + "/" + projectName + "-strings" ;
this.localizedProperties = this.getProperties$S(localizedPropertiesBundleName);
}, 1);

Clazz.newMeth(C$, 'readLocale', function () {
var locale = (I$[3]||$incl$(3)).getDefault();
{

}
return locale;
}, 1);

Clazz.newMeth(C$, 'getProjectName', function () {
return this.projectName;
});

Clazz.newMeth(C$, 'getRootDirectoryName', function () {
return this.rootDirectoryName;
});

Clazz.newMeth(C$, 'getLocale', function () {
return this.locale;
});

Clazz.newMeth(C$, 'getLocalizedProperties', function () {
return this.localizedProperties;
});

Clazz.newMeth(C$, 'getProjectProperties', function () {
return this.projectProperties;
});

Clazz.newMeth(C$, 'getAudioClip$S', function (resourceName) {
return this.resourceLoader.getAudioClip$S(this.getFullPathForAudio$S(resourceName));
});

Clazz.newMeth(C$, 'getFullPathForAudio$S', function (s) {
return this.rootDirectoryName + "/" + "audio" + "/" + s ;
});

Clazz.newMeth(C$, 'getImage$S', function (resourceName) {
return this.resourceLoader.getImage$S(this.rootDirectoryName + "/" + "images" + "/" + resourceName );
});

Clazz.newMeth(C$, 'getResource$S', function (resourceName) {
return this.resourceLoader.getResource$S(this.rootDirectoryName + "/" + resourceName );
});

Clazz.newMeth(C$, 'getResourceAsStream$S', function (resourceName) {
return this.resourceLoader.getResourceAsStream$S(this.rootDirectoryName + "/" + resourceName );
});

Clazz.newMeth(C$, 'getResourceAsString$S', function (resourceName) {
return this.resourceLoader.getResourceAsString$S(resourceName);
});

Clazz.newMeth(C$, 'getProperties$S', function (resourceName) {
return this.resourceLoader.getProperties$S$java_util_Locale(this.rootDirectoryName + "/" + resourceName , this.locale);
});

Clazz.newMeth(C$, 'getProjectProperty$S', function (key) {
return this.projectProperties.getProperty$S(key);
});

Clazz.newMeth(C$, 'getLocalizedString$S', function (key) {
return (I$[4]||$incl$(4)).getString$S(this.localizedProperties.getString$S(key));
});

Clazz.newMeth(C$, 'format$S$SA', function (key, values) {
return (I$[5]||$incl$(5)).format$S$OA(this.getLocalizedString$S(key), values);
});

Clazz.newMeth(C$, 'getLocalizedChar$S$C', function (key, defaultValue) {
return this.localizedProperties.getChar$S$C(key, defaultValue);
});

Clazz.newMeth(C$, 'getLocalizedInt$S$I', function (key, defaultValue) {
return this.localizedProperties.getInt$S$I(key, defaultValue);
});

Clazz.newMeth(C$, 'getLocalizedDouble$S$D', function (key, defaultValue) {
return this.localizedProperties.getDouble$S$D(key, defaultValue);
});

Clazz.newMeth(C$, 'getName$S', function (flavor) {
return this.localizedProperties.getProperty$S(flavor + "." + "name" );
});

Clazz.newMeth(C$, 'getVersion', function () {
if (this.version == null ) {
this.version = C$.getVersion$java_util_Properties(this.projectProperties);
}return this.version;
});

Clazz.newMeth(C$, 'getVersion$java_util_Properties', function (properties) {
var major = properties.getProperty$S("version.major");
var minor = properties.getProperty$S("version.minor");
var dev = properties.getProperty$S("version.dev");
var rev = properties.getProperty$S("version.revision");
var timestamp = properties.getProperty$S("version.timestamp");
return Clazz.new_((I$[6]||$incl$(6)).c$$S$S$S$S$S,[major, minor, dev, rev, timestamp]);
}, 1);

Clazz.newMeth(C$, 'getDistributionTag', function () {
return this.getProjectProperty$S("distribution.tag");
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:49
