(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.resources"),I$=[['edu.colorado.phet.common.phetcommon.resources.PhetResources','java.util.Properties','edu.colorado.phet.common.phetcommon.util.LocaleUtils','java.text.MessageFormat']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "PhetCommonResources");
C$.INSTANCE = null;
C$.PICCOLO_PHET_VELOCITY_SENSOR_NODE_SPEED = null;
C$.PICCOLO_PHET_VELOCITY_SENSOR_NODE_UNKNOWN = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.INSTANCE = Clazz.new_((I$[1]||$incl$(1)).c$$S,["phetcommon"]);
C$.PICCOLO_PHET_VELOCITY_SENSOR_NODE_SPEED = C$.getString$S("PiccoloPhet.VelocitySensorNode.speed");
C$.PICCOLO_PHET_VELOCITY_SENSOR_NODE_UNKNOWN = C$.getString$S("PiccoloPhet.VelocitySensorNode.unknown");
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getInstance', function () {
return C$.INSTANCE;
}, 1);

Clazz.newMeth(C$, 'getPreferredFontNames$java_util_Locale', function (locale) {
var names = null;
var fontProperties = Clazz.new_((I$[2]||$incl$(2)));
try {
fontProperties.load$java_io_InputStream(C$.getInstance().getResourceAsStream$S("localization/phetcommon-fonts.properties"));
var localeString = (I$[3]||$incl$(3)).localeToString$java_util_Locale(locale);
var key = "preferredFonts." + localeString;
var allNames = fontProperties.getProperty$S(key);
if (allNames != null ) {
if (allNames.indexOf("Sans") >= 0) allNames += ",Arial";
 else allNames += ",Serif";
names = allNames.$plit(",");
}} catch (e) {
if (Clazz.exceptionOf(e, "java.io.IOException")){
e.printStackTrace();
} else {
throw e;
}
}
return names;
}, 1);

Clazz.newMeth(C$, 'getString$S', function (key) {
return C$.INSTANCE.getLocalizedString$S(key);
}, 1);

Clazz.newMeth(C$, 'getChar$S$C', function (name, defaultValue) {
return C$.INSTANCE.getLocalizedChar$S$C(name, defaultValue);
}, 1);

Clazz.newMeth(C$, 'getImage$S', function (name) {
return C$.INSTANCE.getImage$S(name);
}, 1);

Clazz.newMeth(C$, 'formatValueUnits$S$S', function (value, units) {
return (I$[4]||$incl$(4)).format$S$OA(C$.getString$S("Common.value_units"), [value, units]);
}, 1);

Clazz.newMeth(C$, 'getMaximizeButtonImage', function () {
return C$.getImage$S("buttons/maximizeButton.png");
}, 1);

Clazz.newMeth(C$, 'getMinimizeButtonImage', function () {
return C$.getImage$S("buttons/minimizeButton.png");
}, 1);
})();
//Created 2018-01-31 11:02:49
