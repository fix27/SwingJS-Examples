(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.components"),I$=[['edu.colorado.phet.common.phetcommon.simsharing.messages.ParameterKeys','edu.colorado.phet.common.phetcommon.simsharing.messages.ParameterSet']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SimSharingJCheckBoxMenuItem", null, 'javax.swing.JCheckBoxMenuItem');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.userComponent = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent', function (userComponent) {
Clazz.super_(C$, this,1);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$javax_swing_Icon', function (userComponent, icon) {
C$.superclazz.c$$javax_swing_Icon.apply(this, [icon]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$S', function (userComponent, text) {
C$.superclazz.c$$S.apply(this, [text]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$javax_swing_Action', function (userComponent, a) {
C$.superclazz.c$$javax_swing_Action.apply(this, [a]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$S$javax_swing_Icon', function (userComponent, text, icon) {
C$.superclazz.c$$S$javax_swing_Icon.apply(this, [text, icon]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$S$Z', function (userComponent, text, b) {
C$.superclazz.c$$S$Z.apply(this, [text, b]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$S$javax_swing_Icon$Z', function (userComponent, text, icon, b) {
C$.superclazz.c$$S$javax_swing_Icon$Z.apply(this, [text, icon, b]);
C$.$init$.apply(this);
this.userComponent = userComponent;
p$.enableMouseEvents.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'enableMouseEvents', function () {
this.enableEvents$J(16);
});

Clazz.newMeth(C$, 'processMouseEvent$java_awt_event_MouseEvent', function (e) {
if (e.getID() == 501 && !this.isEnabled() ) {
p$.sendUserMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet.apply(this, [edu.colorado.phet.common.phetcommon.simsharing.messages.ParameterSet.parameterSet$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$Z((I$[1]||$incl$(1)).enabled, this.isEnabled()).$with$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$Z((I$[1]||$incl$(1)).interactive, this.isEnabled())]);
}C$.superclazz.prototype.processMouseEvent$java_awt_event_MouseEvent.apply(this, [e]);
});

Clazz.newMeth(C$, 'fireActionPerformed$java_awt_event_ActionEvent', function (event) {
p$.sendUserMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet.apply(this, [(I$[2]||$incl$(2)).parameterSet$edu_colorado_phet_common_phetcommon_simsharing_messages_IParameterKey$Z((I$[1]||$incl$(1)).isSelected, this.isSelected())]);
C$.superclazz.prototype.fireActionPerformed$java_awt_event_ActionEvent.apply(this, [event]);
});

Clazz.newMeth(C$, 'sendUserMessage$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet', function (parameterSet) {
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:50
