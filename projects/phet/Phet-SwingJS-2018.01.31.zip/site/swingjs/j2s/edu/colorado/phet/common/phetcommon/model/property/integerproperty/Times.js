(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.property.integerproperty"),I$=[['edu.colorado.phet.common.phetcommon.model.property.integerproperty.Times$1']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Times", null, 'edu.colorado.phet.common.phetcommon.model.property.integerproperty.CompositeIntegerProperty');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty', function (a, b) {
C$.superclazz.c$$edu_colorado_phet_common_phetcommon_util_function_Function0$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA.apply(this, [((
(function(){var C$=Clazz.newClass(P$, "Times$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.Function0', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, '$apply', function () {
return new Integer((this.$finals.a.get()).intValue() * (this.$finals.b.get()).intValue());
});
})()
), Clazz.new_((I$[1]||$incl$(1)).$init$, [this, {a: a, b: b}])), [a, b]]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:49
