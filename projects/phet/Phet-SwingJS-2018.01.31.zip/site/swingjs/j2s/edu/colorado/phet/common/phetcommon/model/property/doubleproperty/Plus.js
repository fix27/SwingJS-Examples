(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.property.doubleproperty"),I$=[['edu.colorado.phet.common.phetcommon.model.property.doubleproperty.Plus$1']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Plus", null, 'edu.colorado.phet.common.phetcommon.model.property.doubleproperty.CompositeDoubleProperty');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA', function (terms) {
C$.superclazz.c$$edu_colorado_phet_common_phetcommon_util_function_Function0$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA.apply(this, [((
(function(){var C$=Clazz.newClass(P$, "Plus$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.Function0', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, '$apply', function () {
var sum = 0.0;
for (var term, $term = 0, $$term = this.$finals.terms; $term<$$term.length&&((term=$$term[$term]),1);$term++) {
sum = sum + (term.get()).doubleValue();
}
return new Double(sum);
});
})()
), Clazz.new_((I$[1]||$incl$(1)).$init$, [this, {terms: terms}])), terms]);
C$.$init$.apply(this);
}, 1);
})();
//Created 2018-01-31 11:02:48
