(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.dialogs"),I$=[];
var C$=Clazz.newClass(P$, "CreditsDialog", null, 'edu.colorado.phet.common.phetcommon.application.PaintImmediateDialog');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:45
