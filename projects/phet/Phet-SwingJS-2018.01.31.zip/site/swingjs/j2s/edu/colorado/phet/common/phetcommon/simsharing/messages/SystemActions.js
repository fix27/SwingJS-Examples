(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.messages"),I$=[];
var C$=Clazz.newClass(P$, "SystemActions", null, 'Enum', 'edu.colorado.phet.common.phetcommon.simsharing.messages.ISystemAction');

C$.$clinit$ = function() {Clazz.load(C$, 1);
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "started", 0, []);
Clazz.newEnumConst($vals, C$.c$, "stopped", 1, []);
Clazz.newEnumConst($vals, C$.c$, "sentEvent", 2, []);
Clazz.newEnumConst($vals, C$.c$, "exited", 3, []);
Clazz.newEnumConst($vals, C$.c$, "shown", 4, []);
Clazz.newEnumConst($vals, C$.c$, "ipAddressLookup", 5, []);
Clazz.newEnumConst($vals, C$.c$, "mountainTimeLookup", 6, []);
Clazz.newEnumConst($vals, C$.c$, "closed", 7, []);
Clazz.newEnumConst($vals, C$.c$, "windowClosing", 8, []);
Clazz.newEnumConst($vals, C$.c$, "windowClosed", 9, []);
Clazz.newEnumConst($vals, C$.c$, "windowOpened", 10, []);
Clazz.newEnumConst($vals, C$.c$, "resized", 11, []);
Clazz.newEnumConst($vals, C$.c$, "activated", 12, []);
Clazz.newEnumConst($vals, C$.c$, "deactivated", 13, []);
Clazz.newEnumConst($vals, C$.c$, "iconified", 14, []);
Clazz.newEnumConst($vals, C$.c$, "deiconified", 15, []);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values', function() { return $vals }, 1);
})();
//Created 2018-01-31 11:02:51
