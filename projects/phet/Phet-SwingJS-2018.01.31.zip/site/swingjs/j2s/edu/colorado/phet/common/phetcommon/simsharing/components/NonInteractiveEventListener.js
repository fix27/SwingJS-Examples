(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.components"),I$=[['edu.colorado.phet.common.phetcommon.simsharing.messages.UserComponentTypes']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "NonInteractiveEventListener", null, 'javax.swing.event.MouseInputAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.userComponent = null;
this.userComponentType = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent', function (userComponent) {
C$.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponentType.apply(this, [userComponent, (I$[1]||$incl$(1)).sprite]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponentType', function (userComponent, userComponentType) {
Clazz.super_(C$, this,1);
this.userComponent = userComponent;
this.userComponentType = userComponentType;
}, 1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (event) {
C$.superclazz.prototype.mousePressed$java_awt_event_MouseEvent.apply(this, [event]);
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:49
