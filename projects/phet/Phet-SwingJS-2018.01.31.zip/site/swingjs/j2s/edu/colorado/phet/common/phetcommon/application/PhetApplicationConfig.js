(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.application"),I$=[[['edu.colorado.phet.common.phetcommon.view.util.FrameSetup','.CenteredWithSize'],'edu.colorado.phet.common.phetcommon.resources.PhetResources','edu.colorado.phet.common.phetcommon.view.PhetLookAndFeel','java.util.Locale','edu.colorado.phet.common.phetcommon.view.util.StringUtil','java.util.Arrays']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "PhetApplicationConfig", null, null, 'edu.colorado.phet.common.phetcommon.application.ISimInfo');
C$.DEFAULT_FRAME_SETUP = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.DEFAULT_FRAME_SETUP = Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[1024, 768]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.commandLineArgs = null;
this.flavor = null;
this.resourceLoader = null;
this.frameSetup = null;
this.phetLookAndFeel = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$SA$S', function (commandLineArgs, project) {
C$.c$$SA$S$S.apply(this, [commandLineArgs, project, project]);
}, 1);

Clazz.newMeth(C$, 'c$$SA$S$S', function (commandLineArgs, project, flavor) {
C$.$init$.apply(this);
this.commandLineArgs = commandLineArgs;
var language = this.getOptionArg$S("--locale");
if (language != null ) C$.setDefaultLocale$S(language);
this.flavor = flavor;
this.resourceLoader = Clazz.new_((I$[2]||$incl$(2)).c$$S,[project]);
this.frameSetup = C$.DEFAULT_FRAME_SETUP;
this.phetLookAndFeel = Clazz.new_((I$[3]||$incl$(3)));
}, 1);

Clazz.newMeth(C$, 'setDefaultLocale$S', function (language) {
var region;
var country;
language = language.$replace("-", "_");
if (language.length$() == 0 || language.equalsIgnoreCase$S("en") ) language = "en_US";
var i = language.indexOf("_");
if (i > 0) {
country = language.substring(0, i);
region = language.substring(i + 1);
} else {
country = language;
region = "";
}region = region.toUpperCase();
(I$[4]||$incl$(4)).setDefault$java_util_Locale(Clazz.new_((I$[4]||$incl$(4)).c$$S$S,[language, country]));
}, 1);

Clazz.newMeth(C$, 'getCommandLineArgs', function () {
return this.commandLineArgs;
});

Clazz.newMeth(C$, 'hasCommandLineArg$S', function (arg) {
return (I$[5]||$incl$(5)).contains$SA$S(this.commandLineArgs, arg);
});

Clazz.newMeth(C$, 'getOptionArg$S', function (option) {
var s = (I$[6]||$incl$(6)).asList$TTA(this.commandLineArgs).indexOf$O(option);
if (s >= 0 && s <= this.commandLineArgs.length - 2  && !this.commandLineArgs[s + 1].startsWith$S("-") ) {
return this.commandLineArgs[s + 1];
} else {
return null;
}});

Clazz.newMeth(C$, 'setFrameSetup$edu_colorado_phet_common_phetcommon_view_util_FrameSetup', function (frameSetup) {
this.frameSetup = frameSetup;
});

Clazz.newMeth(C$, 'getFrameSetup', function () {
return this.frameSetup;
});

Clazz.newMeth(C$, 'getFlavor', function () {
return this.flavor;
});

Clazz.newMeth(C$, 'setLookAndFeel$edu_colorado_phet_common_phetcommon_view_PhetLookAndFeel', function (phetLookAndFeel) {
this.phetLookAndFeel = phetLookAndFeel;
});

Clazz.newMeth(C$, 'getLookAndFeel', function () {
return this.phetLookAndFeel;
});

Clazz.newMeth(C$, 'getResourceLoader', function () {
return this.resourceLoader;
});

Clazz.newMeth(C$, 'getProjectName', function () {
return this.resourceLoader.getProjectName();
});

Clazz.newMeth(C$, 'isPreferencesEnabled', function () {
return this.isStatisticsFeatureIncluded() || this.isUpdatesFeatureIncluded() ;
});

Clazz.newMeth(C$, 'getDistributionTag', function () {
return this.resourceLoader.getDistributionTag();
});

Clazz.newMeth(C$, 'getName', function () {
return this.resourceLoader.getName$S(this.flavor);
});

Clazz.newMeth(C$, 'getVersionForTitleBar', function () {
return this.getVersion().formatForTitleBar();
});

Clazz.newMeth(C$, 'getVersion', function () {
return this.resourceLoader.getVersion();
});

Clazz.newMeth(C$, 'isDev', function () {
return this.hasCommandLineArg$S("-dev");
});

Clazz.newMeth(C$, 'getLocale', function () {
return (I$[2]||$incl$(2)).readLocale();
});

Clazz.newMeth(C$, 'isUpdatesFeatureIncluded', function () {
return false;
});

Clazz.newMeth(C$, 'isStatisticsFeatureIncluded', function () {
return false;
});

Clazz.newMeth(C$, 'isUpdatesEnabled', function () {
return false;
});

Clazz.newMeth(C$, 'isStatisticsEnabled', function () {
return false;
});

Clazz.newMeth(C$, 'isSponsorFeatureEnabled', function () {
return !this.hasCommandLineArg$S("-sponsor-off");
});

Clazz.newMeth(C$, 'isAskFeatureEnabled', function () {
return this.hasCommandLineArg$S("-ask");
});

Clazz.newMeth(C$, 'getProjectJarName$S', function (project) {
return project + "_all.jar";
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:44
