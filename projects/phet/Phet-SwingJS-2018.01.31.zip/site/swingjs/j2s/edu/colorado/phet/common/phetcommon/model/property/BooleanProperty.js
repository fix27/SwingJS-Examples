(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.property"),I$=[['edu.colorado.phet.common.phetcommon.model.property.And','edu.colorado.phet.common.phetcommon.model.property.Or']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "BooleanProperty", null, 'edu.colorado.phet.common.phetcommon.model.property.Property');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$Boolean', function (value) {
C$.superclazz.c$$TT.apply(this, [value]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'and$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty', function (p) {
return Clazz.new_((I$[1]||$incl$(1)).c$$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA,[[this, p]]);
});

Clazz.newMeth(C$, 'or$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty', function (p) {
return Clazz.new_((I$[2]||$incl$(2)).c$$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA,[[this, p]]);
});

Clazz.newMeth(C$, 'toggle', function () {
this.set$TT(new Boolean(!(this.get()).booleanValue()));
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:48
