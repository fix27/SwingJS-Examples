(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.mechanics"),I$=[];
var C$=Clazz.newClass(P$, "Vector3D", null, 'edu.colorado.phet.common.mechanics.PhysicalVector');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'createCrossProduct$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D', function (v1, v2) {
var z = v1.magnitude() * v2.magnitude() * Math.sin(v2.getAngle() - v1.getAngle()) ;
return Clazz.new_(C$.c$$D$D$D,[0, 0, z]);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$D$D$D.apply(this, [0, 0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D', function (vector) {
C$.c$$D$D$D.apply(this, [vector.getX(), vector.getY(), 0]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_mechanics_Vector3D', function (vector) {
C$.c$$D$D$D.apply(this, [vector.getX(), vector.getY(), vector.getZ()]);
}, 1);

Clazz.newMeth(C$, 'c$$D$D$D', function (x, y, z) {
C$.superclazz.c$$I.apply(this, [3]);
C$.$init$.apply(this);
this.setX$D(x);
this.setY$D(y);
this.setZ$D(z);
if (Double.isNaN(x)) {
System.out.println$S("Vector2D constructor: x was NaN");
}if (Double.isNaN(y)) {
System.out.println$S("Vector2D constructor: y was NaN");
}}, 1);

Clazz.newMeth(C$, 'toString', function () {
return "[ " + new Double(this.getX()).toString() + " " + new Double(this.getY()).toString() + " " + new Double(this.getZ()).toString() + "]" ;
});

Clazz.newMeth(C$, 'setComponents$D$D$D', function (x, y, z) {
this.setX$D(x);
this.setY$D(y);
this.setZ$D(z);
return this;
});

Clazz.newMeth(C$, 'setComponents$edu_colorado_phet_common_mechanics_Vector3D', function (that) {
this.setComponents$D$D$D(that.getX(), that.getY(), that.getZ());
return this;
});

Clazz.newMeth(C$, 'getX', function () {
return this.getScalarAt$I(0);
});

Clazz.newMeth(C$, 'setX$D', function (x) {
this.setScalarAt$I$D(0, x);
});

Clazz.newMeth(C$, 'getY', function () {
return this.getScalarAt$I(1);
});

Clazz.newMeth(C$, 'setY$D', function (y) {
this.setScalarAt$I$D(1, y);
});

Clazz.newMeth(C$, 'getZ', function () {
return this.getScalarAt$I(2);
});

Clazz.newMeth(C$, 'setZ$D', function (z) {
this.setScalarAt$I$D(2, z);
});

Clazz.newMeth(C$, 'add$edu_colorado_phet_common_mechanics_Vector3D', function (that) {
return C$.superclazz.prototype.add$edu_colorado_phet_common_mechanics_PhysicalVector$edu_colorado_phet_common_mechanics_PhysicalVector.apply(this, [that, this]);
});

Clazz.newMeth(C$, 'normalize', function () {
return C$.superclazz.prototype.generalNormalize.apply(this, []);
});

Clazz.newMeth(C$, 'multiply$D', function (scale) {
return C$.superclazz.prototype.multiply$D$edu_colorado_phet_common_mechanics_PhysicalVector.apply(this, [scale, this]);
});

Clazz.newMeth(C$, 'subtract$edu_colorado_phet_common_mechanics_Vector3D', function (that) {
return C$.superclazz.prototype.subtract$edu_colorado_phet_common_mechanics_PhysicalVector$edu_colorado_phet_common_mechanics_PhysicalVector.apply(this, [that, this]);
});

Clazz.newMeth(C$, 'subtract$D$D$D', function (x, y, z) {
var temp = Clazz.new_(C$.c$$D$D$D,[x, y, z]);
return this.subtract$edu_colorado_phet_common_mechanics_Vector3D(temp);
});

Clazz.newMeth(C$, 'crossProduct$edu_colorado_phet_common_mechanics_Vector3D', function (that) {
var result = Clazz.new_(C$.c$$D$D$D,[this.getY() * that.getZ() - this.getZ() * that.getY(), -this.getX() * that.getZ() + this.getZ() * that.getX(), this.getX() * that.getY() - this.getY() * that.getX()]);
return result;
});
})();
//Created 2018-01-31 11:02:44
