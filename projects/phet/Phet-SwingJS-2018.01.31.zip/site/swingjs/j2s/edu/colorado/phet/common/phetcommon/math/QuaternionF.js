(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[['edu.colorado.phet.common.phetcommon.math.vector.Vector3F','edu.colorado.phet.common.phetcommon.math.Matrix3F']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "QuaternionF");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x = 0;
this.y = 0;
this.z = 0;
this.w = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'hashCode', function () {
return Float.floatToIntBits(this.x) ^ Float.floatToIntBits(this.y) ^ Float.floatToIntBits(this.z) ^ Float.floatToIntBits(this.w) ;
});

Clazz.newMeth(C$, 'equals$O', function (o) {
if (!(Clazz.instanceOf(o, "edu.colorado.phet.common.phetcommon.math.QuaternionF"))) {
return false;
}var m = o;
return (m.x == this.x  && m.y == this.y   && m.z == this.z   && m.w == this.w  );
});

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.x = 0;
this.y = 0;
this.z = 0;
this.w = 1;
}, 1);

Clazz.newMeth(C$, 'c$$F$F$F$F', function (x, y, z, w) {
C$.$init$.apply(this);
this.x = x;
this.y = y;
this.z = z;
this.w = w;
}, 1);

Clazz.newMeth(C$, 'plus$edu_colorado_phet_common_phetcommon_math_QuaternionF', function (quat) {
return Clazz.new_(C$.c$$F$F$F$F,[this.x + quat.x, this.y + quat.y, this.z + quat.z, this.w + quat.w]);
});

Clazz.newMeth(C$, 'times$F', function (f) {
return Clazz.new_(C$.c$$F$F$F$F,[this.x * f, this.y * f, this.z * f, this.w * f]);
});

Clazz.newMeth(C$, 'times$edu_colorado_phet_common_phetcommon_math_QuaternionF', function (quat) {
return Clazz.new_(C$.c$$F$F$F$F,[this.x * quat.w - this.z * quat.y + this.y * quat.z + this.w * quat.x, -this.x * quat.z + this.y * quat.w + this.z * quat.x + this.w * quat.y, this.x * quat.y - this.y * quat.x + this.z * quat.w + this.w * quat.z, -this.x * quat.x - this.y * quat.y - this.z * quat.z + this.w * quat.w]);
});

Clazz.newMeth(C$, 'times$edu_colorado_phet_common_phetcommon_math_vector_Vector3F', function (v) {
if (v.magnitude() == 0 ) {
return Clazz.new_((I$[1]||$incl$(1)));
}return Clazz.new_((I$[1]||$incl$(1)).c$$F$F$F,[this.w * this.w * v.x  + 2 * this.y * this.w * v.z  - 2 * this.z * this.w * v.y  + this.x * this.x * v.x  + 2 * this.y * this.x * v.y  + 2 * this.z * this.x * v.z  - this.z * this.z * v.x  - this.y * this.y * v.x , 2 * this.x * this.y * v.x  + this.y * this.y * v.y  + 2 * this.z * this.y * v.z  + 2 * this.w * this.z * v.x  - this.z * this.z * v.y  + this.w * this.w * v.y  - 2 * this.x * this.w * v.z  - this.x * this.x * v.y , 2 * this.x * this.z * v.x  + 2 * this.y * this.z * v.y  + this.z * this.z * v.z  - 2 * this.w * this.y * v.x  - this.y * this.y * v.z  + 2 * this.w * this.x * v.y  - this.x * this.x * v.z  + this.w * this.w * v.z ]);
});

Clazz.newMeth(C$, 'magnitude', function () {
return Math.sqrt(this.magnitudeSquared());
});

Clazz.newMeth(C$, 'magnitudeSquared', function () {
return this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w;
});

Clazz.newMeth(C$, 'normalized', function () {
var magnitude = this.magnitude();
if (magnitude == 0 ) {
throw Clazz.new_(Clazz.load('java.lang.UnsupportedOperationException').c$$S,["Cannot normalize a zero-magnitude quaternion."]);
}return this.times$F(1 / magnitude);
});

Clazz.newMeth(C$, 'negated', function () {
return Clazz.new_(C$.c$$F$F$F$F,[-this.x, -this.y, -this.z, -this.w]);
});

Clazz.newMeth(C$, 'fromEulerAngles$F$F$F', function (yaw, roll, pitch) {
var sinPitch = Math.sin(pitch * 0.5);
var cosPitch = Math.cos(pitch * 0.5);
var sinRoll = Math.sin(roll * 0.5);
var cosRoll = Math.cos(roll * 0.5);
var sinYaw = Math.sin(yaw * 0.5);
var cosYaw = Math.cos(yaw * 0.5);
var a = cosRoll * cosPitch;
var b = sinRoll * sinPitch;
var c = cosRoll * sinPitch;
var d = sinRoll * cosPitch;
return Clazz.new_(C$.c$$F$F$F$F,[a * sinYaw + b * cosYaw, d * cosYaw + c * sinYaw, c * cosYaw - d * sinYaw, a * cosYaw - b * sinYaw]);
}, 1);

Clazz.newMeth(C$, 'toRotationMatrix', function () {
var norm = this.magnitudeSquared();
var flip = (norm == 1.0 ) ? 2.0 : (norm > 0.0 ) ? 2.0 / norm : 0;
var xx = this.x * this.x * flip ;
var xy = this.x * this.y * flip ;
var xz = this.x * this.z * flip ;
var xw = this.w * this.x * flip ;
var yy = this.y * this.y * flip ;
var yz = this.y * this.z * flip ;
var yw = this.w * this.y * flip ;
var zz = this.z * this.z * flip ;
var zw = this.w * this.z * flip ;
return (I$[2]||$incl$(2)).columnMajor$F$F$F$F$F$F$F$F$F(1 - (yy + zz), (xy + zw), (xz - yw), (xy - zw), 1 - (xx + zz), (yz + xw), (xz + yw), (yz - xw), 1 - (xx + yy));
});

Clazz.newMeth(C$, 'fromRotationMatrix$edu_colorado_phet_common_phetcommon_math_Matrix3F', function (matrix) {
var v00 = matrix.v00;
var v01 = matrix.v01;
var v02 = matrix.v02;
var v10 = matrix.v10;
var v11 = matrix.v11;
var v12 = matrix.v12;
var v20 = matrix.v20;
var v21 = matrix.v21;
var v22 = matrix.v22;
var trace = v00 + v11 + v22 ;
var sqt;
if (trace >= 0 ) {
sqt = Math.sqrt(trace + 1);
return Clazz.new_(C$.c$$F$F$F$F,[(v21 - v12) * 0.5 / sqt, (v02 - v20) * 0.5 / sqt, (v10 - v01) * 0.5 / sqt, 0.5 * sqt]);
} else if ((v00 > v11 ) && (v00 > v22 ) ) {
sqt = Math.sqrt(1.0 + v00 - v11 - v22);
return Clazz.new_(C$.c$$F$F$F$F,[sqt * 0.5, (v10 + v01) * 0.5 / sqt, (v02 + v20) * 0.5 / sqt, (v21 - v12) * 0.5 / sqt]);
} else if (v11 > v22 ) {
sqt = Math.sqrt(1.0 + v11 - v00 - v22);
return Clazz.new_(C$.c$$F$F$F$F,[(v10 + v01) * 0.5 / sqt, sqt * 0.5, (v21 + v12) * 0.5 / sqt, (v02 - v20) * 0.5 / sqt]);
} else {
sqt = Math.sqrt(1.0 + v22 - v00 - v11);
return Clazz.new_(C$.c$$F$F$F$F,[(v02 + v20) * 0.5 / sqt, (v21 + v12) * 0.5 / sqt, sqt * 0.5, (v10 - v01) * 0.5 / sqt]);
}}, 1);

Clazz.newMeth(C$, 'getRotationQuaternion$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F', function (a, b) {
return C$.fromRotationMatrix$edu_colorado_phet_common_phetcommon_math_Matrix3F((I$[2]||$incl$(2)).rotateAToB$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F(a, b));
}, 1);

Clazz.newMeth(C$, 'slerp$edu_colorado_phet_common_phetcommon_math_QuaternionF$edu_colorado_phet_common_phetcommon_math_QuaternionF$F', function (a, b, t) {
if (a.x == b.x  && a.y == b.y   && a.z == b.z   && a.w == b.w  ) {
return a;
}var dot = (a.x * b.x) + (a.y * b.y) + (a.z * b.z) + (a.w * b.w) ;
if (dot < 0.0 ) {
b = b.negated();
dot = -dot;
}var ratioA = 1 - t;
var ratioB = t;
if ((1 - dot) > 0.1 ) {
var theta = Math.acos(dot);
var invSinTheta = (1.0 / Math.sin(theta));
ratioA = (Math.sin((1 - t) * theta) * invSinTheta);
ratioB = (Math.sin((t * theta)) * invSinTheta);
}return Clazz.new_(C$.c$$F$F$F$F,[(ratioA * a.x) + (ratioB * b.x), (ratioA * a.y) + (ratioB * b.y), (ratioA * a.z) + (ratioB * b.z), (ratioA * a.w) + (ratioB * b.w)]);
}, 1);
})();
//Created 2018-01-31 11:02:46
