(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[['edu.colorado.phet.common.phetcommon.math.PolynomialTerm','java.util.ArrayList','java.util.Arrays','java.lang.StringBuffer']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Polynomial");
C$.ZERO = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.ZERO = Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_math_PolynomialTermA,[Clazz.array((I$[1]||$incl$(1)), -1, [(I$[1]||$incl$(1)).ZERO])]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.terms = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I', function (constant) {
C$.c$$edu_colorado_phet_common_phetcommon_math_PolynomialTermA.apply(this, [Clazz.array((I$[1]||$incl$(1)), -1, [Clazz.new_((I$[1]||$incl$(1)).c$$I,[constant])])]);
}, 1);

Clazz.newMeth(C$, 'c$$java_util_Collection', function (sparseTerms) {
C$.c$$edu_colorado_phet_common_phetcommon_math_PolynomialTermA.apply(this, [sparseTerms.toArray$TTA(Clazz.array((I$[1]||$incl$(1)), [sparseTerms.size()]))]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_PolynomialTermA', function (sparseTerms) {
C$.$init$.apply(this);
if (sparseTerms.length == 0) {
this.terms = Clazz.array((I$[1]||$incl$(1)), -1, [(I$[1]||$incl$(1)).ZERO]);
} else {
var min = 2147483647;
var max = -2147483648;
for (var i = 0; i < sparseTerms.length; i++) {
var sparseTerm = sparseTerms[i];
if (sparseTerm.getPower() < min) {
min = sparseTerm.getPower();
}if (sparseTerm.getPower() > max) {
max = sparseTerm.getPower();
}}
var total = max + 1;
this.terms = Clazz.array((I$[1]||$incl$(1)), [total]);
for (var i = 0; i < this.terms.length; i++) {
this.terms[i] = Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[i, 0]);
}
for (var i = 0; i < sparseTerms.length; i++) {
var sparseTerm = sparseTerms[i];
var pow = sparseTerm.getPower();
this.terms[pow] = this.terms[pow].plus$edu_colorado_phet_common_phetcommon_math_PolynomialTerm(sparseTerm);
}
}}, 1);

Clazz.newMeth(C$, 'parsePolynomial$S', function (sparseTerms) {
var polynomialTerms = Clazz.new_((I$[2]||$incl$(2)));
var matcher = (I$[1]||$incl$(1)).EXPR_PATTERN.matcher$CharSequence(sparseTerms);
while (matcher.find()){
polynomialTerms.add$TE((I$[1]||$incl$(1)).parsePolynomialTerm$S(matcher.group()));
}
return Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_math_PolynomialTermA,[polynomialTerms.toArray$TTA(Clazz.array((I$[1]||$incl$(1)), [polynomialTerms.size()]))]);
}, 1);

Clazz.newMeth(C$, 'getTerms', function () {
return this.terms.clone();
});

Clazz.newMeth(C$, 'eval$D', function (x) {
var sum = 0.0;
for (var i = 0; i < this.terms.length; i++) {
sum += this.terms[i].eval$D(x);
}
return sum;
});

Clazz.newMeth(C$, 'plus$edu_colorado_phet_common_phetcommon_math_Polynomial', function (that) {
var allTerms = Clazz.new_((I$[2]||$incl$(2)));
allTerms.addAll$java_util_Collection((I$[3]||$incl$(3)).asList$TTA(this.terms));
allTerms.addAll$java_util_Collection((I$[3]||$incl$(3)).asList$TTA(that.terms));
return Clazz.new_(C$.c$$java_util_Collection,[allTerms]);
});

Clazz.newMeth(C$, 'derive$I', function (times) {
var p = this;
for (var i = 0; i < times; i++) {
p = p.derive();
}
return p;
});

Clazz.newMeth(C$, 'derive', function () {
var terms = Clazz.new_((I$[2]||$incl$(2)));
terms.addAll$java_util_Collection((I$[3]||$incl$(3)).asList$TTA(this.terms));
for (var i = 0; i < terms.size(); i++) {
terms.set$I$TE(i, terms.get$I(i).derive());
}
return Clazz.new_(C$.c$$java_util_Collection,[terms]);
});

Clazz.newMeth(C$, 'times$edu_colorado_phet_common_phetcommon_math_PolynomialTerm', function (term) {
var mulTerms = Clazz.array((I$[1]||$incl$(1)), [this.terms.length]);
for (var i = 0; i < this.terms.length; i++) {
mulTerms[i] = term.times$edu_colorado_phet_common_phetcommon_math_PolynomialTerm(this.terms[i]);
}
return Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_math_PolynomialTermA,[mulTerms]);
});

Clazz.newMeth(C$, 'times$edu_colorado_phet_common_phetcommon_math_Polynomial', function (that) {
var allTerms = Clazz.new_((I$[2]||$incl$(2)));
for (var i = 0; i < this.terms.length; i++) {
for (var j = 0; j < that.terms.length; j++) {
allTerms.add$TE(this.terms[i].times$edu_colorado_phet_common_phetcommon_math_PolynomialTerm(that.terms[j]));
}
}
return Clazz.new_(C$.c$$java_util_Collection,[allTerms]);
});

Clazz.newMeth(C$, 'pow$I', function (n) {
if (n < 0) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException'));
}var result = Clazz.new_(C$.c$$I,[1]);
for (var i = 0; i < n; i++) {
result = result.times$edu_colorado_phet_common_phetcommon_math_Polynomial(this);
}
return result;
});

Clazz.newMeth(C$, 'toString', function () {
var buffer = Clazz.new_((I$[4]||$incl$(4)));
for (var i = 0; i < this.terms.length; i++) {
var isFirst = i == 0;
if (!isFirst) {
buffer.append$S(" + ");
}buffer.append$S(this.terms[i].toString());
}
return buffer.toString();
});

Clazz.newMeth(C$, 'equals$O', function (o) {
if (this === o ) {
return true;
}if (o == null  || this.getClass() !== o.getClass()  ) {
return false;
}var that = o;
if (!(I$[3]||$incl$(3)).equals$OA$OA(this.terms, that.terms)) {
return false;
}return true;
});

Clazz.newMeth(C$, 'hashCode', function () {
var hashCode = 0;
for (var i = 0; i < this.terms.length; i++) {
hashCode = hashCode+(this.terms[i].hashCode());
}
return hashCode;
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:46
