(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.logs"),I$=[];
var C$=Clazz.newClass(P$, "ConsoleLog", null, null, 'edu.colorado.phet.common.phetcommon.simsharing.Log');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'addMessage$edu_colorado_phet_common_phetcommon_simsharing_SimSharingMessage', function (message) {
System.out.println$O(message);
});

Clazz.newMeth(C$, 'getName', function () {
return "Java Console";
});

Clazz.newMeth(C$, 'shutdown', function () {
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:50
