(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing"),I$=[];
var C$=Clazz.newClass(P$, "SimSharingMessage");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.messageType = null;
this.component = null;
this.componentType = null;
this.action = null;
this.parameters = null;
this.time = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.time = System.currentTimeMillis();
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IMessageType$TT$TU$TV$edu_colorado_phet_common_phetcommon_simsharing_messages_ParameterSet', function (messageType, component, componentType, action, parameters) {
C$.$init$.apply(this);
this.messageType = messageType;
this.component = component;
this.componentType = componentType;
this.action = action;
this.parameters = parameters;
}, 1);

Clazz.newMeth(C$, 'toString', function () {
return this.time + "\u0009" + this.messageType + "\u0009" + this.component + "\u0009" + this.componentType + "\u0009" + this.action + "\u0009" + this.parameters.toString$S("\u0009") ;
});
;
(function(){var C$=Clazz.newClass(P$.SimSharingMessage, "MessageType", null, 'Enum', 'edu.colorado.phet.common.phetcommon.simsharing.messages.IMessageType');

C$.$clinit$ = function() {Clazz.load(C$, 1);
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "user", 0, []);
Clazz.newEnumConst($vals, C$.c$, "system", 1, []);
Clazz.newEnumConst($vals, C$.c$, "model", 2, []);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values', function() { return $vals }, 1);
})()

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:49
