(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.logs"),I$=[['edu.colorado.phet.common.phetcommon.model.property.Property']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "StringLog", null, null, 'edu.colorado.phet.common.phetcommon.simsharing.Log');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.log = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.log = Clazz.new_((I$[1]||$incl$(1)).c$$TT,[""]);
}, 1);

Clazz.newMeth(C$, 'addMessage$edu_colorado_phet_common_phetcommon_simsharing_SimSharingMessage', function (message) {
if (this.log.get().length$() != 0) {
this.log.set$TT(this.log.get() + "\n");
}this.log.set$TT(this.log.get() + message);
});

Clazz.newMeth(C$, 'getName', function () {
return "Internal buffer";
});

Clazz.newMeth(C$, 'shutdown', function () {
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:50
