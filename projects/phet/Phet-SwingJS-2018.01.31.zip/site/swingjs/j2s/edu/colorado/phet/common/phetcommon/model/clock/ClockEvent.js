(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.clock"),I$=[];
var C$=Clazz.newClass(P$, "ClockEvent");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.clock = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_model_clock_IClock', function (clock) {
C$.$init$.apply(this);
this.clock = clock;
}, 1);

Clazz.newMeth(C$, 'getClock', function () {
return this.clock;
});

Clazz.newMeth(C$, 'getWallTimeChange', function () {
return this.clock.getWallTimeChange();
});

Clazz.newMeth(C$, 'getSimulationTimeChange', function () {
return this.clock.getSimulationTimeChange();
});

Clazz.newMeth(C$, 'getSimulationTime', function () {
return this.clock.getSimulationTime();
});

Clazz.newMeth(C$, 'getWallTime', function () {
return this.clock.getWallTime();
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:47
