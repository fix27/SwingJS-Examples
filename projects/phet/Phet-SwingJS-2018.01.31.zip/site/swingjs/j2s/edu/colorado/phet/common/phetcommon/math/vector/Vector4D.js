(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math.vector"),I$=[];
var C$=Clazz.newClass(P$, "Vector4D", null, 'edu.colorado.phet.common.phetcommon.math.vector.AbstractVector4D');
C$.ZERO = null;
C$.X_UNIT = null;
C$.Y_UNIT = null;
C$.Z_UNIT = null;
C$.W_UNIT = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.ZERO = Clazz.new_(C$);
C$.X_UNIT = Clazz.new_(C$.c$$D$D$D$D,[1, 0, 0, 0]);
C$.Y_UNIT = Clazz.new_(C$.c$$D$D$D$D,[0, 1, 0, 0]);
C$.Z_UNIT = Clazz.new_(C$.c$$D$D$D$D,[0, 0, 1, 0]);
C$.W_UNIT = Clazz.new_(C$.c$$D$D$D$D,[0, 0, 0, 1]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x = 0;
this.y = 0;
this.z = 0;
this.w = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'hashCode', function () {
return Float.floatToIntBits(this.x) ^ Float.floatToIntBits(this.y) ^ Float.floatToIntBits(this.z) ^ Float.floatToIntBits(this.w) ;
});

Clazz.newMeth(C$, 'equals$O', function (o) {
if (!(Clazz.instanceOf(o, "edu.colorado.phet.common.phetcommon.math.vector.Vector4D"))) {
return false;
}var m = o;
return (m.x == this.x  && m.y == this.y   && m.z == this.z   && m.w == this.w  );
});

Clazz.newMeth(C$, 'c$', function () {
C$.c$$D$D$D.apply(this, [0, 0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3D', function (v) {
C$.c$$D$D$D.apply(this, [v.getX(), v.getY(), v.getZ()]);
}, 1);

Clazz.newMeth(C$, 'c$$D$D$D', function (x, y, z) {
C$.c$$D$D$D$D.apply(this, [x, y, z, 1]);
}, 1);

Clazz.newMeth(C$, 'c$$D$D$D$D', function (x, y, z, w) {
Clazz.super_(C$, this,1);
this.x = x;
this.y = y;
this.z = z;
this.w = w;
}, 1);

Clazz.newMeth(C$, 'getX', function () {
return this.x;
});

Clazz.newMeth(C$, 'getY', function () {
return this.y;
});

Clazz.newMeth(C$, 'getZ', function () {
return this.z;
});

Clazz.newMeth(C$, 'getW', function () {
return this.w;
});
})();
//Created 2018-01-31 11:02:47
