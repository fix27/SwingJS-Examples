(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.property"),I$=[['edu.colorado.phet.common.phetcommon.model.property.SettableNot$1','edu.colorado.phet.common.phetcommon.model.property.And','edu.colorado.phet.common.phetcommon.model.property.BooleanProperty','edu.colorado.phet.common.phetcommon.model.property.SettableNot$2','edu.colorado.phet.common.phetcommon.model.property.SettableNot$3']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SettableNot", null, 'edu.colorado.phet.common.phetcommon.model.property.SettableProperty');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.parent = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_model_property_SettableProperty', function (parent) {
C$.superclazz.c$$TT.apply(this, [new Boolean(!(parent.get()).booleanValue())]);
C$.$init$.apply(this);
this.parent = parent;
parent.addObserver$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1(((
(function(){var C$=Clazz.newClass(P$, "SettableNot$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.VoidFunction1', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['$apply$Boolean','$apply$TT'], function (value) {
this.b$['edu.colorado.phet.common.phetcommon.model.property.SettableNot'].set$Boolean(new Boolean(!(value).booleanValue()));
});
})()
), Clazz.new_((I$[1]||$incl$(1)).$init$, [this, null])));
}, 1);

Clazz.newMeth(C$, ['set$Boolean','set$TT'], function (value) {
this.parent.set$TT(new Boolean(!(value).booleanValue()));
this.notifyIfChanged();
});

Clazz.newMeth(C$, 'get', function () {
return new Boolean(!(this.parent.get()).booleanValue());
});

Clazz.newMeth(C$, 'and$edu_colorado_phet_common_phetcommon_model_property_SettableProperty', function (term) {
return Clazz.new_((I$[2]||$incl$(2)).c$$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA,[[this, term]]);
});

Clazz.newMeth(C$, 'not$edu_colorado_phet_common_phetcommon_model_property_SettableProperty', function (p) {
return Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_model_property_SettableProperty,[p]);
}, 1);

Clazz.newMeth(C$, 'main', function (args) {
var a = Clazz.new_((I$[3]||$incl$(3)).c$$Boolean,[new Boolean(true)]);
a.addObserver$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1(((
(function(){var C$=Clazz.newClass(P$, "SettableNot$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.VoidFunction1', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['$apply$Boolean','$apply$TT'], function (aBoolean) {
System.out.println$S("a = " + aBoolean);
});
})()
), Clazz.new_((I$[4]||$incl$(4)).$init$, [this, null])));
var b = Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_model_property_SettableProperty,[a]);
b.addObserver$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1(((
(function(){var C$=Clazz.newClass(P$, "SettableNot$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.VoidFunction1', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['$apply$Boolean','$apply$TT'], function (aBoolean) {
System.out.println$S("b = " + aBoolean);
});
})()
), Clazz.new_((I$[5]||$incl$(5)).$init$, [this, null])));
System.out.println$S("Setting a to false:");
a.set$TT(new Boolean(false));
System.out.println$S("Setting a to true");
a.set$TT(new Boolean(true));
System.out.println$S("Setting b to true");
b.set$Boolean(new Boolean(true));
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:48
