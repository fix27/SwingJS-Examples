(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.application"),I$=[['java.util.ArrayList','edu.colorado.phet.common.phetcommon.view.PhetExit','edu.colorado.phet.common.phetcommon.application.PhetApplication$1','edu.colorado.phet.common.phetcommon.application.ModuleManager','edu.colorado.phet.common.phetcommon.Interface','edu.colorado.phet.common.phetcommon.util.CommandLineUtils','edu.colorado.phet.common.phetcommon.view.PhetFrame','java.awt.event.WindowAdapter','edu.colorado.phet.common.phetcommon.dialogs.PhetAboutDialog','java.util.Arrays',['edu.colorado.phet.common.phetcommon.util.Option','.Some'],['edu.colorado.phet.common.phetcommon.util.Option','.None']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "PhetApplication", null, null, 'edu.colorado.phet.common.phetcommon.util.IProguardKeepClass');
C$.phetApplications = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.phetApplications = Clazz.new_((I$[1]||$incl$(1)));
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.tabbedModulePane = null;
this.phetApplicationConfig = null;
this.phetFrame = null;
this.moduleManager = null;
this.aboutDialog = null;
this.applicationStarted = false;
this.exitStrategy = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.applicationStarted = false;
this.exitStrategy = ((
(function(){var C$=Clazz.newClass(P$, "PhetApplication$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.VoidFunction0', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, '$apply', function () {
(I$[2]||$incl$(2)).exit();
});
})()
), Clazz.new_((I$[3]||$incl$(3)).$init$, [this, null]));
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig', function (config) {
C$.c$$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig$edu_colorado_phet_common_phetcommon_view_ITabbedModulePane.apply(this, [config, null]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig$edu_colorado_phet_common_phetcommon_view_ITabbedModulePane', function (phetApplicationConfig, tabbedPane) {
C$.$init$.apply(this);
this.phetApplicationConfig = phetApplicationConfig;
this.tabbedModulePane = tabbedPane;
this.moduleManager = Clazz.new_((I$[4]||$incl$(4)).c$$edu_colorado_phet_common_phetcommon_application_PhetApplication,[this]);
this.phetFrame = this.createPhetFrame();
phetApplicationConfig.getFrameSetup().initialize$javax_swing_JFrame(this.phetFrame);
this.parseArgs$SA(phetApplicationConfig.getCommandLineArgs());
C$.phetApplications.add$TE(this);
}, 1);

Clazz.newMeth(C$, 'getTabbedModulePane', function () {
if (this.tabbedModulePane == null ) this.tabbedModulePane = (I$[5]||$incl$(5)).getInstance$S$Z("edu.colorado.phet.common.phetcommon.view.JTabbedModulePane", false);
return this.tabbedModulePane;
});

Clazz.newMeth(C$, 'isDeveloperControlsEnabled', function () {
return (I$[6]||$incl$(6)).contains$SA$S(this.phetApplicationConfig.getCommandLineArgs(), "-dev");
});

Clazz.newMeth(C$, 'getSimInfo', function () {
return this.phetApplicationConfig;
});

Clazz.newMeth(C$, 'getInstance', function () {
return C$.phetApplications.get$I(C$.phetApplications.size() - 1);
}, 1);

Clazz.newMeth(C$, 'createPhetFrame', function () {
return Clazz.new_((I$[7]||$incl$(7)).c$$edu_colorado_phet_common_phetcommon_application_PhetApplication,[this]);
});

Clazz.newMeth(C$, 'parseArgs$SA', function (args) {
});

Clazz.newMeth(C$, 'startApplication', function () {
if (!this.applicationStarted) {
this.applicationStarted = true;
if (this.moduleManager.numModules() == 0) {
throw Clazz.new_(Clazz.load('java.lang.RuntimeException').c$$S,["No modules in module manager"]);
}this.phetFrame.addWindowFocusListener$java_awt_event_WindowFocusListener(((
(function(){var C$=Clazz.newClass(P$, "PhetApplication$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.WindowAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'windowGainedFocus$java_awt_event_WindowEvent', function (e) {
this.b$['edu.colorado.phet.common.phetcommon.application.PhetApplication'].initializeModuleReferenceSizes.apply(this.b$['edu.colorado.phet.common.phetcommon.application.PhetApplication'], []);
this.b$['edu.colorado.phet.common.phetcommon.application.PhetApplication'].phetFrame.removeWindowFocusListener$java_awt_event_WindowFocusListener(this);
});
})()
), Clazz.new_((I$[8]||$incl$(8)), [this, null],P$.PhetApplication$2)));
if (this.isDeveloperControlsEnabled()) {
var startModuleNumber = this.phetApplicationConfig.getOptionArg$S("-startModule");
if (startModuleNumber != null ) {
this.setStartModule$edu_colorado_phet_common_phetcommon_application_Module(this.getModule$I((Integer.$valueOf(startModuleNumber)).intValue()));
}}this.moduleManager.setActiveModule$edu_colorado_phet_common_phetcommon_application_Module(this.getStartModule());
this.phetFrame.setVisible$Z(true);
this.moduleManager.getActiveModule().getHelpPanel().revalidate();
this.updateLogoVisibility();
} else {
System.out.println$S("WARNING: PhetApplication.startApplication was called more than once.");
}});

Clazz.newMeth(C$, 'updateLogoVisibility', function () {
for (var i = 0; i < this.moduleManager.numModules(); i++) {
if (this.moduleAt$I(i).isLogoPanelVisible() && this.phetFrame.getTabbedModulePane() != null   && this.phetFrame.getTabbedModulePane().getLogoVisible() ) {
this.moduleAt$I(i).setLogoPanelVisible$Z(false);
}}
});

Clazz.newMeth(C$, 'initializeModuleReferenceSizes', function () {
for (var i = 0; i < this.moduleManager.numModules(); i++) {
(this.moduleManager.moduleAt$I(i)).setReferenceSize();
}
});

Clazz.newMeth(C$, 'getPhetFrame', function () {
return this.phetFrame;
});

Clazz.newMeth(C$, 'setModules$edu_colorado_phet_common_phetcommon_application_ModuleA', function (modules) {
this.moduleManager.setModules$edu_colorado_phet_common_phetcommon_application_ModuleA(modules);
});

Clazz.newMeth(C$, 'removeModule$edu_colorado_phet_common_phetcommon_application_Module', function (module) {
this.moduleManager.removeModule$edu_colorado_phet_common_phetcommon_application_Module(module);
});

Clazz.newMeth(C$, 'addModule$edu_colorado_phet_common_phetcommon_application_Module', function (module) {
this.moduleManager.addModule$edu_colorado_phet_common_phetcommon_application_Module(module);
});

Clazz.newMeth(C$, 'moduleAt$I', function (i) {
return this.moduleManager.moduleAt$I(i);
});

Clazz.newMeth(C$, 'getModule$I', function (i) {
return this.moduleAt$I(i);
});

Clazz.newMeth(C$, 'setActiveModule$edu_colorado_phet_common_phetcommon_application_Module', function (module) {
this.moduleManager.setActiveModule$edu_colorado_phet_common_phetcommon_application_Module(module);
});

Clazz.newMeth(C$, 'setActiveModule$I', function (i) {
this.moduleManager.setActiveModule$I(i);
});

Clazz.newMeth(C$, 'getStartModule', function () {
var developmentModule = this.getDevelopmentModule();
if (developmentModule.isSome()) {
return this.moduleAt$I((developmentModule.get()).intValue());
} else {
return this.moduleManager.getStartModule();
}});

Clazz.newMeth(C$, 'setStartModule$edu_colorado_phet_common_phetcommon_application_Module', function (module) {
this.moduleManager.setStartModule$edu_colorado_phet_common_phetcommon_application_Module(module);
});

Clazz.newMeth(C$, 'addModuleObserver$edu_colorado_phet_common_phetcommon_application_ModuleObserver', function (moduleObserver) {
this.moduleManager.addModuleObserver$edu_colorado_phet_common_phetcommon_application_ModuleObserver(moduleObserver);
});

Clazz.newMeth(C$, 'removeModuleObserver$edu_colorado_phet_common_phetcommon_application_ModuleObserver', function (moduleObserver) {
this.moduleManager.removeModuleObserver$edu_colorado_phet_common_phetcommon_application_ModuleObserver(moduleObserver);
});

Clazz.newMeth(C$, 'indexOf$edu_colorado_phet_common_phetcommon_application_Module', function (m) {
return this.moduleManager.indexOf$edu_colorado_phet_common_phetcommon_application_Module(m);
});

Clazz.newMeth(C$, 'numModules', function () {
return this.moduleManager.numModules();
});

Clazz.newMeth(C$, 'getActiveModule', function () {
return this.moduleManager.getActiveModule();
});

Clazz.newMeth(C$, 'addModules$edu_colorado_phet_common_phetcommon_application_ModuleA', function (m) {
for (var i = 0; i < m.length; i++) {
this.addModule$edu_colorado_phet_common_phetcommon_application_Module(m[i]);
}
});

Clazz.newMeth(C$, 'getModules', function () {
return this.moduleManager.getModules();
});

Clazz.newMeth(C$, 'pause', function () {
this.getActiveModule().deactivate();
});

Clazz.newMeth(C$, 'resume', function () {
this.getActiveModule().activate();
});

Clazz.newMeth(C$, 'showAboutDialog', function () {
if (this.aboutDialog == null ) {
this.aboutDialog = Clazz.new_((I$[9]||$incl$(9)).c$$edu_colorado_phet_common_phetcommon_application_PhetApplication,[this]);
this.aboutDialog.addWindowListener$java_awt_event_WindowListener(((
(function(){var C$=Clazz.newClass(P$, "PhetApplication$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.WindowAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'windowClosing$java_awt_event_WindowEvent', function (e) {
this.b$['edu.colorado.phet.common.phetcommon.application.PhetApplication'].aboutDialog.dispose();
});

Clazz.newMeth(C$, 'windowClosed$java_awt_event_WindowEvent', function (e) {
this.b$['edu.colorado.phet.common.phetcommon.application.PhetApplication'].aboutDialog = null;
});
})()
), Clazz.new_((I$[8]||$incl$(8)), [this, null],P$.PhetApplication$3)));
this.aboutDialog.setVisible$Z(true);
}});

Clazz.newMeth(C$, 'setControlPanelBackground$java_awt_Color', function (color) {
for (var module, $module = 0, $$module = this.getModules(); $module<$$module.length&&((module=$$module[$module]),1);$module++) {
module.setControlPanelBackground$java_awt_Color(color);
module.setClockControlPanelBackground$java_awt_Color(color);
module.setHelpPanelBackground$java_awt_Color(color);
}
});

Clazz.newMeth(C$, 'save', function () {
});

Clazz.newMeth(C$, 'load', function () {
});

Clazz.newMeth(C$, 'setExitStrategy$edu_colorado_phet_common_phetcommon_util_function_VoidFunction0', function (exitStrategy) {
this.exitStrategy = exitStrategy;
});

Clazz.newMeth(C$, 'exit', function () {
this.exitStrategy.$apply();
});

Clazz.newMeth(C$, 'getDevelopmentModule', function () {
if (this.phetApplicationConfig.isDev()) {
var index = (I$[10]||$incl$(10)).asList$TTA(this.phetApplicationConfig.getCommandLineArgs()).indexOf$O("-module");
if (index >= 0 && index + 1 < this.phetApplicationConfig.getCommandLineArgs().length ) {
var moduleIndexString = this.phetApplicationConfig.getCommandLineArgs()[index + 1];
var moduleIndex = Integer.parseInt(moduleIndexString);
return Clazz.new_((I$[11]||$incl$(11)).c$$TT,[new Integer(moduleIndex)]);
}}return Clazz.new_((I$[12]||$incl$(12)));
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:44
