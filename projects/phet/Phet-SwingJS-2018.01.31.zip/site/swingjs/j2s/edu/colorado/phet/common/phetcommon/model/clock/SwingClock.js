(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.clock"),I$=[[['edu.colorado.phet.common.phetcommon.model.clock.TimingStrategy','.Constant'],'edu.colorado.phet.common.phetcommon.model.clock.SwingClock$1','javax.swing.Timer','Thread','edu.colorado.phet.common.phetcommon.model.clock.SwingClock$2','javax.swing.JFrame']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SwingClock", null, 'edu.colorado.phet.common.phetcommon.model.clock.Clock');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.timer = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I$D', function (delay, dt) {
C$.c$$I$edu_colorado_phet_common_phetcommon_model_clock_TimingStrategy.apply(this, [delay, Clazz.new_((I$[1]||$incl$(1)).c$$D,[dt])]);
}, 1);

Clazz.newMeth(C$, 'c$$I$edu_colorado_phet_common_phetcommon_model_clock_TimingStrategy', function (delay, timingStrategy) {
C$.superclazz.c$$edu_colorado_phet_common_phetcommon_model_clock_TimingStrategy.apply(this, [timingStrategy]);
C$.$init$.apply(this);
var actionListener = ((
(function(){var C$=Clazz.newClass(P$, "SwingClock$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
if (!this.b$['edu.colorado.phet.common.phetcommon.model.clock.SwingClock'].isPaused()) {
this.b$['edu.colorado.phet.common.phetcommon.model.clock.SwingClock'].doTick();
}});
})()
), Clazz.new_((I$[2]||$incl$(2)).$init$, [this, null]));
this.timer = Clazz.new_((I$[3]||$incl$(3)).c$$I$java_awt_event_ActionListener,[delay, actionListener]);
}, 1);

Clazz.newMeth(C$, 'setCoalesce$Z', function (coalesce) {
this.timer.setCoalesce$Z(coalesce);
});

Clazz.newMeth(C$, 'start', function () {
if (this.isPaused()) {
this.timer.start();
C$.superclazz.prototype.notifyClockStarted.apply(this, []);
}});

Clazz.newMeth(C$, 'pause', function () {
if (this.isRunning()) {
this.timer.stop();
C$.superclazz.prototype.notifyClockPaused.apply(this, []);
}});

Clazz.newMeth(C$, 'isPaused', function () {
return !this.timer.isRunning();
});

Clazz.newMeth(C$, 'isRunning', function () {
return this.timer.isRunning();
});

Clazz.newMeth(C$, 'setDelay$I', function (delay) {
this.timer.setDelay$I(delay);
});

Clazz.newMeth(C$, 'getDelay', function () {
return this.timer.getDelay();
});

Clazz.newMeth(C$, 'getTimer', function () {
return this.timer;
});

Clazz.newMeth(C$, 'main', function (args) {
var startTime = System.currentTimeMillis();
var timer = Clazz.new_((I$[3]||$incl$(3)).c$$I$java_awt_event_ActionListener,[1000, ((
(function(){var C$=Clazz.newClass(P$, "SwingClock$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
System.out.println$S("System.currentTimeMillis() = " + (System.currentTimeMillis() - this.$finals.startTime));
try {
(I$[4]||$incl$(4)).sleep$J(1100);
} catch (e1) {
if (Clazz.exceptionOf(e1, "java.lang.InterruptedException")){
e1.printStackTrace();
} else {
throw e1;
}
}
});
})()
), Clazz.new_((I$[5]||$incl$(5)).$init$, [this, {startTime: startTime}]))]);
timer.setCoalesce$Z(false);
timer.start();
Clazz.new_((I$[6]||$incl$(6))).setVisible$Z(true);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:47
