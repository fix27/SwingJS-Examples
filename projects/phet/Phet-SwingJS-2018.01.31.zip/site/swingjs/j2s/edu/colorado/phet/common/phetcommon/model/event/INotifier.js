(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.event"),I$=[];
var C$=Clazz.newInterface(P$, "INotifier");
})();
//Created 2018-01-31 11:02:48
