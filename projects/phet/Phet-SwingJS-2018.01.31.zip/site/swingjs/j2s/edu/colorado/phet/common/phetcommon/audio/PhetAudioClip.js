(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.audio"),I$=[['Thread','java.lang.Thread','edu.colorado.phet.common.phetcommon.audio.PhetAudioClip$1']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "PhetAudioClip");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.url = null;
this.playing = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (resourceName) {
C$.c$$java_net_URL.apply(this, [(I$[1]||$incl$(1)).currentThread().getContextClassLoader().getResource$S(resourceName)]);
}, 1);

Clazz.newMeth(C$, 'c$$java_net_URL', function (url) {
C$.$init$.apply(this);
this.url = url;
}, 1);

Clazz.newMeth(C$, 'play', function () {
p$.startAudioThread.apply(this, []);
});

Clazz.newMeth(C$, 'isPlaying', function () {
return this.playing;
});

Clazz.newMeth(C$, 'startAudioThread', function () {
var playingThread = Clazz.new_((I$[2]||$incl$(2)).c$$Runnable,[((
(function(){var C$=Clazz.newClass(P$, "PhetAudioClip$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'run', function () {
try {
this.b$['edu.colorado.phet.common.phetcommon.audio.PhetAudioClip'].processAudio.apply(this.b$['edu.colorado.phet.common.phetcommon.audio.PhetAudioClip'], []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
});
})()
), Clazz.new_((I$[3]||$incl$(3)).$init$, [this, null]))]);
playingThread.setDaemon$Z(true);
playingThread.start();
});

Clazz.newMeth(C$, 'processAudio', function () {
this.playing = true;
try {
{
swingjs.JSToolkit.playAudioFile$java_net_URL(this.url);
}
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
} finally {
this.playing = false;
}
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:45
