(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[['edu.colorado.phet.common.phetcommon.math.Complex','edu.colorado.phet.common.phetcommon.util.Pair']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DampedMassSpringSystem");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x0 = 0;
this.v0 = 0;
this.omega0 = 0;
this.zeta = 0;
this.characteristicEquationRoots = null;
this.smallRoot = null;
this.largeRoot = null;
this.smallConstant = null;
this.largeConstant = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$D$D$D$D$D', function (mass, k, c, x0, v0) {
C$.$init$.apply(this);
this.x0 = x0;
this.v0 = v0;
this.omega0 = Math.sqrt(k / mass);
this.zeta = c / (2 * Math.sqrt(mass * k));
this.characteristicEquationRoots = C$.solveQuadratic$D$D$D(1, c / mass, k / mass);
this.smallRoot = this.characteristicEquationRoots._1;
this.largeRoot = this.characteristicEquationRoots._2;
var initialPosition = Clazz.new_((I$[1]||$incl$(1)).c$$D$D,[x0, 0]);
var initialVelocity = Clazz.new_((I$[1]||$incl$(1)).c$$D$D,[v0, 0]);
var frac = (this.largeRoot.getMultiply$edu_colorado_phet_common_phetcommon_math_Complex(initialPosition).getSubtract$edu_colorado_phet_common_phetcommon_math_Complex(initialVelocity)).getDivide$edu_colorado_phet_common_phetcommon_math_Complex(this.smallRoot.getSubtract$edu_colorado_phet_common_phetcommon_math_Complex(this.largeRoot));
if (this.isCriticallyDamped()) {
this.largeConstant = initialPosition;
this.smallConstant = initialVelocity.getAdd$edu_colorado_phet_common_phetcommon_math_Complex(initialPosition.getMultiply$D(this.omega0));
} else {
this.largeConstant = initialPosition.getAdd$edu_colorado_phet_common_phetcommon_math_Complex(frac);
this.smallConstant = frac.getOpposite();
}}, 1);

Clazz.newMeth(C$, 'getSystemFromDifferentialEquation$D$D$D$D$D', function (a, b, c, x0, v0) {
return Clazz.new_(C$.c$$D$D$D$D$D,[a, c, b, x0, v0]);
}, 1);

Clazz.newMeth(C$, 'evaluatePosition$D', function (t) {
var result;
if (this.isCriticallyDamped()) {
var root = -this.omega0;
var a = this.x0;
var b = this.v0 + this.omega0 * this.x0;
result = Clazz.new_((I$[1]||$incl$(1)).c$$D$D,[(a + b * t) * Math.exp(root * t), 0]);
} else {
var left = this.largeConstant.getMultiply$edu_colorado_phet_common_phetcommon_math_Complex((I$[1]||$incl$(1)).getExp$edu_colorado_phet_common_phetcommon_math_Complex(this.largeRoot.getMultiply$D(t)));
var right = this.smallConstant.getMultiply$edu_colorado_phet_common_phetcommon_math_Complex((I$[1]||$incl$(1)).getExp$edu_colorado_phet_common_phetcommon_math_Complex(this.smallRoot.getMultiply$D(t)));
result = left.getAdd$edu_colorado_phet_common_phetcommon_math_Complex(right);
}return result._real;
});

Clazz.newMeth(C$, 'evaluateVelocity$D', function (t) {
var result;
if (this.isCriticallyDamped()) {
var root = -this.omega0;
var a = this.x0;
var b = this.v0 + this.omega0 * this.x0;
result = Clazz.new_((I$[1]||$incl$(1)).c$$D$D,[Math.exp(root * t) * (a * root + b * root * t  + b), 0]);
} else {
var left = this.largeConstant.getMultiply$edu_colorado_phet_common_phetcommon_math_Complex((I$[1]||$incl$(1)).getExp$edu_colorado_phet_common_phetcommon_math_Complex(this.largeRoot.getMultiply$D(t))).getMultiply$edu_colorado_phet_common_phetcommon_math_Complex(this.largeRoot);
var right = this.smallConstant.getMultiply$edu_colorado_phet_common_phetcommon_math_Complex((I$[1]||$incl$(1)).getExp$edu_colorado_phet_common_phetcommon_math_Complex(this.smallRoot.getMultiply$D(t))).getMultiply$edu_colorado_phet_common_phetcommon_math_Complex(this.smallRoot);
result = left.getAdd$edu_colorado_phet_common_phetcommon_math_Complex(right);
}return result._real;
});

Clazz.newMeth(C$, 'isCriticallyDamped', function () {
return this.zeta == 1 ;
});

Clazz.newMeth(C$, 'isOverDamped', function () {
return this.zeta > 1 ;
});

Clazz.newMeth(C$, 'isUnderDamped', function () {
return this.zeta < 1 ;
});

Clazz.newMeth(C$, 'getCriticallyDampedDamping$D$D', function (mass, k) {
return 2 * Math.sqrt(mass * k);
}, 1);

Clazz.newMeth(C$, 'solveQuadratic$D$D$D', function (a, b, c) {
return C$.solveQuadratic$edu_colorado_phet_common_phetcommon_math_Complex$edu_colorado_phet_common_phetcommon_math_Complex$edu_colorado_phet_common_phetcommon_math_Complex(Clazz.new_((I$[1]||$incl$(1)).c$$D$D,[a, 0]), Clazz.new_((I$[1]||$incl$(1)).c$$D$D,[b, 0]), Clazz.new_((I$[1]||$incl$(1)).c$$D$D,[c, 0]));
}, 1);

Clazz.newMeth(C$, 'solveQuadratic$edu_colorado_phet_common_phetcommon_math_Complex$edu_colorado_phet_common_phetcommon_math_Complex$edu_colorado_phet_common_phetcommon_math_Complex', function (a, b, c) {
var discriminant = b.getMultiply$edu_colorado_phet_common_phetcommon_math_Complex(b).getSubtract$edu_colorado_phet_common_phetcommon_math_Complex(a.getMultiply$edu_colorado_phet_common_phetcommon_math_Complex(c).getMultiply$D(4));
var sqrted = discriminant.getCanonicalSquareRoot();
return Clazz.new_((I$[2]||$incl$(2)).c$$TT$TU,[Clazz.new_((I$[1]||$incl$(1)).c$$edu_colorado_phet_common_phetcommon_math_Complex,[b.getOpposite().getSubtract$edu_colorado_phet_common_phetcommon_math_Complex(sqrted).getDivide$edu_colorado_phet_common_phetcommon_math_Complex(a.getMultiply$D(2))]), Clazz.new_((I$[1]||$incl$(1)).c$$edu_colorado_phet_common_phetcommon_math_Complex,[b.getOpposite().getAdd$edu_colorado_phet_common_phetcommon_math_Complex(sqrted).getDivide$edu_colorado_phet_common_phetcommon_math_Complex(a.getMultiply$D(2))])]);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:45
