(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.patterns"),I$=[];
var C$=Clazz.newInterface(P$, "Updatable");
})();
//Created 2018-01-31 11:02:49
