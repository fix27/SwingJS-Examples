(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model"),I$=[];
var C$=Clazz.newInterface(P$, "IBucketSphere", function(){
});
;
(function(){var C$=Clazz.newInterface(P$.IBucketSphere, "Listener", function(){
}, null, 'java.util.EventListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})()
;
(function(){var C$=Clazz.newClass(P$.IBucketSphere, "Adapter", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, [['edu.colorado.phet.common.phetcommon.model.IBucketSphere','edu.colorado.phet.common.phetcommon.model.IBucketSphere.Listener']]);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['grabbedByUser$TT'], function (particle) {
});

Clazz.newMeth(C$, ['droppedByUser$TT'], function (particle) {
});

Clazz.newMeth(C$, ['removedFromModel$TT'], function (particle) {
});

Clazz.newMeth(C$);
})()
})();
//Created 2018-01-31 11:02:47
