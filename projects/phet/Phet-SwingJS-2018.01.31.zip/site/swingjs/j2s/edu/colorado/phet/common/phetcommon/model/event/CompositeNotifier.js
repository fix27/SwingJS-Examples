(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.event"),I$=[['edu.colorado.phet.common.phetcommon.model.event.Notifier','edu.colorado.phet.common.phetcommon.model.event.CompositeNotifier$1','edu.colorado.phet.common.phetcommon.model.event.CompositeNotifier$2$1','edu.colorado.phet.common.phetcommon.model.event.CompositeNotifier$3$1','edu.colorado.phet.common.phetcommon.model.event.CompositeNotifier$4$1','edu.colorado.phet.common.phetcommon.model.event.CompositeNotifier$5',['edu.colorado.phet.common.phetcommon.model.event.CompositeNotifier','.A'],['edu.colorado.phet.common.phetcommon.model.event.CompositeNotifier','.B']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "CompositeNotifier", function(){
Clazz.newInstance(this, arguments,0,C$);
}, null, 'edu.colorado.phet.common.phetcommon.model.event.INotifier');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.compositeNotifier = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.compositeNotifier = Clazz.new_((I$[1]||$incl$(1)));
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_model_event_INotifierA', function (children) {
C$.$init$.apply(this);
for (var child, $child = 0, $$child = children; $child<$$child.length&&((child=$$child[$child]),1);$child++) {
child.addListener$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1(((
(function(){var C$=Clazz.newClass(P$, "CompositeNotifier$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.VoidFunction1', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['$apply$TT'], function (value) {
this.b$['edu.colorado.phet.common.phetcommon.model.event.CompositeNotifier'].compositeNotifier.updateListeners$TT(value);
});
})()
), Clazz.new_((I$[2]||$incl$(2)).$init$, [this, null])));
}
}, 1);

Clazz.newMeth(C$, 'addListener$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1', function (listener) {
this.compositeNotifier.addListener$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1(listener);
});

Clazz.newMeth(C$, 'addUpdateListener$edu_colorado_phet_common_phetcommon_model_event_UpdateListener$Z', function (listener, fireOnAdd) {
this.compositeNotifier.addUpdateListener$edu_colorado_phet_common_phetcommon_model_event_UpdateListener$Z(listener, fireOnAdd);
});

Clazz.newMeth(C$, 'removeListener$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1', function (listener) {
this.compositeNotifier.removeListener$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1(listener);
});

Clazz.newMeth(C$, 'main', function (args) {
var aNotifier = ((
(function(){var C$=Clazz.newClass(P$, "CompositeNotifier$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('edu.colorado.phet.common.phetcommon.model.event.Notifier'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
{
this.addListener$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1(((
(function(){var C$=Clazz.newClass(P$, "CompositeNotifier$2$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.VoidFunction1', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['$apply$edu_colorado_phet_common_phetcommon_model_event_CompositeNotifier_A','$apply$TT'], function (a) {
System.out.println$S("aListener: " + a.aString);
});
})()
), Clazz.new_((I$[3]||$incl$(3)).$init$, [this, null])));
}
}, 1);
})()
), Clazz.new_((I$[1]||$incl$(1)), [this, null],P$.CompositeNotifier$2));
var bNotifier = ((
(function(){var C$=Clazz.newClass(P$, "CompositeNotifier$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('edu.colorado.phet.common.phetcommon.model.event.Notifier'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
{
this.addListener$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1(((
(function(){var C$=Clazz.newClass(P$, "CompositeNotifier$3$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.VoidFunction1', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['$apply$edu_colorado_phet_common_phetcommon_model_event_CompositeNotifier_B','$apply$TT'], function (b) {
System.out.println$S("bListener: " + b.aString + ", " + b.bString );
});
})()
), Clazz.new_((I$[4]||$incl$(4)).$init$, [this, null])));
}
}, 1);
})()
), Clazz.new_((I$[1]||$incl$(1)), [this, null],P$.CompositeNotifier$3));
var aAndBNotifier = ((
(function(){var C$=Clazz.newClass(P$, "CompositeNotifier$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('edu.colorado.phet.common.phetcommon.model.event.CompositeNotifier'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
{
this.addListener$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1(((
(function(){var C$=Clazz.newClass(P$, "CompositeNotifier$4$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.VoidFunction1', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['$apply$edu_colorado_phet_common_phetcommon_model_event_CompositeNotifier_A','$apply$TT'], function (a) {
System.out.println$S("aOrBListener: " + a.aString);
});
})()
), Clazz.new_((I$[5]||$incl$(5)).$init$, [this, null])));
}
}, 1);
})()
), Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_model_event_INotifierA, [this, null, [aNotifier, bNotifier]],P$.CompositeNotifier$4));
aAndBNotifier.addListener$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1(((
(function(){var C$=Clazz.newClass(P$, "CompositeNotifier$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.VoidFunction1', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['$apply$O','$apply$TT'], function (object) {
System.out.println$S("objectListener: " + object);
});
})()
), Clazz.new_((I$[6]||$incl$(6)).$init$, [this, null])));
System.out.println$S("\u000afiring A:penguin");
aNotifier.updateListeners$TT(Clazz.new_((I$[7]||$incl$(7)).c$$S,["penguin"]));
System.out.println$S("\u000afiring B:spaghetti,supper");
bNotifier.updateListeners$TT(Clazz.new_((I$[8]||$incl$(8)).c$$S$S,["spaghetti", "supper"]));
}, 1);
;
(function(){var C$=Clazz.newClass(P$.CompositeNotifier, "A", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.aString = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (aString) {
C$.$init$.apply(this);
this.aString = aString;
}, 1);

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.CompositeNotifier, "B", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, ['edu.colorado.phet.common.phetcommon.model.event.CompositeNotifier','edu.colorado.phet.common.phetcommon.model.event.CompositeNotifier.A']);
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.bString = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S$S', function (aString, bString) {
C$.superclazz.c$$S.apply(this, [aString]);
C$.$init$.apply(this);
this.bString = bString;
}, 1);

Clazz.newMeth(C$);
})()
})();
//Created 2018-01-31 11:02:48
