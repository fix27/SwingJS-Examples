(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.resources"),I$=[['java.util.Locale']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DummyConstantStringTester");
C$.dummyString = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.dummyString = null;
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getString$S', function (string) {
if (false) {
return "T[" + string + "]" ;
}if (C$.dummyString != null ) {
return C$.dummyString;
} else {
return string;
}}, 1);

Clazz.newMeth(C$, 'setConstantTestString$S', function (dummyStringValue) {
C$.dummyString = dummyStringValue;
}, 1);

Clazz.newMeth(C$, 'setTestScenario$java_util_Locale$S', function (locale, dummyStringValue) {
(I$[1]||$incl$(1)).setDefault$java_util_Locale(locale);
C$.setConstantTestString$S(dummyStringValue);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:49
