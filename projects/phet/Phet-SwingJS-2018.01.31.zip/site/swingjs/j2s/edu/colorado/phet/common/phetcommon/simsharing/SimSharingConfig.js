(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing"),I$=[['edu.colorado.phet.common.phetcommon.simsharing.SimSharingConfig$1','edu.colorado.phet.common.phetcommon.simsharing.SimSharingConfig$2','edu.colorado.phet.common.phetcommon.simsharing.SimSharingConfig$3','java.util.HashMap']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SimSharingConfig");
C$.DIGITS = null;
C$.WORDS = null;
C$.NO_WHITESPACE = null;
C$.INTERVIEWS = null;
C$.USB_DRIVE = null;
C$.USB_DRIVE_AND_GROUP_NUMBER = null;
C$.COLORADO_CONFIG = null;
C$.UTAH_CONFIG = null;
C$.DALLAS_JAN_2012 = null;
C$.DALLAS_JAN_2012_ID = null;
C$.ABS_SPRING_2012 = null;
C$.FARADAY_SPRING_2012 = null;
C$.BALANCING_ACT_SPRING_2012 = null;
C$.MOLECULE_SHAPED_FEB_2012 = null;
C$.LOAD_TESTING = null;
C$.DEFAULT = null;
C$.RPAL_APRIL_2012 = null;
C$.CCK_UBC_SPRING_2013 = null;
C$.CONFIG_MAP = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.DIGITS = ((
(function(){var C$=Clazz.newClass(P$, "SimSharingConfig$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.Function1', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['$apply$Character','$apply$TU'], function (character) {
return new Boolean(Character.isDigit(character.charValue()));
});
})()
), Clazz.new_((I$[1]||$incl$(1)).$init$, [this, null]));
C$.WORDS = ((
(function(){var C$=Clazz.newClass(P$, "SimSharingConfig$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.Function1', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['$apply$Character','$apply$TU'], function (character) {
return new Boolean(Character.isLetterOrDigit(character.charValue()) || Character.isWhitespace(character.charValue()) || character.charValue() == "."  );
});
})()
), Clazz.new_((I$[2]||$incl$(2)).$init$, [this, null]));
C$.NO_WHITESPACE = ((
(function(){var C$=Clazz.newClass(P$, "SimSharingConfig$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.Function1', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['$apply$Character','$apply$TU'], function (character) {
return new Boolean(!character.toString().equals$O(" "));
});
})()
), Clazz.new_((I$[3]||$incl$(3)).$init$, [this, null]));
C$.INTERVIEWS = Clazz.new_(C$.c$$S$Z$Z$Z$Z,["interviews", true, false, false, false]);
C$.USB_DRIVE = Clazz.new_(C$.c$$S$Z$Z$Z$Z$Z$edu_colorado_phet_common_phetcommon_util_function_Function1,["usb-drive", false, true, false, false, false, C$.NO_WHITESPACE]);
C$.USB_DRIVE_AND_GROUP_NUMBER = Clazz.new_(C$.c$$S$Z$Z$Z$Z$Z$S$edu_colorado_phet_common_phetcommon_util_function_Function1,["usb-drive-and-group-number", false, true, false, true, true, "Enter your group number:", C$.NO_WHITESPACE]);
C$.COLORADO_CONFIG = Clazz.new_(C$.c$$S$Z$Z$Z$Z$Z$S,["colorado", false, false, true, true, true, "Enter your computer number:"]);
C$.UTAH_CONFIG = Clazz.new_(C$.c$$S$Z$Z$Z$Z$Z$S,["utah", false, false, true, true, false, "Enter your audio recorder number:"]);
C$.DALLAS_JAN_2012 = Clazz.new_(C$.c$$S$Z$Z$Z$Z,["dallas-jan-2012", true, true, false, false]);
C$.DALLAS_JAN_2012_ID = Clazz.new_(C$.c$$S$Z$Z$Z$Z,["dallas-jan-2012-id", true, true, false, false]);
C$.ABS_SPRING_2012 = Clazz.new_(C$.c$$S$Z$Z$Z$Z,["acid-base-solutions-spring-2012", true, true, false, false]);
C$.FARADAY_SPRING_2012 = Clazz.new_(C$.c$$S$Z$Z$Z$Z,["faraday-spring-2012", false, true, false, false]);
C$.BALANCING_ACT_SPRING_2012 = Clazz.new_(C$.c$$S$Z$Z$Z$Z$Z$S$edu_colorado_phet_common_phetcommon_util_function_Function1,["balancing-act-spring-2012", true, false, true, true, true, "Please enter your user ID:", C$.WORDS]);
C$.MOLECULE_SHAPED_FEB_2012 = Clazz.new_(C$.c$$S$Z$Z$Z$Z,["molecule-shapes-feb-2012", true, true, false, false]);
C$.LOAD_TESTING = Clazz.new_(C$.c$$S$Z$Z$Z$Z,["load-testing", false, true, false, false]);
C$.DEFAULT = Clazz.new_(C$.c$$S$Z$Z$Z$Z$Z$S,["default", false, false, false, false, false, ""]);
C$.RPAL_APRIL_2012 = Clazz.new_(C$.c$$S$Z$Z$Z$Z,["rpal-april-2012", true, false, false, false]);
C$.CCK_UBC_SPRING_2013 = Clazz.new_(C$.c$$S$Z$Z$Z$Z$Z$S,["cck-ubc-spring-2013", true, false, false, true, true, "Please enter your assigned ID:"]);
C$.CONFIG_MAP = Clazz.new_((I$[4]||$incl$(4)));
{
C$.addConfig$edu_colorado_phet_common_phetcommon_simsharing_SimSharingConfig(C$.INTERVIEWS);
C$.addConfig$edu_colorado_phet_common_phetcommon_simsharing_SimSharingConfig(C$.USB_DRIVE);
C$.addConfig$edu_colorado_phet_common_phetcommon_simsharing_SimSharingConfig(C$.USB_DRIVE_AND_GROUP_NUMBER);
C$.addConfig$edu_colorado_phet_common_phetcommon_simsharing_SimSharingConfig(C$.COLORADO_CONFIG);
C$.addConfig$edu_colorado_phet_common_phetcommon_simsharing_SimSharingConfig(C$.UTAH_CONFIG);
C$.addConfig$edu_colorado_phet_common_phetcommon_simsharing_SimSharingConfig(C$.DALLAS_JAN_2012);
C$.addConfig$edu_colorado_phet_common_phetcommon_simsharing_SimSharingConfig(C$.DALLAS_JAN_2012_ID);
C$.addConfig$edu_colorado_phet_common_phetcommon_simsharing_SimSharingConfig(C$.ABS_SPRING_2012);
C$.addConfig$edu_colorado_phet_common_phetcommon_simsharing_SimSharingConfig(C$.FARADAY_SPRING_2012);
C$.addConfig$edu_colorado_phet_common_phetcommon_simsharing_SimSharingConfig(C$.BALANCING_ACT_SPRING_2012);
C$.addConfig$edu_colorado_phet_common_phetcommon_simsharing_SimSharingConfig(C$.MOLECULE_SHAPED_FEB_2012);
C$.addConfig$edu_colorado_phet_common_phetcommon_simsharing_SimSharingConfig(C$.LOAD_TESTING);
C$.addConfig$edu_colorado_phet_common_phetcommon_simsharing_SimSharingConfig(C$.RPAL_APRIL_2012);
C$.addConfig$edu_colorado_phet_common_phetcommon_simsharing_SimSharingConfig(C$.CCK_UBC_SPRING_2013);
}
;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.studyName = null;
this.requestId = false;
this.idRequired = false;
this.idPrompt = null;
this.sendToLogFile = false;
this.sendToLogFileNearJAR = false;
this.sendToServer = false;
this.collectIPAddress = false;
this.characterValidation = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.collectIPAddress = false;
}, 1);

Clazz.newMeth(C$, 'addConfig$edu_colorado_phet_common_phetcommon_simsharing_SimSharingConfig', function (config) {
Clazz.assert(C$, this, function(){return (C$.CONFIG_MAP.get$O(config.studyName) == null )});
C$.CONFIG_MAP.put$TK$TV(config.studyName, config);
}, 1);

Clazz.newMeth(C$, 'getConfig$S', function (studyName) {
var config = C$.CONFIG_MAP.get$O(studyName);
if (config == null ) {
config = C$.DEFAULT;
}return config;
}, 1);

Clazz.newMeth(C$, 'c$$S$Z$Z$Z$Z', function (studyName, sendToLogFile, sendToServer, requestId, idRequired) {
C$.c$$S$Z$Z$Z$Z$Z$edu_colorado_phet_common_phetcommon_util_function_Function1.apply(this, [studyName, sendToLogFile, false, sendToServer, requestId, idRequired, C$.DIGITS]);
}, 1);

Clazz.newMeth(C$, 'c$$S$Z$Z$Z$Z$Z$edu_colorado_phet_common_phetcommon_util_function_Function1', function (studyName, sendToLogFile, sendToLogFileNearJAR, sendToServer, requestId, idRequired, characterValidation) {
C$.c$$S$Z$Z$Z$Z$Z$S$edu_colorado_phet_common_phetcommon_util_function_Function1.apply(this, [studyName, sendToLogFile, sendToLogFileNearJAR, sendToServer, requestId, idRequired, null, characterValidation]);
}, 1);

Clazz.newMeth(C$, 'c$$S$Z$Z$Z$Z$Z$S', function (studyName, sendToLogFile, sendToLogFileNearJAR, sendToServer, requestId, idRequired, idPrompt) {
C$.c$$S$Z$Z$Z$Z$Z$S$edu_colorado_phet_common_phetcommon_util_function_Function1.apply(this, [studyName, sendToLogFile, sendToLogFileNearJAR, sendToServer, requestId, idRequired, idPrompt, C$.DIGITS]);
}, 1);

Clazz.newMeth(C$, 'c$$S$Z$Z$Z$Z$Z$S$edu_colorado_phet_common_phetcommon_util_function_Function1', function (studyName, sendToLogFile, sendToLogFileNearJAR, sendToServer, requestId, idRequired, idPrompt, characterValidation) {
C$.$init$.apply(this);
this.studyName = studyName;
this.sendToLogFile = sendToLogFile;
this.sendToLogFileNearJAR = sendToLogFileNearJAR;
this.sendToServer = sendToServer;
this.requestId = requestId;
this.idPrompt = idPrompt;
this.idRequired = idRequired;
this.characterValidation = characterValidation;
}, 1);
C$.$_ASSERT_ENABLED_ = ClassLoader.$getClassAssertionStatus(C$);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:49
