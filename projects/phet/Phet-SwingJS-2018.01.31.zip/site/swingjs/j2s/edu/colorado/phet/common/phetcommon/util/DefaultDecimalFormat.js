(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.util"),I$=[['java.text.NumberFormat','edu.colorado.phet.common.phetcommon.resources.PhetResources','java.math.BigDecimal','java.math.MathContext','java.math.RoundingMode','java.lang.StringBuffer','java.text.DecimalFormat']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DefaultDecimalFormat", null, 'java.text.DecimalFormat');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.decimalFormat = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (pattern) {
C$.c$$java_text_NumberFormat.apply(this, [(I$[1]||$incl$(1)).getNumberInstance$java_util_Locale((I$[2]||$incl$(2)).readLocale())]);
if (pattern.contains$CharSequence("E")) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["scientific notation is not supported, see Unfuddle #3664: " + pattern]);
}if (Clazz.instanceOf(this.decimalFormat, "java.text.DecimalFormat")) {
(this.decimalFormat).applyPattern$S(pattern);
}}, 1);

Clazz.newMeth(C$, 'c$$java_text_NumberFormat', function (decimalFormat) {
Clazz.super_(C$, this,1);
this.decimalFormat = decimalFormat;
}, 1);

Clazz.newMeth(C$, 'roundNearestNeighbor$D', function (number) {
var prefix = (Math.floor(Math.abs(number))|0);
var numberOfDigitsBeforeTheDecimal = prefix == 0 ? 0 : Integer.toString(prefix).length$();
var numDigitsToShow = this.decimalFormat.getMaximumFractionDigits() + numberOfDigitsBeforeTheDecimal;
var bigDecimal = Clazz.new_((I$[3]||$incl$(3)).c$$D$java_math_MathContext,[number, Clazz.new_((I$[4]||$incl$(4)).c$$I$java_math_RoundingMode,[numDigitsToShow, (I$[5]||$incl$(5)).HALF_UP])]);
var roundedBigDecimal = bigDecimal.setScale$I$java_math_RoundingMode(numDigitsToShow, (I$[5]||$incl$(5)).HALF_UP);
return roundedBigDecimal.doubleValue();
});

Clazz.newMeth(C$, 'format$J$StringBuffer$java_text_FieldPosition', function (number, result, fieldPosition) {
return this.format$D$StringBuffer$java_text_FieldPosition(number, result, fieldPosition);
});

Clazz.newMeth(C$, 'format$D$StringBuffer$java_text_FieldPosition', function (number, result, fieldPosition) {
var rounded = p$.roundNearestNeighbor$D.apply(this, [number]);
var formattedText = this.decimalFormat.format$D$StringBuffer$java_text_FieldPosition(rounded, Clazz.new_((I$[6]||$incl$(6))), fieldPosition);
var parsed = 0;
try {
parsed = this.decimalFormat.parse$S(formattedText.toString()).doubleValue();
} catch (e$$) {
if (Clazz.exceptionOf(e$$, "java.lang.NumberFormatException")){
var numberFormatException = e$$;
{
return this.decimalFormat.format$D$StringBuffer$java_text_FieldPosition(number, result, fieldPosition);
}
} else if (Clazz.exceptionOf(e$$, "java.text.ParseException")){
var e = e$$;
{
e.printStackTrace();
}
} else {
throw e$$;
}
}
if (parsed == 0  && formattedText.indexOf$S("-") == 0 ) {
result.append$S(formattedText.substring$I(1));
} else {
result.append$StringBuffer(formattedText);
}return result;
});

Clazz.newMeth(C$, 'createFormat$I', function (numberOfDecimalPlaces) {
var pattern = "0.";
for (var i = 0; i < numberOfDecimalPlaces; i++) {
pattern += "0";
}
return Clazz.new_(C$.c$$S,[pattern]);
}, 1);

Clazz.newMeth(C$, 'main', function (args) {
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.0E0"]).format$D(1200.0).equals$O("1200.0"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.0"]).format$J(999).equals$O("999.0"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.0"]).format$J(1001).equals$O("1001.0"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.0"]).format$D(999.9).equals$O("999.9"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.0"]).format$D(1000.06).equals$O("1000.1"))});
Clazz.assert(C$, this, function(){return (Clazz.new_((I$[7]||$incl$(7)).c$$S,["0.00"]).format$D(-1.0E-5).equals$O("-0.00"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.00"]).format$D(-1.0E-5).equals$O("0.00"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.00"]).format$D(0.014).equals$O("0.01"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.00"]).format$D(0.015).equals$O("0.02"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.00"]).format$D(0.016).equals$O("0.02"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.00"]).format$D(0.024).equals$O("0.02"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.00"]).format$D(0.014).equals$O("0.01"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.00"]).format$D(0.015).equals$O("0.02"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.00"]).format$D(0.016).equals$O("0.02"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.00"]).format$D(0.024).equals$O("0.02"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.00"]).format$D(0.025).equals$O("0.03"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.00"]).format$D(0.026).equals$O("0.03"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.00"]).format$D(-0.014).equals$O("-0.01"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.00"]).format$D(-0.015).equals$O("-0.02"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.00"]).format$D(-0.016).equals$O("-0.02"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.00"]).format$D(-0.024).equals$O("-0.02"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.00"]).format$D(-0.025).equals$O("-0.03"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.00"]).format$D(-0.026).equals$O("-0.03"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.000"]).format$D(0.0015).equals$O("0.002"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.000"]).format$D(0.0025).equals$O("0.003"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.0000"]).format$D(1.5E-4).equals$O("0.0002"))});
Clazz.assert(C$, this, function(){return (Clazz.new_(C$.c$$S,["0.0000"]).format$D(2.5E-4).equals$O("0.0003"))});
}, 1);
C$.$_ASSERT_ENABLED_ = ClassLoader.$getClassAssertionStatus(C$);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:51
