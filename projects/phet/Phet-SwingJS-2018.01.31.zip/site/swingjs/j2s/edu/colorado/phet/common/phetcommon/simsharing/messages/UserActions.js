(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.messages"),I$=[];
var C$=Clazz.newClass(P$, "UserActions", null, 'Enum', 'edu.colorado.phet.common.phetcommon.simsharing.messages.IUserAction');

C$.$clinit$ = function() {Clazz.load(C$, 1);
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "activated", 0, []);
Clazz.newEnumConst($vals, C$.c$, "changed", 1, []);
Clazz.newEnumConst($vals, C$.c$, "closed", 2, []);
Clazz.newEnumConst($vals, C$.c$, "deactivated", 3, []);
Clazz.newEnumConst($vals, C$.c$, "deiconified", 4, []);
Clazz.newEnumConst($vals, C$.c$, "drag", 5, []);
Clazz.newEnumConst($vals, C$.c$, "endDrag", 6, []);
Clazz.newEnumConst($vals, C$.c$, "iconified", 7, []);
Clazz.newEnumConst($vals, C$.c$, "moved", 8, []);
Clazz.newEnumConst($vals, C$.c$, "pressed", 9, []);
Clazz.newEnumConst($vals, C$.c$, "released", 10, []);
Clazz.newEnumConst($vals, C$.c$, "resized", 11, []);
Clazz.newEnumConst($vals, C$.c$, "startDrag", 12, []);
Clazz.newEnumConst($vals, C$.c$, "windowOpened", 13, []);
Clazz.newEnumConst($vals, C$.c$, "windowClosed", 14, []);
Clazz.newEnumConst($vals, C$.c$, "windowClosing", 15, []);
Clazz.newEnumConst($vals, C$.c$, "popupTriggered", 16, []);
Clazz.newEnumConst($vals, C$.c$, "focusLost", 17, []);
Clazz.newEnumConst($vals, C$.c$, "focusGained", 18, []);
Clazz.newEnumConst($vals, C$.c$, "selected", 19, []);
Clazz.newEnumConst($vals, C$.c$, "textFieldCommitted", 20, []);
Clazz.newEnumConst($vals, C$.c$, "textFieldCorrected", 21, []);
Clazz.newEnumConst($vals, C$.c$, "enterPressed", 22, []);
Clazz.newEnumConst($vals, C$.c$, "keyPressed", 23, []);
Clazz.newEnumConst($vals, C$.c$, "buttonPressed", 24, []);
Clazz.newEnumConst($vals, C$.c$, "mousePressed", 25, []);
Clazz.newEnumConst($vals, C$.c$, "trackClicked", 26, []);
Clazz.newEnumConst($vals, C$.c$, "upArrowPressed", 27, []);
Clazz.newEnumConst($vals, C$.c$, "downArrowPressed", 28, []);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values', function() { return $vals }, 1);
})();
//Created 2018-01-31 11:02:51
