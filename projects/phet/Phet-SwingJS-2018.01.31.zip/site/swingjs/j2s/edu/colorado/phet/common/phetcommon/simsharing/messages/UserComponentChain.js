(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.simsharing.messages"),I$=[['edu.colorado.phet.common.phetcommon.util.ObservableList','edu.colorado.phet.common.phetcommon.simsharing.messages.UserComponent']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "UserComponentChain", null, null, 'edu.colorado.phet.common.phetcommon.simsharing.messages.IUserComponent');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.components = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponentA', function (components) {
C$.$init$.apply(this);
this.components = components;
}, 1);

Clazz.newMeth(C$, 'toString', function () {
return Clazz.new_((I$[1]||$incl$(1)).c$$TTA,[this.components]).mkString$S(".");
});

Clazz.newMeth(C$, 'chain$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$I', function (component, index) {
return C$.chain$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponentA([component, Clazz.new_((I$[2]||$incl$(2)).c$$I,[index])]);
}, 1);

Clazz.newMeth(C$, 'chain$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponentA', function (components) {
return Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponentA,[components]);
}, 1);

Clazz.newMeth(C$, 'chain$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponent$S', function (userComponent, name) {
return Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_simsharing_messages_IUserComponentA,[[userComponent, Clazz.new_((I$[2]||$incl$(2)).c$$S,[name])]]);
}, 1);
})();
//Created 2018-01-31 11:02:51
