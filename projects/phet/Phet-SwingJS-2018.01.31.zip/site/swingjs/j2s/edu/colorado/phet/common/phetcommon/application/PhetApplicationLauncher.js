(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.application"),I$=[[['edu.colorado.phet.common.phetcommon.application.PhetApplicationLauncher','.ReflectionApplicationConstructor'],'edu.colorado.phet.common.phetcommon.application.PhetApplicationConfig','javax.swing.SwingUtilities','edu.colorado.phet.common.phetcommon.application.PhetApplicationLauncher$1']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "PhetApplicationLauncher", function(){
Clazz.newInstance(this, arguments,0,C$);
});

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'launchSim$SA$S$Class', function (commandLineArgs, project, phetApplicationClass) {
this.launchSim$SA$S$edu_colorado_phet_common_phetcommon_application_ApplicationConstructor(commandLineArgs, project, Clazz.new_((I$[1]||$incl$(1)).c$$Class,[phetApplicationClass]));
});

Clazz.newMeth(C$, 'launchSim$SA$S$S$Class', function (commandLineArgs, project, flavor, phetApplicationClass) {
this.launchSim$SA$S$S$edu_colorado_phet_common_phetcommon_application_ApplicationConstructor(commandLineArgs, project, flavor, Clazz.new_((I$[1]||$incl$(1)).c$$Class,[phetApplicationClass]));
});

Clazz.newMeth(C$, 'launchSim$SA$S$edu_colorado_phet_common_phetcommon_application_ApplicationConstructor', function (commandLineArgs, project, applicationConstructor) {
this.launchSim$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig$edu_colorado_phet_common_phetcommon_application_ApplicationConstructor(Clazz.new_((I$[2]||$incl$(2)).c$$SA$S,[commandLineArgs, project]), applicationConstructor);
});

Clazz.newMeth(C$, 'launchSim$SA$S$S$edu_colorado_phet_common_phetcommon_application_ApplicationConstructor', function (commandLineArgs, project, flavor, applicationConstructor) {
this.launchSim$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig$edu_colorado_phet_common_phetcommon_application_ApplicationConstructor(Clazz.new_((I$[2]||$incl$(2)).c$$SA$S$S,[commandLineArgs, project, flavor]), applicationConstructor);
});

Clazz.newMeth(C$, 'launchSim$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig$Class', function (config, phetApplicationClass) {
this.launchSim$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig$edu_colorado_phet_common_phetcommon_application_ApplicationConstructor(config, Clazz.new_((I$[1]||$incl$(1)).c$$Class,[phetApplicationClass]));
});

Clazz.newMeth(C$, 'launchSim$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig$edu_colorado_phet_common_phetcommon_application_ApplicationConstructor', function (config, applicationConstructor) {
(I$[3]||$incl$(3)).invokeLater$Runnable(((
(function(){var C$=Clazz.newClass(P$, "PhetApplicationLauncher$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'run', function () {
this.$finals.config.getLookAndFeel().initLookAndFeel();
{

}
if (this.$finals.applicationConstructor != null ) {
var app = this.$finals.applicationConstructor.getApplication$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig(this.$finals.config);
app.startApplication();
} else {
Clazz.new_(Clazz.load('java.lang.RuntimeException').c$$S,["No applicationconstructor specified"]).printStackTrace();
}});
})()
), Clazz.new_((I$[4]||$incl$(4)).$init$, [this, {config: config, applicationConstructor: applicationConstructor}])));
});
;
(function(){var C$=Clazz.newClass(P$.PhetApplicationLauncher, "ReflectionApplicationConstructor", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'edu.colorado.phet.common.phetcommon.application.ApplicationConstructor');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.phetApplicationClass = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$Class', function (phetApplicationClass) {
C$.$init$.apply(this);
this.phetApplicationClass = phetApplicationClass;
}, 1);

Clazz.newMeth(C$, 'getApplication$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig', function (config) {
try {
return this.phetApplicationClass.getConstructor$ClassA(Clazz.array(java.lang.Class, -1, [config.getClass()])).newInstance$OA(Clazz.array(java.lang.Object, -1, [config]));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
throw Clazz.new_(Clazz.load('java.lang.RuntimeException').c$$Throwable,[e]);
} else {
throw e;
}
}
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:02:44
