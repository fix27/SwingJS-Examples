(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math.vector"),I$=[];
var C$=Clazz.newClass(P$, "Vector3D", null, 'edu.colorado.phet.common.phetcommon.math.vector.AbstractVector3D');
C$.ZERO = null;
C$.X_UNIT = null;
C$.Y_UNIT = null;
C$.Z_UNIT = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.ZERO = Clazz.new_(C$);
C$.X_UNIT = Clazz.new_(C$.c$$D$D$D,[1, 0, 0]);
C$.Y_UNIT = Clazz.new_(C$.c$$D$D$D,[0, 1, 0]);
C$.Z_UNIT = Clazz.new_(C$.c$$D$D$D,[0, 0, 1]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x = 0;
this.y = 0;
this.z = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'hashCode', function () {
return Float.floatToIntBits(this.x) ^ Float.floatToIntBits(this.y) ^ Float.floatToIntBits(this.z) ;
});

Clazz.newMeth(C$, 'equals$O', function (o) {
if (!(Clazz.instanceOf(o, "edu.colorado.phet.common.phetcommon.math.vector.Vector3D"))) {
return false;
}var m = o;
return (m.x == this.x  && m.y == this.y   && m.z == this.z  );
});

Clazz.newMeth(C$, 'c$', function () {
C$.c$$D$D$D.apply(this, [0, 0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$D$D$D', function (x, y, z) {
Clazz.super_(C$, this,1);
this.x = x;
this.y = y;
this.z = z;
}, 1);

Clazz.newMeth(C$, 'getX', function () {
return this.x;
});

Clazz.newMeth(C$, 'getY', function () {
return this.y;
});

Clazz.newMeth(C$, 'getZ', function () {
return this.z;
});
})();
//Created 2017-12-22 22:33:02
