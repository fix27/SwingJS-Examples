(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[['java.util.Random',['edu.colorado.phet.common.phetcommon.math.ProbabilisticChooser','.Entry']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ProbabilisticChooser", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.RANDOM = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.RANDOM = Clazz.new_((I$[1]||$incl$(1)));
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._entries = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_ProbabilisticChooser_EntryA', function (entries) {
C$.$init$.apply(this);
this._entries = Clazz.array((I$[2]||$incl$(2)), [entries.length]);
var pTotal = 0;
for (var i = 0; i < entries.length; i++) {
pTotal += entries[i].getWeight();
}
var fNorm = 1 / pTotal;
var p = 0;
for (var i = 0; i < entries.length; i++) {
p += entries[i].getWeight() * fNorm;
this._entries[i] = Clazz.new_((I$[2]||$incl$(2)).c$$O$D,[entries[i].getObject(), p]);
}
}, 1);

Clazz.newMeth(C$, 'get', function () {
return this.get$D(C$.RANDOM.nextDouble());
});

Clazz.newMeth(C$, 'get$D', function (p) {
var result = null;
for (var i = 0; i < this._entries.length && result == null  ; i++) {
var entry = this._entries[i];
if (p <= entry.getWeight() ) {
result = entry.getObject();
}}
return result;
});

Clazz.newMeth(C$, 'getEntries', function () {
return this._entries;
});
;
(function(){var C$=Clazz.newClass(P$.ProbabilisticChooser, "Entry", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.object = null;
this.weight = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$O$D', function (object, weight) {
C$.$init$.apply(this);
this.object = object;
this.weight = weight;
}, 1);

Clazz.newMeth(C$, 'getObject', function () {
return this.object;
});

Clazz.newMeth(C$, 'getWeight', function () {
return this.weight;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:33:00
