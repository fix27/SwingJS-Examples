(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[[['edu.colorado.phet.common.phetcommon.math.SphereF','.SphereIntersectionResult'],'java.util.ArrayList','java.util.Arrays']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SphereF", function(){
Clazz.newInstance(this, arguments,0,C$);
});

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.center = null;
this.radius = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'hashCode', function () {
return Float.floatToIntBits(this.radius) ^ this.center.hashCode();
});

Clazz.newMeth(C$, 'equals$O', function (o) {
if (!(Clazz.instanceOf(o, "edu.colorado.phet.common.phetcommon.math.SphereF"))) {
return false;
}var m = o;
return (m.radius == this.radius  && m.center.x == this.center.x   && m.center.y == this.center.y   && m.center.z == this.center.z  );
});

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$F', function (center, radius) {
C$.$init$.apply(this);
this.center = center;
this.radius = radius;
}, 1);

Clazz.newMeth(C$, 'intersect$edu_colorado_phet_common_phetcommon_math_Ray3F$F', function (ray, epsilon) {
var raydir = ray.dir;
var pos = ray.pos;
var centerToRay = pos.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.center);
var tmp = raydir.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(centerToRay);
var centerToRayDistSq = centerToRay.magnitudeSquared();
var det = 4 * tmp * tmp  - 4 * (centerToRayDistSq - this.radius * this.radius);
if (det < epsilon ) {
return null;
}var base = raydir.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.center) - raydir.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(pos);
var sqt = (Math.sqrt(det) / 2);
var ta = base - sqt;
var tb = base + sqt;
if (tb < epsilon ) {
return null;
}var hitPositionB = ray.pointAtDistance$F(tb);
var normalB = hitPositionB.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.center).normalized();
if (ta < epsilon ) {
return Clazz.new_((I$[1]||$incl$(1)).c$$F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$Z,[tb, hitPositionB, normalB.negated(), false]);
} else {
var hitPositionA = ray.pointAtDistance$F(ta);
var normalA = hitPositionA.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.center).normalized();
return Clazz.new_((I$[1]||$incl$(1)).c$$F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$Z,[ta, hitPositionA, normalA, true]);
}});

Clazz.newMeth(C$, 'intersections$edu_colorado_phet_common_phetcommon_math_Ray3F$F', function (ray, epsilon) {
var result = Clazz.new_((I$[2]||$incl$(2)));
var raydir = ray.dir;
var pos = ray.pos;
var centerToRay = pos.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.center);
var tmp = raydir.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(centerToRay);
var centerToRayDistSq = centerToRay.magnitudeSquared();
var det = 4 * tmp * tmp  - 4 * (centerToRayDistSq - this.radius * this.radius);
if (det < epsilon ) {
return result;
}var base = raydir.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.center) - raydir.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(pos);
var sqt = (Math.sqrt(det) / 2);
var ta = base - sqt;
var tb = base + sqt;
if (tb < epsilon ) {
return result;
}var hitPositionB = ray.pointAtDistance$F(tb);
var normalB = hitPositionB.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.center).normalized();
var hitPositionA = ray.pointAtDistance$F(ta);
var normalA = hitPositionA.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.center).normalized();
var resultB = Clazz.new_((I$[1]||$incl$(1)).c$$F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$Z,[tb, hitPositionB, normalB.negated(), false]);
var resultA = Clazz.new_((I$[1]||$incl$(1)).c$$F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$Z,[ta, hitPositionA, normalA, true]);
if (ta < epsilon ) {
return (I$[3]||$incl$(3)).asList$TTA([resultB, resultA]);
} else {
return (I$[3]||$incl$(3)).asList$TTA([resultA, resultB]);
}});

Clazz.newMeth(C$, 'getCenter', function () {
return this.center;
});

Clazz.newMeth(C$, 'getRadius', function () {
return this.radius;
});
;
(function(){var C$=Clazz.newClass(P$.SphereF, "SphereIntersectionResult", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.distance = 0;
this.hitPoint = null;
this.normal = null;
this.fromOutside = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$Z', function (distance, hitPoint, normal, fromOutside) {
C$.$init$.apply(this);
this.distance = distance;
this.hitPoint = hitPoint;
this.normal = normal;
this.fromOutside = fromOutside;
}, 1);

Clazz.newMeth(C$, 'getDistance', function () {
return this.distance;
});

Clazz.newMeth(C$, 'getHitPoint', function () {
return this.hitPoint;
});

Clazz.newMeth(C$, 'getNormal', function () {
return this.normal;
});

Clazz.newMeth(C$, 'isFromOutside', function () {
return this.fromOutside;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:33:01
