(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.application"),I$=[];
var C$=Clazz.newClass(P$, "PhetPersistenceDir", null, 'java.io.File');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$$S.apply(this, [System.getProperty("user.home") + System.getProperty("file.separator") + ".phet" ]);
C$.$init$.apply(this);
}, 1);
})();
//Created 2017-12-22 22:32:56
