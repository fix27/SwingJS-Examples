(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math.vector"),I$=[];
var C$=Clazz.newClass(P$, "MutableVector4F", null, 'edu.colorado.phet.common.phetcommon.math.vector.AbstractVector4F');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x = 0;
this.y = 0;
this.z = 0;
this.w = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'hashCode', function () {
return Float.floatToIntBits(this.x) ^ Float.floatToIntBits(this.y) ^ Float.floatToIntBits(this.z) ^ Float.floatToIntBits(this.w) ;
});

Clazz.newMeth(C$, 'equals$O', function (o) {
if (!(Clazz.instanceOf(o, "edu.colorado.phet.common.phetcommon.math.vector.MutableVector4F"))) {
return false;
}var m = o;
return (m.x == this.x  && m.y == this.y   && m.z == this.z   && m.w == this.w  );
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector4F', function (v) {
C$.c$$F$F$F$F.apply(this, [v.getX(), v.getY(), v.getZ(), v.getW()]);
}, 1);

Clazz.newMeth(C$, 'c$$F$F$F$F', function (x, y, z, w) {
Clazz.super_(C$, this,1);
this.x = x;
this.y = y;
this.z = z;
this.w = w;
}, 1);

Clazz.newMeth(C$, 'getX', function () {
return this.x;
});

Clazz.newMeth(C$, 'getY', function () {
return this.y;
});

Clazz.newMeth(C$, 'getZ', function () {
return this.z;
});

Clazz.newMeth(C$, 'getW', function () {
return this.w;
});

Clazz.newMeth(C$, 'add$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector4F', function (v) {
this.setX$F(this.getX() + v.getX());
this.setY$F(this.getY() + v.getY());
this.setZ$F(this.getZ() + v.getZ());
this.setW$F(this.getW() + v.getW());
return this;
});

Clazz.newMeth(C$, 'normalize', function () {
var magnitude = this.magnitude();
if (magnitude == 0 ) {
throw Clazz.new_(Clazz.load('java.lang.UnsupportedOperationException').c$$S,["Cannot normalize a zero-magnitude vector."]);
}return this.scale$F(1.0 / magnitude);
});

Clazz.newMeth(C$, 'scale$F', function (scale) {
this.setX$F(this.getX() * scale);
this.setY$F(this.getY() * scale);
this.setZ$F(this.getZ() * scale);
this.setW$F(this.getW() * scale);
return this;
});

Clazz.newMeth(C$, 'negate', function () {
this.setComponents$F$F$F$F(-this.getX(), -this.getY(), -this.getZ(), -this.getW());
return this;
});

Clazz.newMeth(C$, 'setX$F', function (x) {
this.x = x;
});

Clazz.newMeth(C$, 'setY$F', function (y) {
this.y = y;
});

Clazz.newMeth(C$, 'setZ$F', function (z) {
this.z = z;
});

Clazz.newMeth(C$, 'setW$F', function (w) {
this.w = w;
});

Clazz.newMeth(C$, 'setComponents$F$F$F$F', function (x, y, z, w) {
this.setX$F(x);
this.setY$F(y);
this.setY$F(z);
this.setW$F(w);
});

Clazz.newMeth(C$, 'setValue$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector4F', function (value) {
this.setComponents$F$F$F$F(value.getX(), value.getY(), value.getZ(), value.getW());
});

Clazz.newMeth(C$, 'setMagnitude$F', function (magnitude) {
this.normalize();
this.scale$F(magnitude);
});

Clazz.newMeth(C$, 'subtract$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector4F', function (v) {
this.setX$F(this.getX() - v.getX());
this.setY$F(this.getY() - v.getY());
this.setZ$F(this.getZ() - v.getZ());
this.setW$F(this.getW() - v.getW());
return this;
});
})();
//Created 2017-12-22 22:33:01
