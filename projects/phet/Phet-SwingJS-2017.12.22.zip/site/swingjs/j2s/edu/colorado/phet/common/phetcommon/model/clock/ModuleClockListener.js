(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.clock"),I$=[];
var C$=Clazz.newInterface(P$, "ModuleClockListener", null, null, 'edu.colorado.phet.common.phetcommon.model.clock.ClockListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2017-12-22 22:33:03
