(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.event"),I$=[['edu.colorado.phet.common.phetcommon.model.event.AbstractNotifier','edu.colorado.phet.common.phetcommon.model.event.Notifier$1']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Notifier", null, null, 'edu.colorado.phet.common.phetcommon.model.event.INotifier');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.notifier = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.notifier = Clazz.new_((I$[1]||$incl$(1)));
}, 1);

Clazz.newMeth(C$, ['updateListeners$TT'], function (value) {
this.notifier.updateListeners$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1(((
(function(){var C$=Clazz.newClass(P$, "Notifier$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.VoidFunction1', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['$apply$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1','$apply$TT'], function (listener) {
listener.$apply$TT(this.$finals.value);
});
})()
), Clazz.new_((I$[2]||$incl$(2)).$init$, [this, {value: value}])));
});

Clazz.newMeth(C$, 'addListener$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1', function (listener) {
this.notifier.addListener$TT(listener);
});

Clazz.newMeth(C$, 'addUpdateListener$edu_colorado_phet_common_phetcommon_model_event_UpdateListener$Z', function (listener, fireOnAdd) {
this.notifier.addListener$TT(listener);
if (fireOnAdd) {
listener.update();
}});

Clazz.newMeth(C$, 'removeListener$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1', function (listener) {
this.notifier.removeListener$TT(listener);
});

Clazz.newMeth(C$, 'getListeners', function () {
return this.notifier.getListeners();
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:33:03
