(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[['edu.colorado.phet.common.phetcommon.math.vector.Vector3D']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "PlaneD");
C$.XY = null;
C$.XZ = null;
C$.YZ = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.XY = Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$D,[(I$[1]||$incl$(1)).Z_UNIT, 0]);
C$.XZ = Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$D,[(I$[1]||$incl$(1)).Y_UNIT, 0]);
C$.YZ = Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$D,[(I$[1]||$incl$(1)).X_UNIT, 0]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.normal = null;
this.distance = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$D', function (normal, distance) {
C$.$init$.apply(this);
this.normal = normal;
this.distance = distance;
}, 1);

Clazz.newMeth(C$, 'intersectWithRay$edu_colorado_phet_common_phetcommon_math_Ray3D', function (ray) {
return ray.pointAtDistance$D(ray.distanceToPlane$edu_colorado_phet_common_phetcommon_math_PlaneD(this));
});

Clazz.newMeth(C$, 'fromTriangle$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D', function (a, b, c) {
var normal = (c.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3D(a)).cross$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3D(b.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3D(a));
if (normal.magnitude() == 0 ) {
return null;
}normal = normal.normalized();
return Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$D,[normal, normal.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3D(a)]);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:33:00
