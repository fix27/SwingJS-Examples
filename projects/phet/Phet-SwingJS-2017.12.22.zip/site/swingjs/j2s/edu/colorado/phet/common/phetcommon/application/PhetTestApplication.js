(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.application"),I$=[['java.util.ArrayList','java.util.Arrays','edu.colorado.phet.common.phetcommon.application.PhetApplicationConfig','edu.colorado.phet.common.phetcommon.application.PhetApplication','edu.colorado.phet.common.phetcommon.application.Module','edu.colorado.phet.common.phetcommon.application.PhetTestApplication$1','edu.colorado.phet.common.phetcommon.application.PhetApplicationLauncher']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "PhetTestApplication");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.args = null;
this.frameSetup = null;
this.appConstructor = null;
this.modules = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.modules = Clazz.new_((I$[1]||$incl$(1)));
}, 1);

Clazz.newMeth(C$, 'c$$SA', function (args) {
C$.c$$SA$edu_colorado_phet_common_phetcommon_view_util_FrameSetup.apply(this, [args, null]);
}, 1);

Clazz.newMeth(C$, 'c$$SA$edu_colorado_phet_common_phetcommon_view_util_FrameSetup', function (args, frameSetup) {
C$.$init$.apply(this);
this.args = p$.processArgs$SA.apply(this, [args]);
this.frameSetup = frameSetup;
}, 1);

Clazz.newMeth(C$, 'processArgs$SA', function (args) {
var list = Clazz.new_((I$[1]||$incl$(1)).c$$java_util_Collection,[(I$[2]||$incl$(2)).asList$TTA(args)]);
list.add$TE("-statistics-off");
list.add$TE("-updates-off");
return list.toArray$TTA(Clazz.array(java.lang.String, [list.size()]));
});

Clazz.newMeth(C$, 'addModule$edu_colorado_phet_common_phetcommon_application_Module', function (module) {
this.modules.add$TE(module);
});

Clazz.newMeth(C$, 'setApplicationConstructor$edu_colorado_phet_common_phetcommon_application_ApplicationConstructor', function (appConstructor) {
this.appConstructor = appConstructor;
});

Clazz.newMeth(C$, 'startApplication', function () {
var config = Clazz.new_((I$[3]||$incl$(3)).c$$SA$S,[this.args, "phetcommon"]);
if (this.frameSetup != null ) {
config.setFrameSetup$edu_colorado_phet_common_phetcommon_view_util_FrameSetup(this.frameSetup);
}if (this.appConstructor == null ) {
this.appConstructor = ((
(function(){var C$=Clazz.newClass(P$, "PhetTestApplication$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.application.ApplicationConstructor', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getApplication$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig', function (config) {
var phetApplication = ((
(function(){var C$=Clazz.newClass(P$, "PhetTestApplication$1$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('edu.colorado.phet.common.phetcommon.application.PhetApplication'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
})()
), Clazz.new_((I$[4]||$incl$(4)).c$$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig, [this, null, config],P$.PhetTestApplication$1$1));
phetApplication.setModules$edu_colorado_phet_common_phetcommon_application_ModuleA(this.b$['edu.colorado.phet.common.phetcommon.application.PhetTestApplication'].modules.toArray$TTA(Clazz.array((I$[5]||$incl$(5)), [this.b$['edu.colorado.phet.common.phetcommon.application.PhetTestApplication'].modules.size()])));
return phetApplication;
});
})()
), Clazz.new_((I$[6]||$incl$(6)).$init$, [this, null]));
}Clazz.new_((I$[7]||$incl$(7))).launchSim$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig$edu_colorado_phet_common_phetcommon_application_ApplicationConstructor(config, this.appConstructor);
});

Clazz.newMeth(C$, 'setModules$edu_colorado_phet_common_phetcommon_application_ModuleA', function (m) {
this.modules.addAll$java_util_Collection((I$[2]||$incl$(2)).asList$TTA(m));
});

Clazz.newMeth(C$, 'getPhetFrame', function () {
return (I$[4]||$incl$(4)).getInstance().getPhetFrame();
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:32:57
