(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.property"),I$=[];
var C$=Clazz.newInterface(P$, "ChangeObserver");
})();
//Created 2017-12-22 22:33:03
