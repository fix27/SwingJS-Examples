(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[['edu.colorado.phet.common.phetcommon.math.MathUtil',['java.awt.geom.Point2D','.Double']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Point2DPolar");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.r = 0;
this.theta = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$D$D', function (r, theta) {
C$.$init$.apply(this);
this.r = r;
this.theta = theta;
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_geom_Point2D', function (cartCoords) {
C$.c$$java_awt_geom_Point2D$D$D.apply(this, [cartCoords, 0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_geom_Point2D$java_awt_geom_Point2D', function (cartCoords, polarOrigin) {
C$.$init$.apply(this);
this.r = (I$[1]||$incl$(1)).getDistance$java_awt_geom_Point2D$java_awt_geom_Point2D(polarOrigin, cartCoords);
var dx = cartCoords.getX() - polarOrigin.getX();
var dy = cartCoords.getY() - polarOrigin.getY();
this.theta = Math.atan2(dy, dx);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_geom_Point2D$D$D', function (cartCoords, polarOriginX, polarOriginY) {
C$.c$$java_awt_geom_Point2D$java_awt_geom_Point2D.apply(this, [cartCoords, Clazz.new_((I$[2]||$incl$(2)).c$$D$D,[polarOriginX, polarOriginY])]);
}, 1);

Clazz.newMeth(C$, 'toPoint2D$java_awt_geom_Point2D', function (polarOrigin) {
var x = polarOrigin.getX() + this.getR() * Math.cos(this.getTheta());
var y = polarOrigin.getY() + this.getR() * Math.sin(this.getTheta());
return Clazz.new_((I$[2]||$incl$(2)).c$$D$D,[x, y]);
});

Clazz.newMeth(C$, 'getR', function () {
return this.r;
});

Clazz.newMeth(C$, 'setR$D', function (r) {
this.r = r;
});

Clazz.newMeth(C$, 'getTheta', function () {
return this.theta;
});

Clazz.newMeth(C$, 'setTheta$D', function (theta) {
this.theta = theta;
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:33:00
