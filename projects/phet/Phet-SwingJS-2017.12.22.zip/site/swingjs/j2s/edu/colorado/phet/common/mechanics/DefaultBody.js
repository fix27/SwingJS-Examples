(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.mechanics"),I$=[];
var C$=Clazz.newClass(P$, "DefaultBody", null, 'edu.colorado.phet.common.mechanics.Body');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_geom_Point2D$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D$D$D', function (location, velocity, acceleration, mass, charge) {
C$.superclazz.c$$java_awt_geom_Point2D$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D$D$D.apply(this, [location, velocity, acceleration, mass, charge]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getCM', function () {
return null;
});

Clazz.newMeth(C$, 'getMomentOfInertia', function () {
return 0;
});
})();
//Created 2017-12-22 22:32:29
