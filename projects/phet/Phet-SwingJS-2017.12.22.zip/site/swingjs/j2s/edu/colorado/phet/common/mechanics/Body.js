(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.mechanics"),I$=[['edu.colorado.phet.common.phetcommon.math.vector.MutableVector2D']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Body", null, 'edu.colorado.phet.common.phetcommon.model.Particle');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.lastColidedBody = null;
this.theta = 0;
this.omega = 0;
this.alpha = 0;
this.prevAlpha = 0;
this.mass = 0;
this.momentum = null;
this.container = null;
this.vtemp = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.lastColidedBody = null;
this.momentum = Clazz.new_((I$[1]||$incl$(1)));
}, 1);

Clazz.newMeth(C$, 'clone', function () {
var clone = C$.superclazz.prototype.clone.apply(this, []);
clone.lastColidedBody = this.lastColidedBody == null  ? null : this.lastColidedBody.clone();
clone.momentum = Clazz.new_((I$[1]||$incl$(1)).c$$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D,[this.momentum]);
return clone;
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.type = 1;
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_geom_Point2D$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D$D$D', function (location, velocity, acceleration, mass, charge) {
C$.superclazz.c$$java_awt_geom_Point2D$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D.apply(this, [location, velocity, acceleration]);
C$.$init$.apply(this);
this.type = 1;
this.setMass$D(mass);
}, 1);

Clazz.newMeth(C$, 'getKineticEnergy', function () {
return (this.getMass() * this.getVelocity().magnitudeSquared() / 2) + (this.omega == 0  ? 0 : this.getMomentOfInertia() * this.omega * this.omega  / 2);
});

Clazz.newMeth(C$, 'stepInTime$D', function (dt) {
this.stepInTimeB$D(dt);
});

Clazz.newMeth(C$, 'stepInTimeB$D', function (dt) {
this.theta = this.theta + dt * this.omega + dt * dt * this.alpha  / 2;
this.omega = this.omega + dt * (this.alpha + this.prevAlpha) / 2;
this.prevAlpha = this.alpha;
this.stepInTimeP$D(dt);
this.momentum.setComponents$D$D(this.getVelocity().getX() * this.getMass(), this.getVelocity().getY() * this.getMass());
});

Clazz.newMeth(C$, 'getSpeed', function () {
return this.getVelocity().magnitude();
});

Clazz.newMeth(C$, 'getTheta', function () {
return this.theta;
});

Clazz.newMeth(C$, 'setTheta$D', function (theta) {
this.theta = theta;
});

Clazz.newMeth(C$, 'getOmega', function () {
return this.omega;
});

Clazz.newMeth(C$, 'setOmega$D', function (omega) {
this.omega = omega;
});

Clazz.newMeth(C$, 'getAlpha', function () {
return this.alpha;
});

Clazz.newMeth(C$, 'setAlpha$D', function (alpha) {
this.alpha = alpha;
});

Clazz.newMeth(C$, 'getMass', function () {
return this.mass;
});

Clazz.newMeth(C$, 'setMass$D', function (mass) {
this.mass = mass;
});

Clazz.newMeth(C$, 'getMomentum', function () {
return Clazz.new_((I$[1]||$incl$(1)).c$$D$D,[this.getVelocity().getX() * this.getMass(), this.getVelocity().getY() * this.getMass()]);
});

Clazz.newMeth(C$, 'getMomentumNoCopy', function () {
if (this.vtemp == null ) this.vtemp = Clazz.new_((I$[1]||$incl$(1)));
this.vtemp.setComponents$D$D(this.getVelocity().getX() * this.getMass(), this.getVelocity().getY() * this.getMass());
return this.vtemp;
});

Clazz.newMeth(C$, 'setMomentum$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D', function (momentum) {
this.setVelocityNoObs$D$D(momentum.getX() / this.getMass(), momentum.getY() / this.getMass());
});

Clazz.newMeth(C$, 'getLastColidedBody', function () {
return this.lastColidedBody;
});

Clazz.newMeth(C$, 'setLastColidedBody$edu_colorado_phet_common_phetcommon_model_Particle', function (lastColidedBody) {
this.lastColidedBody = lastColidedBody;
});
})();
//Created 2017-12-22 22:32:27
