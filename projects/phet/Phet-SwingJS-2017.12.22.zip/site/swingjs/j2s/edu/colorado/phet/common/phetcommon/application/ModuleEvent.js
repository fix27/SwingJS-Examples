(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.application"),I$=[];
var C$=Clazz.newClass(P$, "ModuleEvent");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.phetApplication = null;
this.module = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_application_PhetApplication$edu_colorado_phet_common_phetcommon_application_Module', function (phetApplication, module) {
C$.$init$.apply(this);
this.phetApplication = phetApplication;
this.module = module;
}, 1);

Clazz.newMeth(C$, 'getModule', function () {
return this.module;
});

Clazz.newMeth(C$, 'getPhetApplication', function () {
return this.phetApplication;
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:32:52
