(function(){var P$=Clazz.newPackage("edu.colorado.phet.assets"),I$=[];
var C$=Clazz.newClass(P$, "Assets");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'main', function (args) {
}, 1);

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:32:22
