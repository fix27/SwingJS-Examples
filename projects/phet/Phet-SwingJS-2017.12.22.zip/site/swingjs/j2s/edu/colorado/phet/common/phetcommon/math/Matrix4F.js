(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[[['edu.colorado.phet.common.phetcommon.math.Matrix4F','.MatrixType'],'edu.colorado.phet.common.phetcommon.math.vector.Vector4F','edu.colorado.phet.common.phetcommon.math.vector.Vector3F']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Matrix4F");
C$.IDENTITY = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.IDENTITY = C$.rowMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix4F_MatrixType(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, (I$[1]||$incl$(1)).IDENTITY);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.v00 = 0;
this.v01 = 0;
this.v02 = 0;
this.v03 = 0;
this.v10 = 0;
this.v11 = 0;
this.v12 = 0;
this.v13 = 0;
this.v20 = 0;
this.v21 = 0;
this.v22 = 0;
this.v23 = 0;
this.v30 = 0;
this.v31 = 0;
this.v32 = 0;
this.v33 = 0;
this.type = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'hashCode', function () {
return Float.floatToIntBits(this.v00) ^ Float.floatToIntBits(this.v01) ^ Float.floatToIntBits(this.v02) ^ Float.floatToIntBits(this.v03) ^ Float.floatToIntBits(this.v10) ^ Float.floatToIntBits(this.v11) ^ Float.floatToIntBits(this.v12) ^ Float.floatToIntBits(this.v13) ^ Float.floatToIntBits(this.v20) ^ Float.floatToIntBits(this.v21) ^ Float.floatToIntBits(this.v22) ^ Float.floatToIntBits(this.v23) ^ Float.floatToIntBits(this.v30) ^ Float.floatToIntBits(this.v31) ^ Float.floatToIntBits(this.v32) ^ Float.floatToIntBits(this.v33) ;
});

Clazz.newMeth(C$, 'equals$O', function (o) {
if (!(Clazz.instanceOf(o, "edu.colorado.phet.common.phetcommon.math.Matrix4F"))) {
return false;
}var m = o;
return (m.v00 == this.v00  && m.v01 == this.v01   && m.v02 == this.v02   && m.v03 == this.v03   && m.v10 == this.v10   && m.v11 == this.v11   && m.v12 == this.v12   && m.v13 == this.v13   && m.v20 == this.v20   && m.v21 == this.v21   && m.v22 == this.v22   && m.v23 == this.v23   && m.v30 == this.v30   && m.v31 == this.v31   && m.v32 == this.v32   && m.v33 == this.v33  );
});

Clazz.newMeth(C$, 'fromMatrix3f$edu_colorado_phet_common_phetcommon_math_Matrix3F', function (m) {
return m.toMatrix4f();
}, 1);

Clazz.newMeth(C$, 'translation$F$F$F', function (x, y, z) {
return C$.rowMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix4F_MatrixType(1, 0, 0, x, 0, 1, 0, y, 0, 0, 1, z, 0, 0, 0, 1, (I$[1]||$incl$(1)).TRANSLATION_3D);
}, 1);

Clazz.newMeth(C$, 'translation$edu_colorado_phet_common_phetcommon_math_vector_Vector3F', function (v) {
return C$.translation$F$F$F(v.x, v.y, v.z);
}, 1);

Clazz.newMeth(C$, 'scaling$F', function (s) {
return C$.scaling$F$F$F(s, s, s);
}, 1);

Clazz.newMeth(C$, 'scaling$F$F$F', function (x, y, z) {
return C$.rowMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix4F_MatrixType(x, 0, 0, 0, 0, y, 0, 0, 0, 0, z, 0, 0, 0, 0, 1, (I$[1]||$incl$(1)).SCALING);
}, 1);

Clazz.newMeth(C$, 'rotation$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$F', function (axis, angle) {
var c = Math.cos(angle);
var s = Math.sin(angle);
var C = 1 - c;
var x = axis.getX();
var y = axis.getY();
var z = axis.getZ();
return C$.rowMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix4F_MatrixType(x * x * C  + c, x * y * C  - z * s, x * z * C  + y * s, 0, y * x * C  + z * s, y * y * C  + c, y * z * C  - x * s, 0, z * x * C  - y * s, z * y * C  + x * s, z * z * C  + c, 0, 0, 0, 0, 1, (I$[1]||$incl$(1)).OTHER);
}, 1);

Clazz.newMeth(C$, 'rotation$edu_colorado_phet_common_phetcommon_math_QuaternionF', function (rotation) {
return rotation.toRotationMatrix().toMatrix4f();
}, 1);

Clazz.newMeth(C$, 'rotation$edu_colorado_phet_common_phetcommon_math_QuaternionF$edu_colorado_phet_common_phetcommon_math_vector_Vector3F', function (rotation, translation) {
return rotation.toRotationMatrix().toMatrix4f().plus$edu_colorado_phet_common_phetcommon_math_Matrix4F(C$.translation$edu_colorado_phet_common_phetcommon_math_vector_Vector3F(translation));
}, 1);

Clazz.newMeth(C$, 'rotationX$F', function (angle) {
var c = Math.cos(angle);
var s = Math.sin(angle);
return C$.rowMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix4F_MatrixType(1, 0, 0, 0, 0, c, -s, 0, 0, s, c, 0, 0, 0, 0, 1, (I$[1]||$incl$(1)).OTHER);
}, 1);

Clazz.newMeth(C$, 'rotationY$F', function (angle) {
var c = Math.cos(angle);
var s = Math.sin(angle);
return C$.rowMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix4F_MatrixType(c, 0, s, 0, 0, 1, 0, 0, -s, 0, c, 0, 0, 0, 0, 1, (I$[1]||$incl$(1)).OTHER);
}, 1);

Clazz.newMeth(C$, 'rotationZ$F', function (angle) {
var c = Math.cos(angle);
var s = Math.sin(angle);
return C$.rowMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix4F_MatrixType(c, -s, 0, 0, s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, (I$[1]||$incl$(1)).OTHER);
}, 1);

Clazz.newMeth(C$, 'rowMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F', function (v00, v01, v02, v03, v10, v11, v12, v13, v20, v21, v22, v23, v30, v31, v32, v33) {
return C$.rowMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix4F_MatrixType(v00, v01, v02, v03, v10, v11, v12, v13, v20, v21, v22, v23, v30, v31, v32, v33, (I$[1]||$incl$(1)).OTHER);
}, 1);

Clazz.newMeth(C$, 'rowMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix4F_MatrixType', function (v00, v01, v02, v03, v10, v11, v12, v13, v20, v21, v22, v23, v30, v31, v32, v33, type) {
return Clazz.new_(C$.c$$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix4F_MatrixType,[v00, v01, v02, v03, v10, v11, v12, v13, v20, v21, v22, v23, v30, v31, v32, v33, type]);
}, 1);

Clazz.newMeth(C$, 'columnMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F', function (v00, v10, v20, v30, v01, v11, v21, v31, v02, v12, v22, v32, v03, v13, v23, v33) {
return C$.columnMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix4F_MatrixType(v00, v10, v20, v30, v01, v11, v21, v31, v02, v12, v22, v32, v03, v13, v23, v33, (I$[1]||$incl$(1)).OTHER);
}, 1);

Clazz.newMeth(C$, 'columnMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix4F_MatrixType', function (v00, v10, v20, v30, v01, v11, v21, v31, v02, v12, v22, v32, v03, v13, v23, v33, type) {
return Clazz.new_(C$.c$$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix4F_MatrixType,[v00, v01, v02, v03, v10, v11, v12, v13, v20, v21, v22, v23, v30, v31, v32, v33, type]);
}, 1);

Clazz.newMeth(C$, 'fromGLBuffer$java_nio_FloatBuffer', function (buffer) {
buffer.rewind();
return C$.columnMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix4F_MatrixType(buffer.get(), buffer.get(), buffer.get(), buffer.get(), buffer.get(), buffer.get(), buffer.get(), buffer.get(), buffer.get(), buffer.get(), buffer.get(), buffer.get(), buffer.get(), buffer.get(), buffer.get(), buffer.get(), (I$[1]||$incl$(1)).OTHER);
}, 1);

Clazz.newMeth(C$, 'c$$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix4F_MatrixType', function (v00, v01, v02, v03, v10, v11, v12, v13, v20, v21, v22, v23, v30, v31, v32, v33, type) {
C$.$init$.apply(this);
this.v00 = v00;
this.v10 = v10;
this.v20 = v20;
this.v30 = v30;
this.v01 = v01;
this.v11 = v11;
this.v21 = v21;
this.v31 = v31;
this.v02 = v02;
this.v12 = v12;
this.v22 = v22;
this.v32 = v32;
this.v03 = v03;
this.v13 = v13;
this.v23 = v23;
this.v33 = v33;
this.type = type;
}, 1);

Clazz.newMeth(C$, 'plus$edu_colorado_phet_common_phetcommon_math_Matrix4F', function (m) {
return C$.rowMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F(this.v00 + m.v00, this.v01 + m.v01, this.v02 + m.v02, this.v03 + m.v03, this.v10 + m.v10, this.v11 + m.v11, this.v12 + m.v12, this.v13 + m.v13, this.v20 + m.v20, this.v21 + m.v21, this.v22 + m.v22, this.v23 + m.v23, this.v30 + m.v30, this.v31 + m.v31, this.v32 + m.v32, this.v33 + m.v33);
});

Clazz.newMeth(C$, 'minus$edu_colorado_phet_common_phetcommon_math_Matrix4F', function (m) {
return C$.rowMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F(this.v00 - m.v00, this.v01 - m.v01, this.v02 - m.v02, this.v03 - m.v03, this.v10 - m.v10, this.v11 - m.v11, this.v12 - m.v12, this.v13 - m.v13, this.v20 - m.v20, this.v21 - m.v21, this.v22 - m.v22, this.v23 - m.v23, this.v30 - m.v30, this.v31 - m.v31, this.v32 - m.v32, this.v33 - m.v33);
});

Clazz.newMeth(C$, 'times$edu_colorado_phet_common_phetcommon_math_Matrix4F', function (m) {
var type = (I$[1]||$incl$(1)).OTHER;
if (this.type === (I$[1]||$incl$(1)).TRANSLATION_3D  && m.type === (I$[1]||$incl$(1)).TRANSLATION_3D  ) {
type = (I$[1]||$incl$(1)).TRANSLATION_3D;
}if (this.type === (I$[1]||$incl$(1)).SCALING  && m.type === (I$[1]||$incl$(1)).SCALING  ) {
type = (I$[1]||$incl$(1)).SCALING;
}if (this.type === (I$[1]||$incl$(1)).IDENTITY ) {
type = m.type;
}if (m.type === (I$[1]||$incl$(1)).IDENTITY ) {
type = this.type;
}return C$.rowMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix4F_MatrixType(this.v00 * m.v00 + this.v01 * m.v10 + this.v02 * m.v20 + this.v03 * m.v30, this.v00 * m.v01 + this.v01 * m.v11 + this.v02 * m.v21 + this.v03 * m.v31, this.v00 * m.v02 + this.v01 * m.v12 + this.v02 * m.v22 + this.v03 * m.v32, this.v00 * m.v03 + this.v01 * m.v13 + this.v02 * m.v23 + this.v03 * m.v33, this.v10 * m.v00 + this.v11 * m.v10 + this.v12 * m.v20 + this.v13 * m.v30, this.v10 * m.v01 + this.v11 * m.v11 + this.v12 * m.v21 + this.v13 * m.v31, this.v10 * m.v02 + this.v11 * m.v12 + this.v12 * m.v22 + this.v13 * m.v32, this.v10 * m.v03 + this.v11 * m.v13 + this.v12 * m.v23 + this.v13 * m.v33, this.v20 * m.v00 + this.v21 * m.v10 + this.v22 * m.v20 + this.v23 * m.v30, this.v20 * m.v01 + this.v21 * m.v11 + this.v22 * m.v21 + this.v23 * m.v31, this.v20 * m.v02 + this.v21 * m.v12 + this.v22 * m.v22 + this.v23 * m.v32, this.v20 * m.v03 + this.v21 * m.v13 + this.v22 * m.v23 + this.v23 * m.v33, this.v30 * m.v00 + this.v31 * m.v10 + this.v32 * m.v20 + this.v33 * m.v30, this.v30 * m.v01 + this.v31 * m.v11 + this.v32 * m.v21 + this.v33 * m.v31, this.v30 * m.v02 + this.v31 * m.v12 + this.v32 * m.v22 + this.v33 * m.v32, this.v30 * m.v03 + this.v31 * m.v13 + this.v32 * m.v23 + this.v33 * m.v33, type);
});

Clazz.newMeth(C$, 'times$edu_colorado_phet_common_phetcommon_math_vector_Vector4F', function (v) {
var x = this.v00 * v.getX() + this.v01 * v.getY() + this.v02 * v.getZ() + this.v03 * v.getW();
var y = this.v10 * v.getX() + this.v11 * v.getY() + this.v12 * v.getZ() + this.v13 * v.getW();
var z = this.v20 * v.getX() + this.v21 * v.getY() + this.v22 * v.getZ() + this.v23 * v.getW();
var w = this.v30 * v.getX() + this.v31 * v.getY() + this.v32 * v.getZ() + this.v33 * v.getW();
return Clazz.new_((I$[2]||$incl$(2)).c$$F$F$F$F,[x, y, z, w]);
});

Clazz.newMeth(C$, 'timesTranspose$edu_colorado_phet_common_phetcommon_math_vector_Vector4F', function (v) {
var x = this.v00 * v.getX() + this.v10 * v.getY() + this.v20 * v.getZ() + this.v30 * v.getW();
var y = this.v01 * v.getX() + this.v11 * v.getY() + this.v21 * v.getZ() + this.v31 * v.getW();
var z = this.v02 * v.getX() + this.v12 * v.getY() + this.v22 * v.getZ() + this.v32 * v.getW();
var w = this.v03 * v.getX() + this.v13 * v.getY() + this.v23 * v.getZ() + this.v33 * v.getW();
return Clazz.new_((I$[2]||$incl$(2)).c$$F$F$F$F,[x, y, z, w]);
});

Clazz.newMeth(C$, 'timesVector$edu_colorado_phet_common_phetcommon_math_vector_Vector3F', function (v) {
var x = this.v00 * v.getX() + this.v10 * v.getY() + this.v20 * v.getZ();
var y = this.v01 * v.getX() + this.v11 * v.getY() + this.v21 * v.getZ();
var z = this.v02 * v.getX() + this.v12 * v.getY() + this.v22 * v.getZ();
return Clazz.new_((I$[3]||$incl$(3)).c$$F$F$F,[x, y, z]);
});

Clazz.newMeth(C$, 'times$edu_colorado_phet_common_phetcommon_math_vector_Vector3F', function (v) {
return this.times$edu_colorado_phet_common_phetcommon_math_vector_Vector4F(Clazz.new_((I$[2]||$incl$(2)).c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3F,[v])).to3F();
});

Clazz.newMeth(C$, 'timesTranspose$edu_colorado_phet_common_phetcommon_math_vector_Vector3F', function (v) {
return this.timesTranspose$edu_colorado_phet_common_phetcommon_math_vector_Vector4F(Clazz.new_((I$[2]||$incl$(2)).c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3F,[v])).to3F();
});

Clazz.newMeth(C$, 'transposed', function () {
return C$.rowMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F(this.v00, this.v10, this.v20, this.v30, this.v01, this.v11, this.v21, this.v31, this.v02, this.v12, this.v22, this.v32, this.v03, this.v13, this.v23, this.v33);
});

Clazz.newMeth(C$, 'determinant', function () {
return this.v03 * this.v12 * this.v21 * this.v30  - this.v02 * this.v13 * this.v21 * this.v30  - this.v03 * this.v11 * this.v22 * this.v30  + this.v01 * this.v13 * this.v22 * this.v30  + this.v02 * this.v11 * this.v23 * this.v30  - this.v01 * this.v12 * this.v23 * this.v30  - this.v03 * this.v12 * this.v20 * this.v31  + this.v02 * this.v13 * this.v20 * this.v31  + this.v03 * this.v10 * this.v22 * this.v31  - this.v00 * this.v13 * this.v22 * this.v31  - this.v02 * this.v10 * this.v23 * this.v31  + this.v00 * this.v12 * this.v23 * this.v31  + this.v03 * this.v11 * this.v20 * this.v32  - this.v01 * this.v13 * this.v20 * this.v32  - this.v03 * this.v10 * this.v21 * this.v32  + this.v00 * this.v13 * this.v21 * this.v32  + this.v01 * this.v10 * this.v23 * this.v32  - this.v00 * this.v11 * this.v23 * this.v32  - this.v02 * this.v11 * this.v20 * this.v33  + this.v01 * this.v12 * this.v20 * this.v33  + this.v02 * this.v10 * this.v21 * this.v33  - this.v00 * this.v12 * this.v21 * this.v33  - this.v01 * this.v10 * this.v22 * this.v33  + this.v00 * this.v11 * this.v22 * this.v33 ;
});

Clazz.newMeth(C$, 'negated', function () {
return C$.rowMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F(-this.v00, -this.v01, -this.v02, -this.v03, -this.v10, -this.v11, -this.v12, -this.v13, -this.v20, -this.v21, -this.v22, -this.v23, -this.v30, -this.v31, -this.v32, -this.v33);
});

Clazz.newMeth(C$, 'inverted', function () {
var determinant = this.determinant();
if (determinant != 0 ) {
return C$.rowMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F((-this.v31 * this.v22 * this.v13  + this.v21 * this.v32 * this.v13  + this.v31 * this.v12 * this.v23  - this.v11 * this.v32 * this.v23  - this.v21 * this.v12 * this.v33  + this.v11 * this.v22 * this.v33 ) / determinant, (this.v31 * this.v22 * this.v03  - this.v21 * this.v32 * this.v03  - this.v31 * this.v02 * this.v23  + this.v01 * this.v32 * this.v23  + this.v21 * this.v02 * this.v33  - this.v01 * this.v22 * this.v33 ) / determinant, (-this.v31 * this.v12 * this.v03  + this.v11 * this.v32 * this.v03  + this.v31 * this.v02 * this.v13  - this.v01 * this.v32 * this.v13  - this.v11 * this.v02 * this.v33  + this.v01 * this.v12 * this.v33 ) / determinant, (this.v21 * this.v12 * this.v03  - this.v11 * this.v22 * this.v03  - this.v21 * this.v02 * this.v13  + this.v01 * this.v22 * this.v13  + this.v11 * this.v02 * this.v23  - this.v01 * this.v12 * this.v23 ) / determinant, (this.v30 * this.v22 * this.v13  - this.v20 * this.v32 * this.v13  - this.v30 * this.v12 * this.v23  + this.v10 * this.v32 * this.v23  + this.v20 * this.v12 * this.v33  - this.v10 * this.v22 * this.v33 ) / determinant, (-this.v30 * this.v22 * this.v03  + this.v20 * this.v32 * this.v03  + this.v30 * this.v02 * this.v23  - this.v00 * this.v32 * this.v23  - this.v20 * this.v02 * this.v33  + this.v00 * this.v22 * this.v33 ) / determinant, (this.v30 * this.v12 * this.v03  - this.v10 * this.v32 * this.v03  - this.v30 * this.v02 * this.v13  + this.v00 * this.v32 * this.v13  + this.v10 * this.v02 * this.v33  - this.v00 * this.v12 * this.v33 ) / determinant, (-this.v20 * this.v12 * this.v03  + this.v10 * this.v22 * this.v03  + this.v20 * this.v02 * this.v13  - this.v00 * this.v22 * this.v13  - this.v10 * this.v02 * this.v23  + this.v00 * this.v12 * this.v23 ) / determinant, (-this.v30 * this.v21 * this.v13  + this.v20 * this.v31 * this.v13  + this.v30 * this.v11 * this.v23  - this.v10 * this.v31 * this.v23  - this.v20 * this.v11 * this.v33  + this.v10 * this.v21 * this.v33 ) / determinant, (this.v30 * this.v21 * this.v03  - this.v20 * this.v31 * this.v03  - this.v30 * this.v01 * this.v23  + this.v00 * this.v31 * this.v23  + this.v20 * this.v01 * this.v33  - this.v00 * this.v21 * this.v33 ) / determinant, (-this.v30 * this.v11 * this.v03  + this.v10 * this.v31 * this.v03  + this.v30 * this.v01 * this.v13  - this.v00 * this.v31 * this.v13  - this.v10 * this.v01 * this.v33  + this.v00 * this.v11 * this.v33 ) / determinant, (this.v20 * this.v11 * this.v03  - this.v10 * this.v21 * this.v03  - this.v20 * this.v01 * this.v13  + this.v00 * this.v21 * this.v13  + this.v10 * this.v01 * this.v23  - this.v00 * this.v11 * this.v23 ) / determinant, (this.v30 * this.v21 * this.v12  - this.v20 * this.v31 * this.v12  - this.v30 * this.v11 * this.v22  + this.v10 * this.v31 * this.v22  + this.v20 * this.v11 * this.v32  - this.v10 * this.v21 * this.v32 ) / determinant, (-this.v30 * this.v21 * this.v02  + this.v20 * this.v31 * this.v02  + this.v30 * this.v01 * this.v22  - this.v00 * this.v31 * this.v22  - this.v20 * this.v01 * this.v32  + this.v00 * this.v21 * this.v32 ) / determinant, (this.v30 * this.v11 * this.v02  - this.v10 * this.v31 * this.v02  - this.v30 * this.v01 * this.v12  + this.v00 * this.v31 * this.v12  + this.v10 * this.v01 * this.v32  - this.v00 * this.v11 * this.v32 ) / determinant, (-this.v20 * this.v11 * this.v02  + this.v10 * this.v21 * this.v02  + this.v20 * this.v01 * this.v12  - this.v00 * this.v21 * this.v12  - this.v10 * this.v01 * this.v22  + this.v00 * this.v11 * this.v22 ) / determinant);
} else {
throw Clazz.new_(Clazz.load('java.lang.RuntimeException').c$$S,["Matrix could not be inverted"]);
}});

Clazz.newMeth(C$, 'writeToBuffer$java_nio_FloatBuffer', function (buf) {
buf.rewind();
buf.put$FA(Clazz.array(Float.TYPE, -1, [this.v00, this.v10, this.v20, this.v30, this.v01, this.v11, this.v21, this.v31, this.v02, this.v12, this.v22, this.v32, this.v03, this.v13, this.v23, this.v33]));
});

Clazz.newMeth(C$, 'writeTransposeToBuffer$java_nio_FloatBuffer', function (buf) {
buf.rewind();
buf.put$FA(Clazz.array(Float.TYPE, -1, [this.v00, this.v01, this.v02, this.v03, this.v10, this.v11, this.v12, this.v13, this.v20, this.v21, this.v22, this.v23, this.v30, this.v31, this.v32, this.v33]));
});

Clazz.newMeth(C$, 'toString', function () {
return edu.colorado.phet.common.phetcommon.util.FunctionalUtils.mkString$java_util_Collection$S(java.util.Arrays.asList$TTA([edu.colorado.phet.common.phetcommon.util.FunctionalUtils.mkString$java_util_Collection$S(java.util.Arrays.asList$TTA([new Float(this.v00), new Float(this.v01), new Float(this.v02), new Float(this.v03)]), " "), edu.colorado.phet.common.phetcommon.util.FunctionalUtils.mkString$java_util_Collection$S(java.util.Arrays.asList$TTA([new Float(this.v10), new Float(this.v11), new Float(this.v12), new Float(this.v13)]), " "), edu.colorado.phet.common.phetcommon.util.FunctionalUtils.mkString$java_util_Collection$S(java.util.Arrays.asList$TTA([new Float(this.v20), new Float(this.v21), new Float(this.v22), new Float(this.v23)]), " "), edu.colorado.phet.common.phetcommon.util.FunctionalUtils.mkString$java_util_Collection$S(java.util.Arrays.asList$TTA([new Float(this.v30), new Float(this.v31), new Float(this.v32), new Float(this.v33)]), " ")]), "\u000a");
});

Clazz.newMeth(C$, 'getTranslation', function () {
return Clazz.new_((I$[3]||$incl$(3)).c$$F$F$F,[this.v03, this.v13, this.v23]);
});

Clazz.newMeth(C$, 'getScaling', function () {
return Clazz.new_((I$[3]||$incl$(3)).c$$F$F$F,[this.v00, this.v11, this.v22]);
});
;
(function(){var C$=Clazz.newClass(P$.Matrix4F, "MatrixType", null, 'Enum');

C$.$clinit$ = function() {Clazz.load(C$, 1);
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "IDENTITY", 0, []);
Clazz.newEnumConst($vals, C$.c$, "TRANSLATION_3D", 1, []);
Clazz.newEnumConst($vals, C$.c$, "SCALING", 2, []);
Clazz.newEnumConst($vals, C$.c$, "OTHER", 3, []);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values', function() { return $vals }, 1);
})()

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:32:59
