(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.mechanics"),I$=[];
var C$=Clazz.newClass(P$, "PhysicalVector");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.scalars = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I', function (numDimensions) {
C$.$init$.apply(this);
this.scalars = Clazz.array(Double.TYPE, [numDimensions]);
}, 1);

Clazz.newMeth(C$, 'getScalarAt$I', function (idx) {
return this.scalars[idx];
});

Clazz.newMeth(C$, 'setScalarAt$I$D', function (idx, value) {
this.scalars[idx] = value;
});

Clazz.newMeth(C$, 'equals$O', function (obj) {
var result = true;
if (this.getClass() !== obj.getClass() ) {
result = false;
} else {
var that = obj;
for (var i = 0; result == true  && i < this.scalars.length ; i++) {
if (this.scalars[i] != that.scalars[i] ) {
result = false;
}}
}return result;
});

Clazz.newMeth(C$, 'getMagnitudeSq', function () {
var sum = 0;
for (var i = 0; i < this.scalars.length; i++) {
sum += this.scalars[i] * this.scalars[i];
}
return sum;
});

Clazz.newMeth(C$, 'getMagnitude', function () {
return Math.sqrt(this.getMagnitudeSq());
});

Clazz.newMeth(C$, 'getLength', function () {
return this.getMagnitude();
});

Clazz.newMeth(C$, 'add$edu_colorado_phet_common_mechanics_PhysicalVector$edu_colorado_phet_common_mechanics_PhysicalVector', function (that, result) {
for (var i = 0; i < this.scalars.length; i++) {
result.scalars[i] = this.scalars[i] + that.scalars[i];
}
return result;
});

Clazz.newMeth(C$, 'generalNormalize', function () {
var length = this.getMagnitude();
return this.multiply$D$edu_colorado_phet_common_mechanics_PhysicalVector(1.0 / length, this);
});

Clazz.newMeth(C$, 'multiply$D$edu_colorado_phet_common_mechanics_PhysicalVector', function (scale, result) {
for (var i = 0; i < this.scalars.length; i++) {
result.scalars[i] = this.scalars[i] * scale;
}
return result;
});

Clazz.newMeth(C$, 'dot$edu_colorado_phet_common_mechanics_PhysicalVector', function (that) {
var result = 0;
for (var i = 0; i < this.scalars.length; i++) {
result += this.scalars[i] * that.scalars[i];
}
return result;
});

Clazz.newMeth(C$, 'distance$edu_colorado_phet_common_mechanics_PhysicalVector', function (that) {
return Math.sqrt(this.distanceSquared$edu_colorado_phet_common_mechanics_PhysicalVector(that));
});

Clazz.newMeth(C$, 'distanceSquared$edu_colorado_phet_common_mechanics_PhysicalVector', function (that) {
if (this.scalars.length != that.scalars.length) {
throw Clazz.new_(Clazz.load('java.lang.RuntimeException').c$$S,["Vectors of different dimensionalities set to PhysicalVector.distanceSquared"]);
}var result = 0;
for (var i = 0; i < this.scalars.length; i++) {
var diff = this.scalars[i] - that.scalars[i];
result += diff * diff;
}
return result;
});

Clazz.newMeth(C$, 'subtract$edu_colorado_phet_common_mechanics_PhysicalVector$edu_colorado_phet_common_mechanics_PhysicalVector', function (that, result) {
for (var i = 0; i < this.scalars.length; i++) {
result.scalars[i] = this.scalars[i] - that.scalars[i];
}
return result;
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:32:29
