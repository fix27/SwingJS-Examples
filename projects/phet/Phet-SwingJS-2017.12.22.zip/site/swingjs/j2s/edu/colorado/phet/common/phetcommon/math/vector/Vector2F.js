(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math.vector"),I$=[];
var C$=Clazz.newClass(P$, "Vector2F", null, 'edu.colorado.phet.common.phetcommon.math.vector.AbstractVector2F');
C$.ZERO = null;
C$.X_UNIT = null;
C$.Y_UNIT = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.ZERO = Clazz.new_(C$);
C$.X_UNIT = Clazz.new_(C$.c$$F$F,[1, 0]);
C$.Y_UNIT = Clazz.new_(C$.c$$F$F,[0, 1]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x = 0;
this.y = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'hashCode', function () {
return Float.floatToIntBits(this.x) ^ Float.floatToIntBits(this.y);
});

Clazz.newMeth(C$, 'equals$O', function (o) {
if (!(Clazz.instanceOf(o, "edu.colorado.phet.common.phetcommon.math.vector.Vector2F"))) {
return false;
}var m = o;
return (m.x == this.x  && m.y == this.y  );
});

Clazz.newMeth(C$, 'c$', function () {
C$.c$$F$F.apply(this, [0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$F$F', function (x, y) {
Clazz.super_(C$, this,1);
this.x = x;
this.y = y;
}, 1);

Clazz.newMeth(C$, 'c$$D$D', function (x, y) {
Clazz.super_(C$, this,1);
this.x = x;
this.y = y;
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2F', function (v) {
C$.c$$F$F.apply(this, [v.getX(), v.getY()]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_Vector2F$edu_colorado_phet_common_phetcommon_math_vector_Vector2F', function (initialPt, finalPt) {
C$.c$$F$F.apply(this, [finalPt.getX() - initialPt.getX(), finalPt.getY() - initialPt.getY()]);
}, 1);

Clazz.newMeth(C$, 'getY', function () {
return this.y;
});

Clazz.newMeth(C$, 'getX', function () {
return this.x;
});

Clazz.newMeth(C$, 'createPolar$F$F', function (radius, angle) {
return Clazz.new_(C$.c$$F$F,[Math.cos(angle), Math.sin(angle)]).times$F(radius);
}, 1);

Clazz.newMeth(C$, 'negated', function () {
return this.times$F(-1);
});

Clazz.newMeth(C$, 'v$F$F', function (x, y) {
return Clazz.new_(C$.c$$F$F,[x, y]);
}, 1);
})();
//Created 2017-12-22 22:33:02
