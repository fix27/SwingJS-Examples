(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.event"),I$=[];
var C$=Clazz.newClass(P$, "VoidNotifier", null, 'edu.colorado.phet.common.phetcommon.model.event.ValueNotifier');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$$TT.apply(this, [null]);
C$.$init$.apply(this);
}, 1);
})();
//Created 2017-12-22 22:33:03
