(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.clock"),I$=[['java.util.ArrayList','edu.colorado.phet.common.phetcommon.model.clock.ClockAdapter','edu.colorado.phet.common.phetcommon.model.clock.ClockEvent']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Clock", null, null, 'edu.colorado.phet.common.phetcommon.model.clock.IClock');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.listeners = null;
this.timingStrategy = null;
this.lastSimulationTime = 0;
this.simulationTime = 0;
this.lastWallTime = 0;
this.wallTime = 0;
this.firstPanel = 0;
this.firstModule = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.listeners = Clazz.new_((I$[1]||$incl$(1)));
this.lastSimulationTime = 0.0;
this.simulationTime = 0.0;
this.lastWallTime = 0;
this.wallTime = 0;
this.firstPanel = -1;
this.firstModule = -1;
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_model_clock_TimingStrategy', function (timingStrategy) {
C$.$init$.apply(this);
this.timingStrategy = timingStrategy;
}, 1);

Clazz.newMeth(C$, 'addClockListener$edu_colorado_phet_common_phetcommon_model_clock_ClockListener', function (clockListener) {
var pt = this.listeners.size();
if (Clazz.instanceOf(clockListener, "edu.colorado.phet.common.phetcommon.model.clock.ApparatusPanelClockListener")) {
if (this.firstPanel < 0) this.firstPanel = pt;
 else pt = this.firstPanel;
} else if (Clazz.instanceOf(clockListener, "edu.colorado.phet.common.phetcommon.model.clock.ModuleClockListener")) {
if (this.firstModule < 0) this.firstModule = pt;
 else pt = this.firstModule;
} else if (this.firstModule > 0 && this.firstPanel > 0 ) {
pt = Math.min(this.firstModule++, this.firstPanel++);
} else if (this.firstModule > 0) {
pt = this.firstModule++;
} else if (this.firstPanel > 0) {
pt = this.firstPanel++;
}this.listeners.add$I$TE(pt, clockListener);
});

Clazz.newMeth(C$, 'removeClockListener$edu_colorado_phet_common_phetcommon_model_clock_ClockListener', function (clockListener) {
this.listeners.remove$O(clockListener);
});

Clazz.newMeth(C$, 'addSimulationTimeChangeListener$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1', function (listener) {
this.addClockListener$edu_colorado_phet_common_phetcommon_model_clock_ClockListener(((
(function(){var C$=Clazz.newClass(P$, "Clock$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('edu.colorado.phet.common.phetcommon.model.clock.ClockAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'simulationTimeChanged$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
this.$finals.listener.$apply$TT(new Double(clockEvent.getSimulationTimeChange()));
});
})()
), Clazz.new_((I$[2]||$incl$(2)), [this, {listener: listener}],P$.Clock$1)));
});

Clazz.newMeth(C$, 'resetSimulationTime', function () {
this.setSimulationTime$D(0.0);
this.notifySimulationTimeReset();
p$.testNotifySimulationTimeChange.apply(this, []);
});

Clazz.newMeth(C$, 'tick$D', function (simulationTimeChange) {
this.lastWallTime = this.wallTime;
this.wallTime = System.currentTimeMillis();
var t = (this.wallTime - this.lastWallTime);
{
document.title = t;
}p$.setSimulationTimeNoUpdate$D.apply(this, [this.simulationTime + simulationTimeChange]);
this.notifyClockTicked();
p$.testNotifySimulationTimeChange.apply(this, []);
});

Clazz.newMeth(C$, 'doTick', function () {
this.tick$D(this.timingStrategy.getSimulationTimeChangeWT$J$J(this.lastWallTime, this.wallTime));
});

Clazz.newMeth(C$, 'stepClockWhilePaused', function () {
this.tick$D(this.timingStrategy.getSimulationTimeChangeForPausedClock());
});

Clazz.newMeth(C$, 'stepClockBackWhilePaused', function () {
this.tick$D(-this.timingStrategy.getSimulationTimeChangeForPausedClock());
});

Clazz.newMeth(C$, 'setSimulationTimeNoUpdate$D', function (simulationTime) {
this.lastSimulationTime = this.simulationTime;
this.simulationTime = simulationTime;
});

Clazz.newMeth(C$, 'getWallTimeChange', function () {
return this.wallTime - this.lastWallTime;
});

Clazz.newMeth(C$, 'getSimulationTimeChange', function () {
return this.simulationTime - this.lastSimulationTime;
});

Clazz.newMeth(C$, 'getSimulationTime', function () {
return this.simulationTime;
});

Clazz.newMeth(C$, 'getWallTime', function () {
return this.wallTime;
});

Clazz.newMeth(C$, 'setSimulationTime$D', function (simulationTime) {
p$.setSimulationTimeNoUpdate$D.apply(this, [simulationTime]);
p$.testNotifySimulationTimeChange.apply(this, []);
});

Clazz.newMeth(C$, 'getTimingStrategy', function () {
return this.timingStrategy;
});

Clazz.newMeth(C$, 'setTimingStrategy$edu_colorado_phet_common_phetcommon_model_clock_TimingStrategy', function (timingStrategy) {
this.timingStrategy = timingStrategy;
});

Clazz.newMeth(C$, 'notifyClockTicked', function () {
var clockEvent = Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[this]);
for (var i = 0, n = this.listeners.size(); i < n; i++) {
var clockListener = this.listeners.get$I(i);
clockListener.clockTicked$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(clockEvent);
}
});

Clazz.newMeth(C$, 'notifyClockPaused', function () {
var clockEvent = Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[this]);
for (var i = 0; i < this.listeners.size(); i++) {
var clockListener = this.listeners.get$I(i);
clockListener.clockPaused$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(clockEvent);
}
});

Clazz.newMeth(C$, 'notifyClockStarted', function () {
var clockEvent = Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[this]);
for (var i = 0; i < this.listeners.size(); i++) {
var clockListener = this.listeners.get$I(i);
clockListener.clockStarted$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(clockEvent);
}
});

Clazz.newMeth(C$, 'notifySimulationTimeReset', function () {
var clockEvent = Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[this]);
for (var i = 0; i < this.listeners.size(); i++) {
var clockListener = this.listeners.get$I(i);
clockListener.simulationTimeReset$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(clockEvent);
}
});

Clazz.newMeth(C$, 'testNotifySimulationTimeChange', function () {
if (this.getSimulationTimeChange() != 0.0 ) {
this.notifySimulationTimeChanged();
}});

Clazz.newMeth(C$, 'notifySimulationTimeChanged', function () {
var clockEvent = Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[this]);
for (var i = 0; i < this.listeners.size(); i++) {
var clockListener = this.listeners.get$I(i);
clockListener.simulationTimeChanged$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(clockEvent);
}
});

Clazz.newMeth(C$, 'stop', function () {
this.pause();
});

Clazz.newMeth(C$, 'containsClockListener$edu_colorado_phet_common_phetcommon_model_clock_ClockListener', function (clockListener) {
return this.listeners.contains$O(clockListener);
});

Clazz.newMeth(C$, 'removeAllClockListeners', function () {
this.listeners.clear();
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:33:02
