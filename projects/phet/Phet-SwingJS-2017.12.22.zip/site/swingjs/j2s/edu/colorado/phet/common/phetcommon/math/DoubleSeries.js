(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[['java.util.ArrayList']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DoubleSeries");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.data = null;
this.maxSize = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.data = Clazz.new_((I$[1]||$incl$(1)));
}, 1);

Clazz.newMeth(C$, 'c$$I', function (maxSize) {
C$.$init$.apply(this);
this.maxSize = maxSize;
}, 1);

Clazz.newMeth(C$, 'add$D', function (value) {
this.data.add$TE( new Double(value));
if (this.data.size() > this.maxSize) {
this.data.remove$I(0);
}});

Clazz.newMeth(C$, 'average', function () {
return p$.sum.apply(this, []) / this.getSampleCount();
});

Clazz.newMeth(C$, 'getSampleCount', function () {
return this.data.size();
});

Clazz.newMeth(C$, 'sum', function () {
var sum = 0;
for (var i = 0; i < this.data.size(); i++) {
sum += (this.data.get$I(i)).doubleValue();
}
return sum;
});

Clazz.newMeth(C$, 'clear', function () {
this.data.clear();
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:32:58
