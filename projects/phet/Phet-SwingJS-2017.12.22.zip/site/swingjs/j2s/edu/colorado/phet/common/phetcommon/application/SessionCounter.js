(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.application"),I$=[['java.io.File','edu.colorado.phet.common.phetcommon.application.PhetPersistenceDir',['edu.colorado.phet.common.phetcommon.application.SessionCounter','.SessionCountsFile']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SessionCounter", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.instance = null;
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.project = null;
this.simulation = null;
this.file = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S$S', function (project, simulation) {
C$.$init$.apply(this);
this.project = project;
this.simulation = simulation;
this.file = Clazz.new_((I$[3]||$incl$(3)));
}, 1);

Clazz.newMeth(C$, 'initInstance$S$S', function (project, simulation) {
if (C$.instance != null ) {
throw Clazz.new_(Clazz.load('java.lang.RuntimeException').c$$S,["SessionCounter is already initialized"]);
} else {
try {
C$.instance = Clazz.new_(C$.c$$S$S,[project, simulation]);
} catch (e) {
if (Clazz.exceptionOf(e, "java.security.AccessControlException")){
C$.instance = null;
System.out.println$S("SessionCounter: cannot create instance, no permissions");
} else {
throw e;
}
}
}return C$.instance;
}, 1);

Clazz.newMeth(C$, 'getInstance', function () {
return C$.instance;
}, 1);

Clazz.newMeth(C$, 'incrementCounts', function () {
this.file.setCount$S$S$I(this.project, this.simulation, this.file.getCount$S$S(this.project, this.simulation) + 1);
this.file.setCountSince$S$S$I(this.project, this.simulation, this.file.getCountSince$S$S(this.project, this.simulation) + 1);
this.file.setTotal$I(this.getTotal() + 1);
});

Clazz.newMeth(C$, 'decrementCounts', function () {
this.file.setCount$S$S$I(this.project, this.simulation, Math.max(0, this.file.getCount$S$S(this.project, this.simulation) - 1));
this.file.setCountSince$S$S$I(this.project, this.simulation, Math.max(0, this.file.getCountSince$S$S(this.project, this.simulation) - 1));
this.file.setTotal$I(Math.max(0, this.getTotal() - 1));
});

Clazz.newMeth(C$, 'resetCountSince', function () {
this.file.setCountSince$S$S$I(this.project, this.simulation, 0);
});

Clazz.newMeth(C$, 'getCount', function () {
return this.file.getCount$S$S(this.project, this.simulation);
});

Clazz.newMeth(C$, 'getTotal', function () {
return this.file.getTotal();
});

Clazz.newMeth(C$, 'getCountSince', function () {
return this.file.getCountSince$S$S(this.project, this.simulation);
});

Clazz.newMeth(C$, 'clear', function () {
if (!this.file.$delete()) {
this.file.deleteOnExit();
}});

Clazz.newMeth(C$, 'main', function (args) {
var s = C$.initInstance$S$S("balloons", "balloons");
System.out.println$S("before increment: count=" + s.getCount() + " since=" + s.getCountSince() );
s.incrementCounts();
System.out.println$S("after increment: count=" + s.getCount() + " since=" + s.getCountSince() );
s.clear();
System.out.println$S("after clear: count=" + s.getCount() + " since=" + s.getCountSince() );
}, 1);
;
(function(){var C$=Clazz.newClass(P$.SessionCounter, "SessionCountsFile", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'edu.colorado.phet.common.phetcommon.util.AbstractPropertiesFile');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getCountKey$S$S', function (project, simulation) {
return project + "." + simulation + ".count" ;
}, 1);

Clazz.newMeth(C$, 'getSinceKey$S$S', function (project, simulation) {
return project + "." + simulation + ".since" ;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$$java_io_File.apply(this, [Clazz.new_((I$[1]||$incl$(1)).c$$java_io_File$S,[Clazz.new_((I$[2]||$incl$(2))), "session-counts.properties"])]);
C$.$init$.apply(this);
this.setHeader$S("DO NOT EDIT! - counts how many times simulations have been run");
}, 1);

Clazz.newMeth(C$, 'setCount$S$S$I', function (project, simulation, count) {
this.setProperty$S$I(C$.getCountKey$S$S(project, simulation), count);
});

Clazz.newMeth(C$, 'getCount$S$S', function (project, simulation) {
return this.getPropertyInt$S$I(C$.getCountKey$S$S(project, simulation), 0);
});

Clazz.newMeth(C$, 'setCountSince$S$S$I', function (project, simulation, count) {
this.setProperty$S$I(C$.getSinceKey$S$S(project, simulation), count);
});

Clazz.newMeth(C$, 'getCountSince$S$S', function (project, simulation) {
return this.getPropertyInt$S$I(C$.getSinceKey$S$S(project, simulation), 0);
});

Clazz.newMeth(C$, 'setTotal$I', function (total) {
this.setProperty$S$I("total.count", total);
});

Clazz.newMeth(C$, 'getTotal', function () {
return this.getPropertyInt$S$I("total.count", 0);
});
})()

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:32:57
