(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[];
var C$=Clazz.newInterface(P$, "Function", function(){
});
;
(function(){var C$=Clazz.newClass(P$.Function, "IdentityFunction", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'edu.colorado.phet.common.phetcommon.math.Function');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'evaluate$D', function (x) {
return x;
});

Clazz.newMeth(C$, 'createInverse', function () {
return this;
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.Function, "PowerFunction", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'edu.colorado.phet.common.phetcommon.math.Function');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.power = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$D', function (power) {
C$.$init$.apply(this);
this.power = power;
}, 1);

Clazz.newMeth(C$, 'evaluate$D', function (x) {
return Math.pow(x, this.power);
});

Clazz.newMeth(C$, 'createInverse', function () {
throw Clazz.new_(Clazz.load('java.lang.RuntimeException').c$$S,["Not yet implemented"]);
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.Function, "ExponentialGrowthFunction", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'edu.colorado.phet.common.phetcommon.math.Function');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.base = 0;
this.multiplier = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$D$D', function (base, multiplier) {
C$.$init$.apply(this);
this.base = base;
this.multiplier = multiplier;
}, 1);

Clazz.newMeth(C$, 'evaluate$D', function (x) {
return this.multiplier * Math.pow(this.base, x);
});

Clazz.newMeth(C$, 'createInverse', function () {
throw Clazz.new_(Clazz.load('java.lang.RuntimeException').c$$S,["Not yet implemented"]);
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.Function, "LinearFunction", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'edu.colorado.phet.common.phetcommon.math.Function');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.minInput = 0;
this.maxInput = 0;
this.minOutput = 0;
this.maxOutput = 0;
this.t1 = 0;
this.scale = 0;
this.t2 = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$D$D', function (offset, scale) {
C$.c$$D$D$D$D.apply(this, [0, 1, offset, offset + scale * 1]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_geom_Point2D$java_awt_geom_Point2D', function (p1, p2) {
C$.c$$D$D$D$D.apply(this, [p1.getX(), p2.getX(), p1.getY(), p2.getY()]);
}, 1);

Clazz.newMeth(C$, 'c$$D$D$D$D', function (minInput, maxInput, minOutput, maxOutput) {
C$.$init$.apply(this);
this.minInput = minInput;
this.maxInput = maxInput;
this.minOutput = minOutput;
this.maxOutput = maxOutput;
this.update();
}, 1);

Clazz.newMeth(C$, 'update', function () {
this.t1 = (-this.minInput);
this.scale = (this.maxOutput - this.minOutput) / (this.maxInput - this.minInput);
this.t2 = this.minOutput;
});

Clazz.newMeth(C$, 'evaluate$D', function (x) {
var output = this.t1 + x;
output = this.scale * output;
output = this.t2 + output;
return output;
});

Clazz.newMeth(C$, 'createInverse', function () {
return Clazz.new_(C$.c$$D$D$D$D,[this.minOutput, this.maxOutput, this.minInput, this.maxInput]);
});

Clazz.newMeth(C$, 'getMinInput', function () {
return this.minInput;
});

Clazz.newMeth(C$, 'getMaxInput', function () {
return this.maxInput;
});

Clazz.newMeth(C$, 'getMinOutput', function () {
return this.minOutput;
});

Clazz.newMeth(C$, 'getMaxOutput', function () {
return this.maxOutput;
});

Clazz.newMeth(C$, 'getInputRange', function () {
return this.maxInput - this.minInput;
});

Clazz.newMeth(C$, 'getOutputRange', function () {
return this.maxOutput - this.minOutput;
});

Clazz.newMeth(C$, 'setInput$D$D', function (minInput, maxInput) {
this.minInput = minInput;
this.maxInput = maxInput;
this.update();
});

Clazz.newMeth(C$, 'setOutput$D$D', function (minOutput, maxOutput) {
this.minOutput = minOutput;
this.maxOutput = maxOutput;
this.update();
});

Clazz.newMeth(C$, 'toString', function () {
return "Linear Function, [" + new Double(this.minInput).toString() + "," + new Double(this.maxInput).toString() + "]->[" + new Double(this.minOutput).toString() + "," + new Double(this.maxOutput).toString() + "]" ;
});

Clazz.newMeth(C$, 'equals$O', function (o) {
if (this === o ) {
return true;
}if (o == null  || this.getClass() !== o.getClass()  ) {
return false;
}var that = o;
if (Double.compare(that.maxInput, this.maxInput) != 0) {
return false;
}if (Double.compare(that.maxOutput, this.maxOutput) != 0) {
return false;
}if (Double.compare(that.minInput, this.minInput) != 0) {
return false;
}if (Double.compare(that.minOutput, this.minOutput) != 0) {
return false;
}if (Double.compare(that.scale, this.scale) != 0) {
return false;
}if (Double.compare(that.t1, this.t1) != 0) {
return false;
}if (Double.compare(that.t2, this.t2) != 0) {
return false;
}return true;
});

Clazz.newMeth(C$, 'hashCode', function () {
var result;
var temp;
temp = this.minInput != 0.0  ? Double.doubleToLongBits(this.minInput) : 0;
result = ((temp ^ (temp >>> 32))|0);
temp = this.maxInput != 0.0  ? Double.doubleToLongBits(this.maxInput) : 0;
result = 31 * result + ((temp ^ (temp >>> 32))|0);
temp = this.minOutput != 0.0  ? Double.doubleToLongBits(this.minOutput) : 0;
result = 31 * result + ((temp ^ (temp >>> 32))|0);
temp = this.maxOutput != 0.0  ? Double.doubleToLongBits(this.maxOutput) : 0;
result = 31 * result + ((temp ^ (temp >>> 32))|0);
temp = this.t1 != 0.0  ? Double.doubleToLongBits(this.t1) : 0;
result = 31 * result + ((temp ^ (temp >>> 32))|0);
temp = this.scale != 0.0  ? Double.doubleToLongBits(this.scale) : 0;
result = 31 * result + ((temp ^ (temp >>> 32))|0);
temp = this.t2 != 0.0  ? Double.doubleToLongBits(this.t2) : 0;
result = 31 * result + ((temp ^ (temp >>> 32))|0);
return result;
});

Clazz.newMeth(C$);
})()
})();
//Created 2017-12-22 22:32:58
