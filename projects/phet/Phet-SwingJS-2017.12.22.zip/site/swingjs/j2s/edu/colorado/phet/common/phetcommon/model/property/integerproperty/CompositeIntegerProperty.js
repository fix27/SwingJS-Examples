(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.property.integerproperty"),I$=[['java.util.ArrayList','java.util.Arrays','edu.colorado.phet.common.phetcommon.model.property.integerproperty.Plus','edu.colorado.phet.common.phetcommon.model.property.ObservableProperty','edu.colorado.phet.common.phetcommon.model.property.integerproperty.DividedBy','edu.colorado.phet.common.phetcommon.model.property.integerproperty.GreaterThan','edu.colorado.phet.common.phetcommon.model.property.integerproperty.Times','edu.colorado.phet.common.phetcommon.model.property.Property','edu.colorado.phet.common.phetcommon.model.property.integerproperty.GreaterThanOrEqualTo','edu.colorado.phet.common.phetcommon.model.property.integerproperty.LessThan','edu.colorado.phet.common.phetcommon.model.property.integerproperty.Max']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "CompositeIntegerProperty", null, 'edu.colorado.phet.common.phetcommon.model.property.CompositeProperty');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_util_function_Function0$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA', function ($function, properties) {
C$.superclazz.c$$edu_colorado_phet_common_phetcommon_util_function_Function0$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA.apply(this, [$function, properties]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'plus$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA', function (b) {
var all = Clazz.new_((I$[1]||$incl$(1)));
all.add$TE(this);
all.addAll$java_util_Collection((I$[2]||$incl$(2)).asList$TTA(b));
return Clazz.new_((I$[3]||$incl$(3)).c$$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA,[all.toArray$TTA(Clazz.array((I$[4]||$incl$(4)), [0]))]);
});

Clazz.newMeth(C$, 'dividedBy$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty', function (volume) {
return Clazz.new_((I$[5]||$incl$(5)).c$$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty,[this, volume]);
});

Clazz.newMeth(C$, 'greaterThan$I', function (value) {
return Clazz.new_((I$[6]||$incl$(6)).c$$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty$I,[this, value]);
});

Clazz.newMeth(C$, 'times$I', function (b) {
return Clazz.new_((I$[7]||$incl$(7)).c$$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty,[this, Clazz.new_((I$[8]||$incl$(8)).c$$TT,[new Integer(b)])]);
});

Clazz.newMeth(C$, 'greaterThanOrEqualTo$I', function (b) {
return Clazz.new_((I$[9]||$incl$(9)).c$$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty$I,[this, b]);
});

Clazz.newMeth(C$, 'lessThan$I', function (b) {
return Clazz.new_((I$[10]||$incl$(10)).c$$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty$I,[this, b]);
});

Clazz.newMeth(C$, 'max$edu_colorado_phet_common_phetcommon_model_property_integerproperty_CompositeIntegerProperty', function (b) {
return Clazz.new_((I$[11]||$incl$(11)).c$$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty,[this, b]);
});
})();
//Created 2017-12-22 22:33:04
