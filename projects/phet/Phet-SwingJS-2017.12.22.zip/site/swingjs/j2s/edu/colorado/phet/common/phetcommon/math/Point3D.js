(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[['edu.colorado.phet.common.phetcommon.view.util.StringUtil']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Point3D", function(){
Clazz.newInstance(this, arguments,0,C$);
});

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'distance$edu_colorado_phet_common_phetcommon_math_Point3D', function (p) {
return C$.distance$D$D$D$D$D$D(this.getX(), this.getY(), this.getZ(), p.getX(), p.getY(), p.getZ());
});

Clazz.newMeth(C$, 'distance$D$D$D', function (x, y, z) {
return C$.distance$D$D$D$D$D$D(this.getX(), this.getY(), this.getZ(), x, y, z);
});

Clazz.newMeth(C$, 'distance$edu_colorado_phet_common_phetcommon_math_Point3D$edu_colorado_phet_common_phetcommon_math_Point3D', function (p1, p2) {
return C$.distance$D$D$D$D$D$D(p1.getX(), p1.getY(), p1.getZ(), p2.getX(), p2.getY(), p2.getZ());
}, 1);

Clazz.newMeth(C$, 'distance$D$D$D$D$D$D', function (x1, y1, z1, x2, y2, z2) {
var dx = x1 - x2;
var dy = y1 - y2;
var dz = z1 - z2;
return Math.sqrt((dx * dx) + (dy * dy) + (dz * dz) );
}, 1);

Clazz.newMeth(C$, 'equals$O', function (obj) {
if (Clazz.instanceOf(obj, "edu.colorado.phet.common.phetcommon.math.Point3D")) {
var p = obj;
return (this.getX() == p.getX() ) && (this.getY() == p.getY() ) && (this.getZ() == p.getZ() )  ;
}return C$.superclazz.prototype.equals$O.apply(this, [obj]);
});

Clazz.newMeth(C$, 'toString', function () {
return ((I$[1]||$incl$(1)).basename$Class(this.getClass()) + "[" + new Double(this.getX()).toString() + "," + new Double(this.getY()).toString() + "," + new Double(this.getZ()).toString() + "]" );
});
;
(function(){var C$=Clazz.newClass(P$.Point3D, "Double", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'edu.colorado.phet.common.phetcommon.math.Point3D');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x = 0;
this.y = 0;
this.z = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$D$D$D.apply(this, [0, 0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_Point3D', function (p) {
C$.c$$D$D$D.apply(this, [p.getX(), p.getY(), p.getZ()]);
}, 1);

Clazz.newMeth(C$, 'c$$D$D$D', function (x, y, z) {
Clazz.super_(C$, this,1);
this.x = x;
this.y = y;
this.z = z;
}, 1);

Clazz.newMeth(C$, 'getX', function () {
return this.x;
});

Clazz.newMeth(C$, 'getY', function () {
return this.y;
});

Clazz.newMeth(C$, 'getZ', function () {
return this.z;
});

Clazz.newMeth(C$, 'setLocation$edu_colorado_phet_common_phetcommon_math_Point3D', function (p) {
this.setLocation$D$D$D(p.getX(), p.getY(), p.getZ());
});

Clazz.newMeth(C$, 'setLocation$D$D$D', function (x, y, z) {
this.x = x;
this.y = y;
this.z = z;
});
})()
})();
//Created 2017-12-22 22:33:00
