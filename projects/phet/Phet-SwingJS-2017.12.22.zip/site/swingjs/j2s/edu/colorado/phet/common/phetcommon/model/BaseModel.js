(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model"),I$=[['edu.colorado.phet.common.phetcommon.model.CommandQueue','java.util.ArrayList']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "BaseModel");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.commandList = null;
this.modelElements = null;
this.nElements = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.commandList = Clazz.new_((I$[1]||$incl$(1)));
this.modelElements = Clazz.new_((I$[2]||$incl$(2)));
}, 1);

Clazz.newMeth(C$, 'addModelElement$edu_colorado_phet_common_phetcommon_model_ModelElement', function (aps) {
this.addModelElementBM$edu_colorado_phet_common_phetcommon_model_ModelElement(aps);
});

Clazz.newMeth(C$, 'addModelElementBM$edu_colorado_phet_common_phetcommon_model_ModelElement', function (aps) {
this.modelElements.add$TE(aps);
this.nElements++;
});

Clazz.newMeth(C$, 'modelElementAt$I', function (i) {
return this.modelElements.get$I(i);
});

Clazz.newMeth(C$, 'containsModelElement$edu_colorado_phet_common_phetcommon_model_ModelElement', function (modelElement) {
return this.modelElements.contains$O(modelElement);
});

Clazz.newMeth(C$, 'numModelElements', function () {
return this.nElements;
});

Clazz.newMeth(C$, 'removeModelElement$edu_colorado_phet_common_phetcommon_model_ModelElement', function (m) {
this.removeModelElementBM$edu_colorado_phet_common_phetcommon_model_ModelElement(m);
});

Clazz.newMeth(C$, 'removeModelElementBM$edu_colorado_phet_common_phetcommon_model_ModelElement', function (m) {
this.modelElements.remove$O(m);
this.nElements--;
});

Clazz.newMeth(C$, 'removeAllModelElements', function () {
this.modelElements.clear();
this.nElements = 0;
});

Clazz.newMeth(C$, 'execute$edu_colorado_phet_common_phetcommon_model_Command', function (cmd) {
this.commandList.addCommand$edu_colorado_phet_common_phetcommon_model_Command(cmd);
});

Clazz.newMeth(C$, 'update$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (event) {
this.commandList.doIt();
this.stepInTime$D(event.getSimulationTimeChange());
});

Clazz.newMeth(C$, 'stepInTime$D', function (dt) {
for (var i = 0; i < this.nElements; i++) {
this.modelElements.get$I(i).stepInTime$D(dt);
}
});

Clazz.newMeth(C$, 'selectForAny$ClassA', function (modelElementClasses) {
var elements = Clazz.new_((I$[2]||$incl$(2)));
for (var i = 0, nClasses = modelElementClasses.length; i < this.nElements; i++) {
for (var j = 0; j < nClasses; j++) {
var c = modelElementClasses[j];
var element = this.modelElements.get$I(i);
if (c.isAssignableFrom$Class(element.getClass())) {
elements.add$TE(element);
}}
}
return elements;
});

Clazz.newMeth(C$, 'selectFor$Class', function (modelElementClass) {
var elements = Clazz.new_((I$[2]||$incl$(2)).c$$I,[this.modelElements.size()]);
C$.selectFor$java_util_List$Class$java_util_List(this.modelElements, modelElementClass, elements);
return elements;
});

Clazz.newMeth(C$, 'selectFor$ClassA', function (classes) {
var elements = Clazz.new_((I$[2]||$incl$(2)).c$$I,[this.modelElements.size()]);
for (var i = 0; i < classes.length; i++) {
var c = classes[i];
C$.selectFor$java_util_List$Class$java_util_List(this.modelElements, c, elements);
}
return elements;
});

Clazz.newMeth(C$, 'selectFor$java_util_List$Class$java_util_List', function (modelElements, modelElementClass, elements) {
for (var i = modelElements.size(); --i >= 0; ) {
var element = modelElements.get$I(i);
if (modelElementClass.isAssignableFrom$Class(element.getClass())) {
elements.add$TE(element);
}}
}, 1);

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:33:02
