(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.application"),I$=[];
var C$=Clazz.newInterface(P$, "ApplicationConstructor");
})();
//Created 2017-12-22 22:32:30
