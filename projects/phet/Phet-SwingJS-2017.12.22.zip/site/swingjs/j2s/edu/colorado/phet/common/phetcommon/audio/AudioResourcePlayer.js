(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.audio"),I$=[['edu.colorado.phet.common.phetcommon.resources.PhetCommonResources']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "AudioResourcePlayer");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.simResourceLoader = null;
this.enabled = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_resources_PhetResources$Z', function (simResourceLoader, enabled) {
C$.$init$.apply(this);
this.simResourceLoader = simResourceLoader;
this.enabled = enabled;
}, 1);

Clazz.newMeth(C$, 'isEnabled', function () {
return this.enabled;
});

Clazz.newMeth(C$, 'setEnabled$Z', function (isEnabled) {
this.enabled = isEnabled;
});

Clazz.newMeth(C$, 'playSimAudio$S', function (resourceName) {
if (this.isEnabled()) {
this.simResourceLoader.getAudioClip$S(resourceName).play();
}});

Clazz.newMeth(C$, 'playCommonAudio$S', function (resourceName) {
if (this.isEnabled()) {
(I$[1]||$incl$(1)).getInstance().getAudioClip$S(resourceName).play();
}});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:32:57
