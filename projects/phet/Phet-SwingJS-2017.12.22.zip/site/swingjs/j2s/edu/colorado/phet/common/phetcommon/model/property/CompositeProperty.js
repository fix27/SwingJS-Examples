(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.property"),I$=[['edu.colorado.phet.common.phetcommon.model.property.CompositeProperty$1']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "CompositeProperty", null, 'edu.colorado.phet.common.phetcommon.model.property.ObservableProperty');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.$function = null;
this.observer = null;
this.properties = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_util_function_Function0$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA', function ($function, properties) {
C$.superclazz.c$$TT.apply(this, [$function.$apply()]);
C$.$init$.apply(this);
this.$function = $function;
this.properties = properties;
this.observer = ((
(function(){var C$=Clazz.newClass(P$, "CompositeProperty$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.SimpleObserver', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'update', function () {
this.b$['edu.colorado.phet.common.phetcommon.model.property.CompositeProperty'].notifyIfChanged();
});
})()
), Clazz.new_((I$[1]||$incl$(1)).$init$, [this, null]));
for (var property, $property = 0, $$property = properties; $property < $$property.length && ((property = $$property[$property]) || true); $property++) {
property.addObserver$edu_colorado_phet_common_phetcommon_util_SimpleObserver(this.observer);
}
}, 1);

Clazz.newMeth(C$, 'cleanup', function () {
for (var property, $property = 0, $$property = this.properties; $property < $$property.length && ((property = $$property[$property]) || true); $property++) {
property.removeObserver$edu_colorado_phet_common_phetcommon_util_SimpleObserver(this.observer);
}
});

Clazz.newMeth(C$, 'get', function () {
return this.$function.$apply();
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:33:03
