(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[];
var C$=Clazz.newClass(P$, "Ray2D");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.pos = null;
this.dir = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_Vector2D$edu_colorado_phet_common_phetcommon_math_vector_Vector2D', function (pos, dir) {
C$.$init$.apply(this);
this.pos = pos;
this.dir = dir.magnitude() == 1  ? dir : dir.normalized();
}, 1);

Clazz.newMeth(C$, 'shifted$D', function (distance) {
return Clazz.new_(C$.c$$edu_colorado_phet_common_phetcommon_math_vector_Vector2D$edu_colorado_phet_common_phetcommon_math_vector_Vector2D,[this.pointAtDistance$D(distance), this.dir]);
});

Clazz.newMeth(C$, 'pointAtDistance$D', function (distance) {
return this.pos.plus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D(this.dir.times$D(distance));
});

Clazz.newMeth(C$, 'toString', function () {
return this.pos.toString() + " => " + this.dir.toString() ;
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:33:00
