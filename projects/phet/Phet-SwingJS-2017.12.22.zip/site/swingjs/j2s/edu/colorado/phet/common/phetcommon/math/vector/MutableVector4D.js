(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math.vector"),I$=[];
var C$=Clazz.newClass(P$, "MutableVector4D", null, 'edu.colorado.phet.common.phetcommon.math.vector.AbstractVector4D');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x = 0;
this.y = 0;
this.z = 0;
this.w = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'hashCode', function () {
return Float.floatToIntBits(this.x) ^ Float.floatToIntBits(this.y) ^ Float.floatToIntBits(this.z) ^ Float.floatToIntBits(this.w) ;
});

Clazz.newMeth(C$, 'equals$O', function (o) {
if (!(Clazz.instanceOf(o, "edu.colorado.phet.common.phetcommon.math.vector.MutableVector4D"))) {
return false;
}var m = o;
return (m.x == this.x  && m.y == this.y   && m.z == this.z   && m.w == this.w  );
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector4D', function (v) {
C$.c$$D$D$D$D.apply(this, [v.getX(), v.getY(), v.getZ(), v.getW()]);
}, 1);

Clazz.newMeth(C$, 'c$$D$D$D$D', function (x, y, z, w) {
Clazz.super_(C$, this,1);
this.x = x;
this.y = y;
this.z = z;
this.w = w;
}, 1);

Clazz.newMeth(C$, 'getX', function () {
return this.x;
});

Clazz.newMeth(C$, 'getY', function () {
return this.y;
});

Clazz.newMeth(C$, 'getZ', function () {
return this.z;
});

Clazz.newMeth(C$, 'getW', function () {
return this.w;
});

Clazz.newMeth(C$, 'add$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector4D', function (v) {
this.setX$D(this.getX() + v.getX());
this.setY$D(this.getY() + v.getY());
this.setZ$D(this.getZ() + v.getZ());
this.setW$D(this.getW() + v.getW());
return this;
});

Clazz.newMeth(C$, 'normalize', function () {
var magnitude = this.magnitude();
if (magnitude == 0 ) {
throw Clazz.new_(Clazz.load('java.lang.UnsupportedOperationException').c$$S,["Cannot normalize a zero-magnitude vector."]);
}return this.scale$D(1.0 / magnitude);
});

Clazz.newMeth(C$, 'scale$D', function (scale) {
this.setX$D(this.getX() * scale);
this.setY$D(this.getY() * scale);
this.setZ$D(this.getZ() * scale);
this.setW$D(this.getW() * scale);
return this;
});

Clazz.newMeth(C$, 'negate', function () {
this.setComponents$D$D$D$D(-this.getX(), -this.getY(), -this.getZ(), -this.getW());
return this;
});

Clazz.newMeth(C$, 'setX$D', function (x) {
this.x = x;
});

Clazz.newMeth(C$, 'setY$D', function (y) {
this.y = y;
});

Clazz.newMeth(C$, 'setZ$D', function (z) {
this.z = z;
});

Clazz.newMeth(C$, 'setW$D', function (w) {
this.w = w;
});

Clazz.newMeth(C$, 'setComponents$D$D$D$D', function (x, y, z, w) {
this.setX$D(x);
this.setY$D(y);
this.setY$D(z);
this.setW$D(w);
});

Clazz.newMeth(C$, 'setValue$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector4D', function (value) {
this.setComponents$D$D$D$D(value.getX(), value.getY(), value.getZ(), value.getW());
});

Clazz.newMeth(C$, 'setMagnitude$D', function (magnitude) {
this.normalize();
this.scale$D(magnitude);
});

Clazz.newMeth(C$, 'subtract$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector4D', function (v) {
this.setX$D(this.getX() - v.getX());
this.setY$D(this.getY() - v.getY());
this.setZ$D(this.getZ() - v.getZ());
this.setW$D(this.getW() - v.getW());
return this;
});
})();
//Created 2017-12-22 22:33:01
