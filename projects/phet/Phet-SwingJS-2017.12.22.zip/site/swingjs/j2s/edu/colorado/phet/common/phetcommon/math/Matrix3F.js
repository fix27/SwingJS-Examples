(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[[['edu.colorado.phet.common.phetcommon.math.Matrix3F','.MatrixType'],'edu.colorado.phet.common.phetcommon.math.vector.Vector3F','edu.colorado.phet.common.phetcommon.math.Matrix4F','edu.colorado.phet.common.phetcommon.math.vector.Vector2F']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Matrix3F");
C$.IDENTITY = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.IDENTITY = C$.rowMajor$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix3F_MatrixType(1, 0, 0, 0, 1, 0, 0, 0, 1, (I$[1]||$incl$(1)).IDENTITY);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.v00 = 0;
this.v01 = 0;
this.v02 = 0;
this.v10 = 0;
this.v11 = 0;
this.v12 = 0;
this.v20 = 0;
this.v21 = 0;
this.v22 = 0;
this.type = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'hashCode', function () {
return Float.floatToIntBits(this.v00) ^ Float.floatToIntBits(this.v01) ^ Float.floatToIntBits(this.v02) ^ Float.floatToIntBits(this.v10) ^ Float.floatToIntBits(this.v11) ^ Float.floatToIntBits(this.v12) ^ Float.floatToIntBits(this.v20) ^ Float.floatToIntBits(this.v21) ^ Float.floatToIntBits(this.v22) ;
});

Clazz.newMeth(C$, 'equals$O', function (o) {
if (!(Clazz.instanceOf(o, "edu.colorado.phet.common.phetcommon.math.Matrix3F"))) {
return false;
}var m = o;
return (m.v00 == this.v00  && m.v01 == this.v01   && m.v02 == this.v02   && m.v10 == this.v10   && m.v11 == this.v11   && m.v12 == this.v12   && m.v20 == this.v20   && m.v21 == this.v21   && m.v22 == this.v22  );
});

Clazz.newMeth(C$, 'translation$F$F', function (x, y) {
return C$.rowMajor$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix3F_MatrixType(1, 0, x, 0, 1, y, 0, 0, 1, (I$[1]||$incl$(1)).TRANSLATION_2D);
}, 1);

Clazz.newMeth(C$, 'scaling$F', function (s) {
return C$.scaling$F$F$F(s, s, s);
}, 1);

Clazz.newMeth(C$, 'scaling$F$F$F', function (x, y, z) {
return C$.rowMajor$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix3F_MatrixType(x, 0, 0, 0, y, 0, 0, 0, z, (I$[1]||$incl$(1)).SCALING);
}, 1);

Clazz.newMeth(C$, 'rotation$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$F', function (axis, angle) {
var c = Math.cos(angle);
var s = Math.sin(angle);
var C = 1 - c;
var x = axis.getX();
var y = axis.getY();
var z = axis.getZ();
return C$.rowMajor$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix3F_MatrixType(x * x * C  + c, x * y * C  - z * s, x * z * C  + y * s, y * x * C  + z * s, y * y * C  + c, y * z * C  - x * s, z * x * C  - y * s, z * y * C  + x * s, z * z * C  + c, (I$[1]||$incl$(1)).OTHER);
}, 1);

Clazz.newMeth(C$, 'rotation$edu_colorado_phet_common_phetcommon_math_QuaternionF', function (quaternion) {
return quaternion.toRotationMatrix();
}, 1);

Clazz.newMeth(C$, 'rotationX$F', function (angle) {
var c = Math.cos(angle);
var s = Math.sin(angle);
return C$.rowMajor$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix3F_MatrixType(1, 0, 0, 0, c, -s, 0, s, c, (I$[1]||$incl$(1)).OTHER);
}, 1);

Clazz.newMeth(C$, 'rotationY$F', function (angle) {
var c = Math.cos(angle);
var s = Math.sin(angle);
return C$.rowMajor$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix3F_MatrixType(c, 0, s, 0, 1, 0, -s, 0, c, (I$[1]||$incl$(1)).OTHER);
}, 1);

Clazz.newMeth(C$, 'rotationZ$F', function (angle) {
var c = Math.cos(angle);
var s = Math.sin(angle);
return C$.rowMajor$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix3F_MatrixType(c, -s, 0, s, c, 0, 0, 0, 1, (I$[1]||$incl$(1)).OTHER);
}, 1);

Clazz.newMeth(C$, 'rowMajor$F$F$F$F$F$F$F$F$F', function (v00, v01, v02, v10, v11, v12, v20, v21, v22) {
return C$.rowMajor$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix3F_MatrixType(v00, v01, v02, v10, v11, v12, v20, v21, v22, (I$[1]||$incl$(1)).OTHER);
}, 1);

Clazz.newMeth(C$, 'rowMajor$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix3F_MatrixType', function (v00, v01, v02, v10, v11, v12, v20, v21, v22, type) {
return Clazz.new_(C$.c$$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix3F_MatrixType,[v00, v01, v02, v10, v11, v12, v20, v21, v22, type]);
}, 1);

Clazz.newMeth(C$, 'columnMajor$F$F$F$F$F$F$F$F$F', function (v00, v10, v20, v01, v11, v21, v02, v12, v22) {
return C$.columnMajor$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix3F_MatrixType(v00, v10, v20, v01, v11, v21, v02, v12, v22, (I$[1]||$incl$(1)).OTHER);
}, 1);

Clazz.newMeth(C$, 'columnMajor$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix3F_MatrixType', function (v00, v10, v20, v01, v11, v21, v02, v12, v22, type) {
return Clazz.new_(C$.c$$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix3F_MatrixType,[v00, v01, v02, v10, v11, v12, v20, v21, v22, type]);
}, 1);

Clazz.newMeth(C$, 'rotateAToB$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F', function (a, b) {
var start = a;
var end = b;
var epsilon = 1.0E-4;
var e;
var h;
var f;
var v = start.cross$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(end);
e = start.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(end);
f = (e < 0 ) ? -e : e;
if (f > 1.0 - epsilon ) {
var c1;
var c2;
var c3;
var x = Clazz.new_((I$[2]||$incl$(2)).c$$F$F$F,[(start.x > 0.0 ) ? start.x : -start.x, (start.y > 0.0 ) ? start.y : -start.y, (start.z > 0.0 ) ? start.z : -start.z]);
if (x.x < x.y ) {
if (x.x < x.z ) {
x = (I$[2]||$incl$(2)).X_UNIT;
} else {
x = (I$[2]||$incl$(2)).Z_UNIT;
}} else {
if (x.y < x.z ) {
x = (I$[2]||$incl$(2)).Y_UNIT;
} else {
x = (I$[2]||$incl$(2)).Z_UNIT;
}}var u = x.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(start);
v = x.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(end);
c1 = 2.0 / u.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(u);
c2 = 2.0 / v.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(v);
c3 = c1 * c2 * u.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(v) ;
return C$.IDENTITY.plus$edu_colorado_phet_common_phetcommon_math_Matrix3F(C$.rowMajor$F$F$F$F$F$F$F$F$F(-c1 * u.x * u.x  - c2 * v.x * v.x  + c3 * v.x * u.x , -c1 * u.x * u.y  - c2 * v.x * v.y  + c3 * v.x * u.y , -c1 * u.x * u.z  - c2 * v.x * v.z  + c3 * v.x * u.z , -c1 * u.y * u.x  - c2 * v.y * v.x  + c3 * v.y * u.x , -c1 * u.y * u.y  - c2 * v.y * v.y  + c3 * v.y * u.y , -c1 * u.y * u.z  - c2 * v.y * v.z  + c3 * v.y * u.z , -c1 * u.z * u.x  - c2 * v.z * v.x  + c3 * v.z * u.x , -c1 * u.z * u.y  - c2 * v.z * v.y  + c3 * v.z * u.y , -c1 * u.z * u.z  - c2 * v.z * v.z  + c3 * v.z * u.z ));
} else {
var hvx;
var hvz;
var hvxy;
var hvxz;
var hvyz;
h = 1.0 / (1.0 + e);
hvx = h * v.x;
hvz = h * v.z;
hvxy = hvx * v.y;
hvxz = hvx * v.z;
hvyz = hvz * v.y;
return C$.rowMajor$F$F$F$F$F$F$F$F$F(e + hvx * v.x, hvxy - v.z, hvxz + v.y, hvxy + v.z, e + h * v.y * v.y , hvyz - v.x, hvxz - v.y, hvyz + v.x, e + hvz * v.z);
}}, 1);

Clazz.newMeth(C$, 'c$$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix3F_MatrixType', function (v00, v01, v02, v10, v11, v12, v20, v21, v22, type) {
C$.$init$.apply(this);
this.v00 = v00;
this.v10 = v10;
this.v20 = v20;
this.v01 = v01;
this.v11 = v11;
this.v21 = v21;
this.v02 = v02;
this.v12 = v12;
this.v22 = v22;
this.type = type;
}, 1);

Clazz.newMeth(C$, 'toMatrix4f', function () {
return (I$[3]||$incl$(3)).rowMajor$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F$F(this.v00, this.v01, this.v02, 0, this.v10, this.v11, this.v12, 0, this.v20, this.v21, this.v22, 0, 0, 0, 0, 1);
});

Clazz.newMeth(C$, 'plus$edu_colorado_phet_common_phetcommon_math_Matrix3F', function (m) {
return C$.rowMajor$F$F$F$F$F$F$F$F$F(this.v00 + m.v00, this.v01 + m.v01, this.v02 + m.v02, this.v10 + m.v10, this.v11 + m.v11, this.v12 + m.v12, this.v20 + m.v20, this.v21 + m.v21, this.v22 + m.v22);
});

Clazz.newMeth(C$, 'minus$edu_colorado_phet_common_phetcommon_math_Matrix3F', function (m) {
return C$.rowMajor$F$F$F$F$F$F$F$F$F(this.v00 - m.v00, this.v01 - m.v01, this.v02 - m.v02, this.v10 - m.v10, this.v11 - m.v11, this.v12 - m.v12, this.v20 - m.v20, this.v21 - m.v21, this.v22 - m.v22);
});

Clazz.newMeth(C$, 'times$edu_colorado_phet_common_phetcommon_math_Matrix3F', function (m) {
var type = (I$[1]||$incl$(1)).OTHER;
if (this.type === (I$[1]||$incl$(1)).TRANSLATION_2D  && m.type === (I$[1]||$incl$(1)).TRANSLATION_2D  ) {
type = (I$[1]||$incl$(1)).TRANSLATION_2D;
}if (this.type === (I$[1]||$incl$(1)).SCALING  && m.type === (I$[1]||$incl$(1)).SCALING  ) {
type = (I$[1]||$incl$(1)).SCALING;
}if (this.type === (I$[1]||$incl$(1)).IDENTITY ) {
type = m.type;
}if (m.type === (I$[1]||$incl$(1)).IDENTITY ) {
type = this.type;
}return C$.rowMajor$F$F$F$F$F$F$F$F$F$edu_colorado_phet_common_phetcommon_math_Matrix3F_MatrixType(this.v00 * m.v00 + this.v01 * m.v10 + this.v02 * m.v20, this.v00 * m.v01 + this.v01 * m.v11 + this.v02 * m.v21, this.v00 * m.v02 + this.v01 * m.v12 + this.v02 * m.v22, this.v10 * m.v00 + this.v11 * m.v10 + this.v12 * m.v20, this.v10 * m.v01 + this.v11 * m.v11 + this.v12 * m.v21, this.v10 * m.v02 + this.v11 * m.v12 + this.v12 * m.v22, this.v20 * m.v00 + this.v21 * m.v10 + this.v22 * m.v20, this.v20 * m.v01 + this.v21 * m.v11 + this.v22 * m.v21, this.v20 * m.v02 + this.v21 * m.v12 + this.v22 * m.v22, type);
});

Clazz.newMeth(C$, 'times$edu_colorado_phet_common_phetcommon_math_vector_Vector3F', function (v) {
return Clazz.new_((I$[2]||$incl$(2)).c$$F$F$F,[this.v00 * v.getX() + this.v01 * v.getY() + this.v02 * v.getZ(), this.v10 * v.getX() + this.v11 * v.getY() + this.v12 * v.getZ(), this.v20 * v.getX() + this.v21 * v.getY() + this.v22 * v.getZ()]);
});

Clazz.newMeth(C$, 'timesTranspose$edu_colorado_phet_common_phetcommon_math_vector_Vector3F', function (v) {
return Clazz.new_((I$[2]||$incl$(2)).c$$F$F$F,[this.v00 * v.getX() + this.v10 * v.getY() + this.v20 * v.getZ(), this.v01 * v.getX() + this.v11 * v.getY() + this.v21 * v.getZ(), this.v02 * v.getX() + this.v12 * v.getY() + this.v22 * v.getZ()]);
});

Clazz.newMeth(C$, 'transposed', function () {
return C$.rowMajor$F$F$F$F$F$F$F$F$F(this.v00, this.v10, this.v20, this.v01, this.v11, this.v21, this.v02, this.v12, this.v22);
});

Clazz.newMeth(C$, 'determinant', function () {
return this.v00 * this.v11 * this.v22  + this.v01 * this.v12 * this.v20  + this.v02 * this.v10 * this.v21  - this.v02 * this.v11 * this.v20  - this.v01 * this.v10 * this.v22  - this.v00 * this.v12 * this.v21 ;
});

Clazz.newMeth(C$, 'negated', function () {
return C$.rowMajor$F$F$F$F$F$F$F$F$F(-this.v00, -this.v01, -this.v02, -this.v10, -this.v11, -this.v12, -this.v20, -this.v21, -this.v22);
});

Clazz.newMeth(C$, 'inverted', function () {
var determinant = this.determinant();
if (determinant != 0 ) {
return C$.rowMajor$F$F$F$F$F$F$F$F$F((-this.v12 * this.v21 + this.v11 * this.v22) / determinant, (this.v02 * this.v21 - this.v01 * this.v22) / determinant, (-this.v02 * this.v11 + this.v01 * this.v12) / determinant, (this.v12 * this.v20 - this.v10 * this.v22) / determinant, (-this.v02 * this.v20 + this.v00 * this.v22) / determinant, (this.v02 * this.v10 - this.v00 * this.v12) / determinant, (-this.v11 * this.v20 + this.v10 * this.v21) / determinant, (this.v01 * this.v20 - this.v00 * this.v21) / determinant, (-this.v01 * this.v10 + this.v00 * this.v11) / determinant);
} else {
throw Clazz.new_(Clazz.load('java.lang.RuntimeException').c$$S,["Matrix could not be inverted"]);
}});

Clazz.newMeth(C$, 'writeToBuffer$java_nio_FloatBuffer', function (buf) {
buf.rewind();
buf.put$FA(Clazz.array(Float.TYPE, -1, [this.v00, this.v10, this.v20, 0, this.v01, this.v11, this.v21, 0, this.v02, this.v12, this.v22, 0, 0, 0, 0, 1]));
});

Clazz.newMeth(C$, 'writeTransposeToBuffer$java_nio_FloatBuffer', function (buf) {
buf.rewind();
buf.put$FA(Clazz.array(Float.TYPE, -1, [this.v00, this.v01, this.v02, 0, this.v10, this.v11, this.v12, 0, this.v20, this.v21, this.v22, 0, 0, 0, 0, 1]));
});

Clazz.newMeth(C$, 'toString', function () {
return edu.colorado.phet.common.phetcommon.util.FunctionalUtils.mkString$java_util_Collection$S(java.util.Arrays.asList$TTA([edu.colorado.phet.common.phetcommon.util.FunctionalUtils.mkString$java_util_Collection$S(java.util.Arrays.asList$TTA([new Float(this.v00), new Float(this.v01), new Float(this.v02)]), " "), edu.colorado.phet.common.phetcommon.util.FunctionalUtils.mkString$java_util_Collection$S(java.util.Arrays.asList$TTA([new Float(this.v10), new Float(this.v11), new Float(this.v12)]), " "), edu.colorado.phet.common.phetcommon.util.FunctionalUtils.mkString$java_util_Collection$S(java.util.Arrays.asList$TTA([new Float(this.v20), new Float(this.v21), new Float(this.v22)]), " ")]), "\u000a");
});

Clazz.newMeth(C$, 'getTranslation', function () {
return Clazz.new_((I$[4]||$incl$(4)).c$$F$F,[this.v02, this.v12]);
});

Clazz.newMeth(C$, 'getScaling', function () {
return Clazz.new_((I$[2]||$incl$(2)).c$$F$F$F,[this.v00, this.v11, this.v22]);
});

Clazz.newMeth(C$, 'equalsWithEpsilon$edu_colorado_phet_common_phetcommon_math_Matrix3F$F', function (m, epsilon) {
return Math.abs(this.v00 - m.v00) < epsilon  && Math.abs(this.v01 - m.v01) < epsilon   && Math.abs(this.v02 - m.v02) < epsilon   && Math.abs(this.v10 - m.v10) < epsilon   && Math.abs(this.v11 - m.v11) < epsilon   && Math.abs(this.v12 - m.v12) < epsilon   && Math.abs(this.v20 - m.v20) < epsilon   && Math.abs(this.v21 - m.v21) < epsilon   && Math.abs(this.v22 - m.v22) < epsilon  ;
});
;
(function(){var C$=Clazz.newClass(P$.Matrix3F, "MatrixType", null, 'Enum');

C$.$clinit$ = function() {Clazz.load(C$, 1);
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "IDENTITY", 0, []);
Clazz.newEnumConst($vals, C$.c$, "TRANSLATION_2D", 1, []);
Clazz.newEnumConst($vals, C$.c$, "SCALING", 2, []);
Clazz.newEnumConst($vals, C$.c$, "OTHER", 3, []);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values', function() { return $vals }, 1);
})()

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:32:59
