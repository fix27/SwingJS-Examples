(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.dialogs"),I$=[['javax.swing.JColorChooser','javax.swing.colorchooser.AbstractColorChooserPanel','edu.colorado.phet.common.phetcommon.dialogs.ColorChooserFactory$1','edu.colorado.phet.common.phetcommon.dialogs.ColorChooserFactory$2','edu.colorado.phet.common.phetcommon.dialogs.ColorChooserFactory$3','edu.colorado.phet.common.phetcommon.view.util.SwingUtils']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ColorChooserFactory", function(){
Clazz.newInstance(this, arguments,0,C$);
});
var p$=C$.prototype;

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'createDialog$S$java_awt_Component$java_awt_Color$edu_colorado_phet_common_phetcommon_dialogs_ColorChooserFactory_Listener', function (title, parent, initialColor, listener) {
return C$.createDialog$S$java_awt_Component$java_awt_Color$edu_colorado_phet_common_phetcommon_dialogs_ColorChooserFactory_Listener$SA(title, parent, initialColor, listener, null);
}, 1);

Clazz.newMeth(C$, 'createDialog$S$java_awt_Component$java_awt_Color$edu_colorado_phet_common_phetcommon_dialogs_ColorChooserFactory_Listener$SA', function (title, parent, initialColor, listener, panelOrder) {
var jcc = Clazz.new_((I$[1]||$incl$(1)).c$$java_awt_Color,[initialColor]);
if (panelOrder != null ) {
var newPanels = Clazz.array((I$[2]||$incl$(2)), [panelOrder.length]);
for (var i = 0; i < newPanels.length; i++) {
newPanels[i] = C$.findPanel$javax_swing_JColorChooser$S(jcc, panelOrder[i]);
}
jcc.setChooserPanels$javax_swing_colorchooser_AbstractColorChooserPanelA(newPanels);
}jcc.getSelectionModel().addChangeListener$javax_swing_event_ChangeListener(((
(function(){var C$=Clazz.newClass(P$, "ColorChooserFactory$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'javax.swing.event.ChangeListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'stateChanged$javax_swing_event_ChangeEvent', function (e) {
this.$finals.listener.colorChanged$java_awt_Color(this.$finals.jcc.getColor());
});
})()
), Clazz.new_((I$[3]||$incl$(3)).$init$, [this, {listener: listener, jcc: jcc}])));
var dialog = (I$[1]||$incl$(1)).createDialog$java_awt_Component$S$Z$javax_swing_JColorChooser$java_awt_event_ActionListener$java_awt_event_ActionListener(parent, title, false, jcc, ((
(function(){var C$=Clazz.newClass(P$, "ColorChooserFactory$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.$finals.listener.ok$java_awt_Color(this.$finals.jcc.getColor());
});
})()
), Clazz.new_((I$[4]||$incl$(4)).$init$, [this, {listener: listener, jcc: jcc}])), ((
(function(){var C$=Clazz.newClass(P$, "ColorChooserFactory$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.$finals.listener.cancelled$java_awt_Color(this.$finals.initialColor);
});
})()
), Clazz.new_((I$[5]||$incl$(5)).$init$, [this, {listener: listener, initialColor: initialColor}])));
(I$[6]||$incl$(6)).centerDialogInParent$javax_swing_JDialog(dialog);
if (parent == null ) {
(I$[6]||$incl$(6)).centerWindowOnScreen$java_awt_Window(dialog);
}return dialog;
}, 1);

Clazz.newMeth(C$, 'showDialog$S$java_awt_Component$java_awt_Color$edu_colorado_phet_common_phetcommon_dialogs_ColorChooserFactory_Listener', function (title, parent, initialColor, listener) {
C$.showDialog$S$java_awt_Component$java_awt_Color$edu_colorado_phet_common_phetcommon_dialogs_ColorChooserFactory_Listener$Z(title, parent, initialColor, listener, false);
}, 1);

Clazz.newMeth(C$, 'showDialog$S$java_awt_Component$java_awt_Color$edu_colorado_phet_common_phetcommon_dialogs_ColorChooserFactory_Listener$Z', function (title, parent, initialColor, listener, hsbFirst) {
var dialog = C$.createDialog$S$java_awt_Component$java_awt_Color$edu_colorado_phet_common_phetcommon_dialogs_ColorChooserFactory_Listener$SA(title, parent, initialColor, listener, hsbFirst ? C$.getHSBFirstPanelOrder() : null);
dialog.show();
}, 1);

Clazz.newMeth(C$, 'getHSBFirstPanelOrder', function () {
return Clazz.array(java.lang.String, -1, ["javax.swing.colorchooser.DefaultHSBChooserPanel", "javax.swing.colorchooser.DefaultRGBChooserPanel", "javax.swing.colorchooser.DefaultSwatchChooserPanel"]);
}, 1);

Clazz.newMeth(C$, 'findPanel$javax_swing_JColorChooser$S', function (chooser, name) {
var panels = chooser.getChooserPanels();
for (var i = 0; i < panels.length; i++) {
var clsName = panels[i].getClass().getName();
if (clsName.equals$O(name)) {
return panels[i];
}}
return null;
}, 1);
;
(function(){var C$=Clazz.newInterface(P$.ColorChooserFactory, "Listener", function(){
});
})()
})();
//Created 2017-12-22 22:32:57
