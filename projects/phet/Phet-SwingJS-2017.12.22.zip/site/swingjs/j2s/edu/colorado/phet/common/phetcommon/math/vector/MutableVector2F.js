(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math.vector"),I$=[['edu.colorado.phet.common.phetcommon.math.vector.Vector2D']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "MutableVector2F", null, 'edu.colorado.phet.common.phetcommon.math.vector.AbstractVector2F');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x = 0;
this.y = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'hashCode', function () {
return Float.floatToIntBits(this.x) ^ Float.floatToIntBits(this.y);
});

Clazz.newMeth(C$, 'equals$O', function (o) {
if (!(Clazz.instanceOf(o, "edu.colorado.phet.common.phetcommon.math.vector.MutableVector2F"))) {
return false;
}var m = o;
return (m.x == this.x  && m.y == this.y  );
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2F', function (v) {
C$.c$$F$F.apply(this, [v.getX(), v.getY()]);
}, 1);

Clazz.newMeth(C$, 'c$$F$F', function (x, y) {
Clazz.super_(C$, this,1);
this.x = x;
this.y = y;
}, 1);

Clazz.newMeth(C$, 'add$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2F', function (v) {
this.setX$F(this.getX() + v.getX());
this.setY$F(this.getY() + v.getY());
return this;
});

Clazz.newMeth(C$, 'normalize', function () {
var magnitude = this.magnitude();
if (magnitude == 0 ) {
throw Clazz.new_(Clazz.load('java.lang.UnsupportedOperationException').c$$S,["Cannot normalize a zero-magnitude vector."]);
}return this.scale$F(1.0 / magnitude);
});

Clazz.newMeth(C$, 'scale$F', function (scale) {
this.setX$F(this.getX() * scale);
this.setY$F(this.getY() * scale);
return this;
});

Clazz.newMeth(C$, 'setX$F', function (x) {
this.x = x;
});

Clazz.newMeth(C$, 'setY$F', function (y) {
this.y = y;
});

Clazz.newMeth(C$, 'setComponents$F$F', function (x, y) {
this.setX$F(x);
this.setY$F(y);
});

Clazz.newMeth(C$, 'setValue$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2F', function (value) {
this.setComponents$F$F(value.getX(), value.getY());
});

Clazz.newMeth(C$, 'setMagnitudeAndAngle$F$F', function (magnitude, angle) {
this.setComponents$F$F(Math.cos(angle) * magnitude, Math.sin(angle) * magnitude);
});

Clazz.newMeth(C$, 'setMagnitude$F', function (magnitude) {
this.setMagnitudeAndAngle$F$F(magnitude, this.getAngle());
});

Clazz.newMeth(C$, 'setAngle$F', function (angle) {
this.setMagnitudeAndAngle$F$F(this.magnitude(), angle);
});

Clazz.newMeth(C$, 'subtract$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2F', function (v) {
this.setX$F(this.getX() - v.getX());
this.setY$F(this.getY() - v.getY());
return this;
});

Clazz.newMeth(C$, 'rotate$F', function (theta) {
var r = this.magnitude();
var alpha = this.getAngle();
var gamma = alpha + theta;
var xPrime = (r * Math.cos(gamma));
var yPrime = (r * Math.sin(gamma));
this.setComponents$F$F(xPrime, yPrime);
return this;
});

Clazz.newMeth(C$, 'negate', function () {
this.setComponents$F$F(-this.getX(), -this.getY());
return this;
});

Clazz.newMeth(C$, 'getY', function () {
return this.y;
});

Clazz.newMeth(C$, 'getX', function () {
return this.x;
});

Clazz.newMeth(C$, 'createPolar$F$F', function (magnitude, angle) {
return (I$[1]||$incl$(1)).createPolar$D$D(magnitude, angle);
}, 1);
})();
//Created 2017-12-22 22:33:01
