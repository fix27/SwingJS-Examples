(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.model.clock"),I$=[];
var C$=Clazz.newClass(P$, "ClockAdapter", null, null, 'edu.colorado.phet.common.phetcommon.model.clock.ClockListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'clockTicked$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
});

Clazz.newMeth(C$, 'clockStarted$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
});

Clazz.newMeth(C$, 'clockPaused$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
});

Clazz.newMeth(C$, 'simulationTimeChanged$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
});

Clazz.newMeth(C$, 'simulationTimeReset$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:33:02
