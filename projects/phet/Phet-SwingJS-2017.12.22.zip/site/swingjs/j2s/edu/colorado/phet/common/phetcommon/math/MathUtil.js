(function(){var P$=Clazz.newPackage("edu.colorado.phet.common.phetcommon.math"),I$=[['java.util.Random',['java.awt.geom.Point2D','.Double'],['java.awt.geom.Point2D','.Float'],'edu.colorado.phet.common.phetcommon.math.vector.MutableVector2D','java.awt.geom.Point2D','java.awt.geom.AffineTransform']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "MathUtil", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.random = null;
C$.SQRT_2 = 0;
C$.tempTx = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.random = Clazz.new_((I$[1]||$incl$(1)).c$$J,[System.currentTimeMillis()]);
C$.SQRT_2 = Math.sqrt(2);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'nextRandomSign', function () {
return C$.random.nextBoolean() ? 1 : -1;
}, 1);

Clazz.newMeth(C$, 'logBaseX$D$D', function (number, base) {
return Math.log(number) / Math.log(base);
}, 1);

Clazz.newMeth(C$, 'log10$D', function (number) {
return C$.logBaseX$D$D(number, 10);
}, 1);

Clazz.newMeth(C$, 'getSign$D', function (d) {
if (d != 0  && !Double.isNaN(d)  && !Double.isInfinite(d) ) {
return ((Math.abs(d) / d)|0);
} else {
return 1;
}}, 1);

Clazz.newMeth(C$, 'getSign$F', function (f) {
if (f != 0  && !Float.isNaN(f)  && !Float.isInfinite(f) ) {
return ((Math.abs(f) / f)|0);
} else {
return 1;
}}, 1);

Clazz.newMeth(C$, 'getSign$I', function (i) {
return i >= 0 ? 1 : -1;
}, 1);

Clazz.newMeth(C$, 'quadraticRoots$DA$D$D$D', function (quadRoots, a, b, c) {
var sqrt = Math.sqrt((b * b) - 4 * a * c );
quadRoots[0] = (-b + sqrt) / (2 * a);
quadRoots[1] = (-b - sqrt) / (2 * a);
return quadRoots;
}, 1);

Clazz.newMeth(C$, 'quadraticRoots$D$D$D', function (a, b, c) {
var roots = Clazz.array(Double.TYPE, [2]);
return C$.quadraticRoots$DA$D$D$D(roots, a, b, c);
}, 1);

Clazz.newMeth(C$, 'quadraticRoots$FA$F$F$F', function (quadRoots, a, b, c) {
var sqrt = Math.sqrt((b * b) - 4 * a * c );
quadRoots[0] = (-b + sqrt) / (2 * a);
quadRoots[1] = (-b - sqrt) / (2 * a);
return quadRoots;
}, 1);

Clazz.newMeth(C$, 'quadraticRoots$F$F$F', function (a, b, c) {
var roots = Clazz.array(Float.TYPE, [2]);
return C$.quadraticRoots$FA$F$F$F(roots, a, b, c);
}, 1);

Clazz.newMeth(C$, 'isApproxEqual$F$F$F', function (x, y, eps) {
return Math.abs(x - y) < eps ;
}, 1);

Clazz.newMeth(C$, 'isApproxEqual$java_awt_geom_Point2D$java_awt_geom_Point2D$D', function (p1, p2, eps) {
return C$.isApproxEqual$D$D$D(p1.getX(), p2.getX(), eps) && C$.isApproxEqual$D$D$D(p1.getY(), p2.getY(), eps) ;
}, 1);

Clazz.newMeth(C$, 'isApproxEqual$D$D$D', function (x, y, eps) {
return Math.abs(x - y) < eps ;
}, 1);

Clazz.newMeth(C$, 'reflectPointAcrossLine$java_awt_geom_Point2D$java_awt_geom_Point2D$D', function (p, ptOnLine, lineAngle) {
var alpha = lineAngle % 6.283185307179586;
var gamma = Math.atan2((p.getY() - ptOnLine.getY()), (p.getX() - ptOnLine.getX())) % 6.283185307179586;
var theta = (2 * alpha - gamma) % 6.283185307179586;
var d = C$.getDistance$java_awt_geom_Point2D$java_awt_geom_Point2D(p, ptOnLine);
return Clazz.new_((I$[2]||$incl$(2)).c$$D$D,[ptOnLine.getX() + d * Math.cos(theta), ptOnLine.getY() + d * Math.sin(theta)]);
}, 1);

Clazz.newMeth(C$, 'getDistance$java_awt_geom_Point2D$java_awt_geom_Point2D', function (p1, p2) {
var dx = (p2).x - (p1).x;
var dy = (p2).y - (p1).y;
return Math.sqrt(dx * dx + dy * dy);
}, 1);

Clazz.newMeth(C$, 'getDistanceSq$java_awt_geom_Point2D_Double$java_awt_geom_Point2D_Double', function (p1, p2) {
var dx = p2.x - p1.x;
var dy = p2.y - p1.y;
return dx * dx + dy * dy;
}, 1);

Clazz.newMeth(C$, 'reflectPointAcrossLinePt$java_awt_geom_Point2D_Double$java_awt_geom_Point2D_Double$D$java_awt_geom_Point2D_Double', function (p, ptOnLine, lineAngle, ret) {
var alpha = lineAngle % 6.283185307179586;
var gamma = Math.atan2((p.getY() - ptOnLine.getY()), (p.getX() - ptOnLine.getX())) % 6.283185307179586;
var theta = (2 * alpha - gamma) % 6.283185307179586;
var d = C$.getDistance$java_awt_geom_Point2D$java_awt_geom_Point2D(p, ptOnLine);
ret.x = ptOnLine.getX() + d * Math.cos(theta);
ret.y = ptOnLine.getY() + d * Math.sin(theta);
}, 1);

Clazz.newMeth(C$, 'getLineSegmentsIntersection$java_awt_geom_Line2D$java_awt_geom_Line2D', function (l1, l2) {
return C$.getLineSegmentsIntersection$java_awt_geom_Point2D$java_awt_geom_Point2D$java_awt_geom_Point2D$java_awt_geom_Point2D(l1.getP1(), l1.getP2(), l2.getP1(), l2.getP2());
}, 1);

Clazz.newMeth(C$, 'getLineSegmentsIntersection$java_awt_geom_Point2D$java_awt_geom_Point2D$java_awt_geom_Point2D$java_awt_geom_Point2D', function (p1, p2, p3, p4) {
var result = Clazz.new_((I$[2]||$incl$(2)));
var x1 = p1.getX();
var y1 = p1.getY();
var x2 = p2.getX();
var y2 = p2.getY();
var x3 = p3.getX();
var y3 = p3.getY();
var x4 = p4.getX();
var y4 = p4.getY();
var numA = (x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3);
var numB = (x2 - x1) * (y1 - y3) - (y2 - y1) * (x1 - x3);
var denom = (y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1);
if (denom == 0 ) {
result.x = NaN;
result.y = NaN;
} else {
var ua = numA / denom;
var ub = numB / denom;
if (!(ua >= 0  && ua <= 1   && ub >= 0   && ub <= 1  )) {
result.x = NaN;
result.y = NaN;
} else {
result.x = x1 + ua * (x2 - x1);
result.y = y1 + ua * (y2 - y1);
}}return result;
}, 1);

Clazz.newMeth(C$, 'getSegmentLineIntersection$java_awt_geom_Point2D$java_awt_geom_Point2D$java_awt_geom_Point2D$java_awt_geom_Point2D', function (p1, p2, p3, p4) {
var result = Clazz.new_((I$[2]||$incl$(2)));
var x1 = p1.getX();
var y1 = p1.getY();
var x2 = p2.getX();
var y2 = p2.getY();
var x3 = p3.getX();
var y3 = p3.getY();
var x4 = p4.getX();
var y4 = p4.getY();
var numA = (x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3);
var numB = (x2 - x1) * (y1 - y3) - (y2 - y1) * (x1 - x3);
var denom = (y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1);
if (denom == 0 ) {
result.x = NaN;
result.y = NaN;
} else {
var ua = numA / denom;
var ub = numB / denom;
if (!(ub >= 0  && ub <= 1  )) {
result.x = NaN;
result.y = NaN;
} else {
result.x = x1 + ua * (x2 - x1);
result.y = y1 + ua * (y2 - y1);
}}return result;
}, 1);

Clazz.newMeth(C$, 'getLinesIntersection$java_awt_geom_Line2D$java_awt_geom_Line2D', function (l1, l2) {
return C$.getLinesIntersection$java_awt_geom_Point2D$java_awt_geom_Point2D$java_awt_geom_Point2D$java_awt_geom_Point2D(l1.getP1(), l1.getP2(), l2.getP1(), l2.getP2());
}, 1);

Clazz.newMeth(C$, 'getLinesIntersection$java_awt_geom_Point2D$java_awt_geom_Point2D$java_awt_geom_Point2D$java_awt_geom_Point2D', function (p1, p2, p3, p4) {
var result = Clazz.new_((I$[2]||$incl$(2)));
var x1 = p1.getX();
var y1 = p1.getY();
var x2 = p2.getX();
var y2 = p2.getY();
var x3 = p3.getX();
var y3 = p3.getY();
var x4 = p4.getX();
var y4 = p4.getY();
var numA = (x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3);
var denom = (y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1);
if (denom == 0 ) {
result.x = NaN;
result.y = NaN;
} else {
var ua = numA / denom;
result.x = x1 + ua * (x2 - x1);
result.y = y1 + ua * (y2 - y1);
}return result;
}, 1);

Clazz.newMeth(C$, 'segmentsIntersect$D$D$D$D$D$D$D$D', function (x1, y1, x2, y2, x3, y3, x4, y4) {
var denom = (y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1);
if (denom == 0 ) return false;
var num = (x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3);
var u = num / denom;
if (u < 0  || u > 1  ) return false;
num = (x2 - x1) * (y1 - y3) - (y2 - y1) * (x1 - x3);
u = num / denom;
if (u < 0  || u > 1  ) return false;
return true;
}, 1);

Clazz.newMeth(C$, 'getLinesIntersection$F$F$F$F', function (m1, b1, m2, b2) {
var result = Clazz.new_((I$[3]||$incl$(3)).c$$F$F,[0, 0]);
if (m1 == m2 ) {
result.x = NaN;
result.y = NaN;
} else if (m1 == -Infinity  || m1 == Infinity  ) {
throw Clazz.new_(Clazz.load('java.lang.RuntimeException').c$$S,["Method does not handle vertical lines yet"]);
} else {
var x = (b2 - b1) / (m1 - m2);
result.y = m1 * x + b1;
result.x = x;
}return result;
}, 1);

Clazz.newMeth(C$, 'clamp$D$D$D', function (min, value, max) {
if (Double.isNaN(min) || Double.isNaN(value) || Double.isNaN(max)  ) {
return NaN;
} else if (value < min ) {
return min;
} else if (value > max ) {
return max;
}return value;
}, 1);

Clazz.newMeth(C$, 'clamp$I$I$I', function (min, value, max) {
if (value < min) {
return min;
} else if (value > max) {
return max;
}return value;
}, 1);

Clazz.newMeth(C$, 'clamp$D$edu_colorado_phet_common_phetcommon_util_DoubleRange', function (value, range) {
return C$.clamp$D$D$D(range.getMin(), value, range.getMax());
}, 1);

Clazz.newMeth(C$, 'clamp$D$edu_colorado_phet_common_phetcommon_util_IntegerRange', function (value, range) {
return C$.clamp$D$D$D(range.getMin(), value, range.getMax());
}, 1);

Clazz.newMeth(C$, 'getAngle$java_awt_geom_Point2D$java_awt_geom_Point2D', function (origin, end) {
var theta = Math.atan2(end.getY() - origin.getY(), end.getX() - origin.getX());
return theta;
}, 1);

Clazz.newMeth(C$, 'radialToCartesian$D$D$java_awt_geom_Point2D', function (r, theta, origin) {
var x = r * Math.cos(theta);
var y = r * Math.sin(theta);
return Clazz.new_((I$[2]||$incl$(2)).c$$D$D,[origin.getX() + x, origin.getY() + y]);
}, 1);

Clazz.newMeth(C$, 'getPointOnLineClosestToPoint$java_awt_geom_Line2D$java_awt_geom_Point2D', function (line, point) {
var deltaX = ((line.getX1()) - (line.getX2()));
var deltaY = ((line.getY1()) - (line.getY2()));
var x = (line.getX1()) - (deltaX * (deltaX * ((line.getX1()) - (point.getX())) + deltaY * ((line.getY1()) - (point.getY())))) / (deltaX * deltaX + deltaY * deltaY);
var y = (deltaX * (-((line.getX2()) * (line.getY1())) + (line.getX1()) * (line.getY2()) + deltaY * (point.getX())) + deltaY * deltaY * (point.getY()) ) / (deltaX * deltaX + deltaY * deltaY);
return Clazz.new_((I$[2]||$incl$(2)).c$$D$D,[x, y]);
}, 1);

Clazz.newMeth(C$, 'getVectorFromLineToPoint$java_awt_geom_Line2D$java_awt_geom_Point2D', function (line, point) {
var pointOnLine = C$.getPointOnLineClosestToPoint$java_awt_geom_Line2D$java_awt_geom_Point2D(line, point);
return Clazz.new_((I$[4]||$incl$(4)).c$$D$D,[point.getX() - pointOnLine.getX(), point.getY() - pointOnLine.getY()]);
}, 1);

Clazz.newMeth(C$, 'signum$D', function (v) {
if (v < 0.0 ) {
return -1.0;
}if (v > 0.0 ) {
return 1.0;
}return 0.0;
}, 1);

Clazz.newMeth(C$, 'max$DA', function (v) {
Clazz.assert(C$, this, function(){return v.length > 0});
var max = v[0];
for (var i = 0; i < v.length; i++) {
if (v[i] > max ) {
max = v[i];
}}
return max;
}, 1);

Clazz.newMeth(C$, 'getLeastCommonMultiple$I$I', function (a, b) {
var found = false;
var aFactor = 0;
a = a < 0 ? -a : a;
b = b < 0 ? -b : b;
while (!found){
aFactor++;
for (var bFactor = (a/b|0); bFactor * b <= aFactor * a; bFactor++) {
if (bFactor * b == aFactor * a) {
found = true;
}}
}
return a * aFactor;
}, 1);

Clazz.newMeth(C$, 'getLineCircleIntersection$java_awt_geom_Ellipse2D$java_awt_geom_Line2D', function (c, l) {
var cx = c.getCenterX();
var cy = c.getCenterY();
var x1 = l.getX1() - cx;
var x2 = l.getX2() - cx;
var y1 = l.getY1() - cy;
var y2 = l.getY2() - cy;
var r = c.getWidth() / 2;
var dx = x2 - x1;
var dy = y2 - y1;
var dr = Math.sqrt(dx * dx + dy * dy);
var D = x1 * y2 - x2 * y1;
var discriminant = r * r * dr * dr  - D * D;
var radical = Math.sqrt(discriminant);
var numeratorX_1 = D * dy - C$.getSign$D(dy) * dx * radical ;
var numeratorX_2 = D * dy + C$.getSign$D(dy) * dx * radical ;
var numeratorY_1 = -D * dx - Math.abs(dy) * radical;
var numeratorY_2 = -D * dx + Math.abs(dy) * radical;
var result = Clazz.array((I$[5]||$incl$(5)), [2]);
if (discriminant >= 0 ) {
var denom = dr * dr;
result[0] = Clazz.new_((I$[2]||$incl$(2)).c$$D$D,[cx + numeratorX_1 / denom, cy + numeratorY_1 / denom]);
result[1] = Clazz.new_((I$[2]||$incl$(2)).c$$D$D,[cx + numeratorX_2 / denom, cy + numeratorY_2 / denom]);
}return result;
}, 1);

Clazz.newMeth(C$, 'getProjection$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D', function (v1, v2) {
var proj = Clazz.new_((I$[4]||$incl$(4)).c$$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D,[v2]).normalize();
proj = proj.scale$D(v1.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D(proj));
return proj;
}, 1);

Clazz.newMeth(C$, 'daysToMilliseconds$J', function (days) {
return days * 24 * 60 * 60 * 1000 ;
}, 1);

Clazz.newMeth(C$, 'roundHalfUp$D', function (d) {
return ((d + ((d >= 0 ) ? 0.5 : -0.5))|0);
}, 1);

Clazz.newMeth(C$, 'getGreatestCommonDivisor$I$I', function (a, b) {
if (b == 0) {
return a;
} else {
return C$.getGreatestCommonDivisor$I$I(b, a % b);
}}, 1);

Clazz.newMeth(C$, 'isInteger$D', function (value) {
return value == Math.round(value) ;
}, 1);

Clazz.newMeth(C$, 'segmentsIntersectL2$java_awt_geom_Line2D_Double$java_awt_geom_Line2D_Double', function (a, b) {
return C$.segmentsIntersect$D$D$D$D$D$D$D$D(a.x1, a.y1, a.x2, a.y2, b.x1, b.y1, b.x2, b.y2);
}, 1);

Clazz.newMeth(C$, 'segmentsIntersectLP2$java_awt_geom_Line2D_Double$java_awt_geom_Point2D_Double$java_awt_geom_Point2D_Double', function (a, p1, p2) {
return C$.segmentsIntersect$D$D$D$D$D$D$D$D(a.x1, a.y1, a.x2, a.y2, p1.x, p1.y, p2.x, p2.y);
}, 1);

Clazz.newMeth(C$, 'setToRotation$java_awt_geom_AffineTransform$D$D$D', function (tx, theta, x, y) {
if (tx == null ) tx = (C$.tempTx == null  ? (C$.tempTx = Clazz.new_((I$[6]||$incl$(6)))) : C$.tempTx);
tx.setToRotation$D$D$D(theta, x, y);
return tx;
}, 1);
C$.$_ASSERT_ENABLED_ = ClassLoader.$getClassAssertionStatus(C$);
;
(function(){var C$=Clazz.newClass(P$.MathUtil, "Average", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.sum = 0;
this.num = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.reset();
}, 1);

Clazz.newMeth(C$, 'addValue$D', function (newValue) {
this.sum += newValue;
this.num++;
});

Clazz.newMeth(C$, 'getAverage', function () {
return this.sum / this.num;
});

Clazz.newMeth(C$, 'numValues', function () {
return this.num;
});

Clazz.newMeth(C$, 'reset', function () {
this.sum = 0;
this.num = 0;
});
})()

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:32:59
