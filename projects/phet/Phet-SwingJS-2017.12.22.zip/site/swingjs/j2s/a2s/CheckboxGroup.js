(function(){var P$=Clazz.newPackage("a2s");
var C$=Clazz.newClass(P$, "CheckboxGroup", null, 'javax.swing.ButtonGroup');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'getSelectedCheckbox', function () {
for (var e = this.getElements(); e.hasMoreElements(); ) {
var ab = e.nextElement();
if (ab.isSelected()) return ab;
}
return null;
});
})();
//Created 2017-12-17 19:28:41
