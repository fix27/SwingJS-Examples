(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.models.treealign"),I$=[];
var C$=Clazz.newInterface(P$, "TreeAlignLabelDistanceAsymmetric");
})();
//Created 2018-01-31 11:12:45
