(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.models.treealign"),I$=[];
var C$=Clazz.newClass(P$, "AlignedNode", null, null, 'fr.orsay.lri.varna.models.treealign.GraphvizDrawableNodeValue');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.leftNode = null;
this.rightNode = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getLeftNode', function () {
return this.leftNode;
});

Clazz.newMeth(C$, 'setLeftNode$fr_orsay_lri_varna_models_treealign_Tree', function (leftNode) {
this.leftNode = leftNode;
});

Clazz.newMeth(C$, 'getRightNode', function () {
return this.rightNode;
});

Clazz.newMeth(C$, 'setRightNode$fr_orsay_lri_varna_models_treealign_Tree', function (rightNode) {
this.rightNode = rightNode;
});

Clazz.newMeth(C$, 'maybeNodeToGraphvizNodeName$fr_orsay_lri_varna_models_treealign_Tree', function (tree) {
return (tree != null  && tree.getValue() != null  ) ? tree.getValue().toGraphvizNodeName() : "_";
});

Clazz.newMeth(C$, 'toGraphvizNodeName', function () {
return "(" + p$.maybeNodeToGraphvizNodeName$fr_orsay_lri_varna_models_treealign_Tree.apply(this, [this.leftNode]) + "," + p$.maybeNodeToGraphvizNodeName$fr_orsay_lri_varna_models_treealign_Tree.apply(this, [this.rightNode]) + ")" ;
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:12:44
