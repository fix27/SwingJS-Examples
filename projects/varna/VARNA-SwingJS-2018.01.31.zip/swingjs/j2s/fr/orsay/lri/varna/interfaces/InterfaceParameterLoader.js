(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.interfaces"),I$=[];
var C$=Clazz.newInterface(P$, "InterfaceParameterLoader");
})();
//Created 2018-01-31 11:12:41
