(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.models.export"),I$=[];
var C$=Clazz.newClass(P$, "ColorCommand", null, 'fr.orsay.lri.varna.models.export.GraphicElement');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._color = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Color', function (c) {
Clazz.super_(C$, this,1);
this._color = c;
}, 1);

Clazz.newMeth(C$, 'getColor', function () {
return this._color;
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:12:42
