(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.controlers"),I$=[['fr.orsay.lri.varna.controlers.ControleurVueAnnotation$1']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ControleurVueAnnotation", null, null, ['javax.swing.event.CaretListener', 'javax.swing.event.ChangeListener', 'java.awt.event.ActionListener']);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._vueAnnot = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$fr_orsay_lri_varna_views_VueAnnotation', function (vueAnnot) {
C$.$init$.apply(this);
this._vueAnnot = vueAnnot;
}, 1);

Clazz.newMeth(C$, 'caretUpdate$javax_swing_event_CaretEvent', function (arg0) {
this._vueAnnot.update();
});

Clazz.newMeth(C$, 'stateChanged$javax_swing_event_ChangeEvent', function (arg0) {
this._vueAnnot.update();
});

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (arg0) {
if (arg0.getActionCommand().equals$O("setcolor")) {
var vui = this._vueAnnot.get_vp().getVARNAUI();
vui.showColorDialog$S$O$Runnable("Pick a color", this._vueAnnot.getTextAnnotation().getColor(), ((
(function(){var C$=Clazz.newClass(P$, "ControleurVueAnnotation$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'run', function () {
var c = this.$finals.vui.dialogReturnValue;
if (c != null ) this.b$['fr.orsay.lri.varna.controlers.ControleurVueAnnotation']._vueAnnot.updateColor$java_awt_Color(c);
this.b$['fr.orsay.lri.varna.controlers.ControleurVueAnnotation']._vueAnnot.update();
});
})()
), Clazz.new_((I$[1]||$incl$(1)).$init$, [this, {vui: vui}])));
}this._vueAnnot.update();
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:12:41
