(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.controlers"),I$=[];
var C$=Clazz.newClass(P$, "ControleurBPHeightIncrement", null, null, 'javax.swing.event.ChangeListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._vsbb = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$fr_orsay_lri_varna_views_VueBPHeightIncrement', function (vsbb) {
C$.$init$.apply(this);
this._vsbb = vsbb;
}, 1);

Clazz.newMeth(C$, 'stateChanged$javax_swing_event_ChangeEvent', function (e) {
this._vsbb.get_vp().setBPHeightIncrement$D((this._vsbb.getIncrement()).doubleValue());
this._vsbb.get_vp().drawRNA();
this._vsbb.get_vp().repaint();
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:12:40
