(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.models.export"),I$=[];
var C$=Clazz.newClass(P$, "FontCommand", null, 'fr.orsay.lri.varna.models.export.GraphicElement');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._font = 0;
this._size = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I$D', function (font, size) {
Clazz.super_(C$, this,1);
this._font = font;
this._size = size;
}, 1);

Clazz.newMeth(C$, 'get_font', function () {
return this._font;
});

Clazz.newMeth(C$, 'get_size', function () {
return this._size;
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:12:42
