(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.models.treealign"),I$=[];
var C$=Clazz.newClass(P$, "RNANodeValue2WrongTypeException", null, 'NullPointerException');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:12:45
