(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.applications.templateEditor"),I$=[[['fr.orsay.lri.varna.applications.templateEditor.TemplateEditorPanelUI','.Tool'],'javax.swing.undo.UndoableEditSupport',['fr.orsay.lri.varna.applications.templateEditor.TemplateEdits','.ElementEdgeMoveTemplateEdit'],['java.awt.geom.Point2D','.Double'],['fr.orsay.lri.varna.applications.templateEditor.GraphicalTemplateElement','.RelativePosition'],['fr.orsay.lri.varna.applications.templateEditor.TemplateEdits','.ElementAddTemplateEdit'],['fr.orsay.lri.varna.applications.templateEditor.TemplateEdits','.ElementRemoveTemplateEdit'],'fr.orsay.lri.varna.applications.templateEditor.GraphicalTemplateElement',['fr.orsay.lri.varna.applications.templateEditor.TemplateEdits','.ElementAttachTemplateEdit'],['fr.orsay.lri.varna.applications.templateEditor.TemplateEdits','.ElementDetachTemplateEdit'],['fr.orsay.lri.varna.applications.templateEditor.TemplateEdits','.HelixFlipTemplateEdit']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "TemplateEditorPanelUI");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._undoableEditSupport = null;
this._tp = null;
this.selectedTool = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.selectedTool = (I$[1]||$incl$(1)).CREATE_HELIX;
}, 1);

Clazz.newMeth(C$, 'c$$fr_orsay_lri_varna_applications_templateEditor_TemplatePanel', function (tp) {
C$.$init$.apply(this);
this._tp = tp;
this._undoableEditSupport = Clazz.new_((I$[2]||$incl$(2)).c$$O,[tp]);
}, 1);

Clazz.newMeth(C$, 'getSelectedTool', function () {
return this.selectedTool;
});

Clazz.newMeth(C$, 'setSelectedTool$fr_orsay_lri_varna_applications_templateEditor_TemplateEditorPanelUI_Tool', function (selectedTool) {
this.selectedTool = selectedTool;
});

Clazz.newMeth(C$, 'undoableEdgeMove$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement_RelativePosition$D$D', function (h, edge, nx, ny) {
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[3]||$incl$(3)).c$$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement_RelativePosition$D$D$fr_orsay_lri_varna_applications_templateEditor_TemplatePanel,[h, edge, nx, ny, this._tp]));
h.setEdgePosition$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement_RelativePosition$java_awt_geom_Point2D_Double(edge, Clazz.new_((I$[4]||$incl$(4)).c$$D$D,[nx, ny]));
this._tp.repaint();
});

Clazz.newMeth(C$, 'setEdge5UI$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$D$D', function (h, nx, ny) {
this.undoableEdgeMove$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement_RelativePosition$D$D(h, (I$[5]||$incl$(5)).RP_CONNECT_START5, nx, ny);
});

Clazz.newMeth(C$, 'setEdge3UI$fr_orsay_lri_varna_applications_templateEditor_UnpairedRegion$D$D', function (h, nx, ny) {
this.undoableEdgeMove$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement_RelativePosition$D$D(h, (I$[5]||$incl$(5)).RP_CONNECT_END3, nx, ny);
});

Clazz.newMeth(C$, 'setEdge5TangentUI$fr_orsay_lri_varna_applications_templateEditor_UnpairedRegion$D$D', function (h, nx, ny) {
this.undoableEdgeMove$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement_RelativePosition$D$D(h, (I$[5]||$incl$(5)).RP_EDIT_TANGENT_5, nx, ny);
});

Clazz.newMeth(C$, 'setEdge3TangentUI$fr_orsay_lri_varna_applications_templateEditor_UnpairedRegion$D$D', function (h, nx, ny) {
this.undoableEdgeMove$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement_RelativePosition$D$D(h, (I$[5]||$incl$(5)).RP_EDIT_TANGENT_3, nx, ny);
});

Clazz.newMeth(C$, 'moveUnpairedUI$fr_orsay_lri_varna_applications_templateEditor_UnpairedRegion$D$D', function (u, nx, ny) {
this.undoableEdgeMove$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement_RelativePosition$D$D(u, (I$[5]||$incl$(5)).RP_INNER_MOVE, nx, ny);
});

Clazz.newMeth(C$, 'moveHelixUI$fr_orsay_lri_varna_applications_templateEditor_Helix$D$D', function (h, nx, ny) {
this.undoableEdgeMove$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement_RelativePosition$D$D(h, (I$[5]||$incl$(5)).RP_INNER_MOVE, nx, ny);
});

Clazz.newMeth(C$, 'setHelixPosUI$fr_orsay_lri_varna_applications_templateEditor_Helix$D$D', function (h, nx, ny) {
this.undoableEdgeMove$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement_RelativePosition$D$D(h, (I$[5]||$incl$(5)).RP_EDIT_START, nx, ny);
});

Clazz.newMeth(C$, 'setHelixExtentUI$fr_orsay_lri_varna_applications_templateEditor_Helix$D$D', function (h, nx, ny) {
this.undoableEdgeMove$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement_RelativePosition$D$D(h, (I$[5]||$incl$(5)).RP_EDIT_END, nx, ny);
});

Clazz.newMeth(C$, 'addElementUI$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement', function (h) {
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[6]||$incl$(6)).c$$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$fr_orsay_lri_varna_applications_templateEditor_TemplatePanel,[h, this._tp]));
this._tp.addElement$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement(h);
});

Clazz.newMeth(C$, 'removeElementUI$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement', function (h) {
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[7]||$incl$(7)).c$$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$fr_orsay_lri_varna_applications_templateEditor_TemplatePanel,[h, this._tp]));
this._tp.removeElement$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement(h);
});

Clazz.newMeth(C$, 'addUndoableEditListener$javax_swing_undo_UndoManager', function (manager) {
this._undoableEditSupport.addUndoableEditListener$javax_swing_event_UndoableEditListener(manager);
});

Clazz.newMeth(C$, 'addConnectionUI$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement_RelativePosition$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement_RelativePosition', function (h1, e1, h2, e2) {
if ((I$[8]||$incl$(8)).canConnect$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement_RelativePosition$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement_RelativePosition(h1, e1, h2, e2)) {
var c = this._tp.addConnection$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement_RelativePosition$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement_RelativePosition(h1, e1, h2, e2);
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[9]||$incl$(9)).c$$fr_orsay_lri_varna_applications_templateEditor_Connection$fr_orsay_lri_varna_applications_templateEditor_TemplatePanel,[c, this._tp]));
}});

Clazz.newMeth(C$, 'removeConnectionUI$fr_orsay_lri_varna_applications_templateEditor_Connection', function (c) {
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[10]||$incl$(10)).c$$fr_orsay_lri_varna_applications_templateEditor_Connection$fr_orsay_lri_varna_applications_templateEditor_TemplatePanel,[c, this._tp]));
this._tp.removeConnection$fr_orsay_lri_varna_applications_templateEditor_Connection(c);
});

Clazz.newMeth(C$, 'flipHelixUI$fr_orsay_lri_varna_applications_templateEditor_Helix', function (h) {
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[11]||$incl$(11)).c$$fr_orsay_lri_varna_applications_templateEditor_Helix$fr_orsay_lri_varna_applications_templateEditor_TemplatePanel,[h, this._tp]));
this._tp.flip$fr_orsay_lri_varna_applications_templateEditor_Helix(h);
this._tp.repaint();
});

Clazz.newMeth(C$, 'getTemplate', function () {
return this._tp.getTemplate();
});
;
(function(){var C$=Clazz.newClass(P$.TemplateEditorPanelUI, "Tool", null, 'Enum');

C$.$clinit$ = function() {Clazz.load(C$, 1);
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "SELECT", 0, []);
Clazz.newEnumConst($vals, C$.c$, "CREATE_HELIX", 1, []);
Clazz.newEnumConst($vals, C$.c$, "CREATE_UNPAIRED", 2, []);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values', function() { return $vals }, 1);
})()

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:12:39
