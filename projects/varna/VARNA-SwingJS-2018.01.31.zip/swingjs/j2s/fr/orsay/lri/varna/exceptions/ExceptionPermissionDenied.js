(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.exceptions"),I$=[];
var C$=Clazz.newClass(P$, "ExceptionPermissionDenied", null, 'Exception');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._errorMessage = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (errorMessage) {
Clazz.super_(C$, this,1);
this._errorMessage = errorMessage;
}, 1);

Clazz.newMeth(C$, 'getError', function () {
return this._errorMessage;
});

Clazz.newMeth(C$, 'getMessage', function () {
return "Permission denied for security reason !\u000aConsider using the VARNA panel class in a signed context.\u000a";
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 11:12:41
