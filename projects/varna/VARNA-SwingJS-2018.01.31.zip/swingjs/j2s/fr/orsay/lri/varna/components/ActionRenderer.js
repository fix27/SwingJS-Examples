(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.components"),I$=[];
var C$=Clazz.newClass(P$, "ActionRenderer", null, 'javax.swing.JButton', 'javax.swing.table.TableCellRenderer');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'getTableCellRendererComponent$javax_swing_JTable$O$Z$Z$I$I', function (table, button, isSelected, hasFocus, row, column) {
this.setText$S(button.toString());
return this;
});
})();
//Created 2018-01-31 11:12:39
