(function(){var P$=Clazz.newPackage("java.awt.dnd.peer"),I$=[];
var C$=Clazz.newInterface(P$, "DragSourceContextPeer");
})();
//Created 2018-01-06 13:29:18
