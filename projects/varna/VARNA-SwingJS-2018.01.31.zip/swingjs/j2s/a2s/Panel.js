(function(){var P$=Clazz.newPackage("a2s"),I$=[['a2s.A2SEvent']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Panel", null, 'javax.swing.JPanel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_LayoutManager', function (layout) {
C$.superclazz.c$$java_awt_LayoutManager.apply(this, [layout]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'add$java_awt_Component', function (comp) {
C$.superclazz.prototype.add$java_awt_Component.apply(this, [comp]);
return (I$[1]||$incl$(1)).addComponent$java_util_EventListener$java_awt_Component(this.getTopLevelAncestor(), comp);
});
})();
//Created 2018-01-06 13:29:06
