(function(){var P$=Clazz.newPackage("a2s"),I$=[];
var C$=Clazz.newClass(P$, "Scrollbar", null, 'javax.swing.JScrollBar');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I', function (direction) {
C$.superclazz.c$$I.apply(this, [direction]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I$I', function (orientation, value, extent, min, max) {
C$.superclazz.c$$I$I$I$I$I.apply(this, [orientation, value, extent, min, max]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'setValue$I', function (n) {
C$.superclazz.prototype.setValue$I.apply(this, [n]);
});

Clazz.newMeth(C$, 'getMinimum', function () {
return C$.superclazz.prototype.getMinimum.apply(this, []);
});

Clazz.newMeth(C$, 'getMaximum', function () {
return C$.superclazz.prototype.getMaximum.apply(this, []);
});

Clazz.newMeth(C$, 'getValue', function () {
return C$.superclazz.prototype.getValue.apply(this, []);
});
})();
//Created 2018-01-06 13:29:07
