This directory contains:


js/*.js  a set of files needed for all SwingJS pagees

js/make.bat  a script that concatenates the *.js files in the right order to make swingjs2.js

js/core/  a folder used by build_core_applet.xml to create Google closure-compiled swingjs/j2s/core files.
  