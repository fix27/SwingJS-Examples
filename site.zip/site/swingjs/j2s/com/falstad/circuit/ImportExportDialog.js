(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[];
var C$=Clazz.newInterface(P$, "ImportExportDialog");
;
(function(){var C$=Clazz.newClass(P$.ImportExportDialog, "Action", null, 'Enum');

C$.$clinit$ = function() {Clazz.load(C$, 1);
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "IMPORT", 0, []);
Clazz.newEnumConst($vals, C$.c$, "EXPORT", 1, []);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values', function() { return $vals }, 1);
})()
})();
//Created 2018-01-31 09:35:26
