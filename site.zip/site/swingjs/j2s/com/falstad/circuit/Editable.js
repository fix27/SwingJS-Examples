(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[];
var C$=Clazz.newInterface(P$, "Editable");
})();
//Created 2018-01-31 09:35:26
