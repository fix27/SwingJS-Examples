(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[];
var C$=Clazz.newClass(P$, "GraphicElm", null, 'com.falstad.circuit.CircuitElm');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I$I', function (xx, yy) {
C$.superclazz.c$$I$I.apply(this, [xx, yy]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I$I', function (xa, ya, xb, yb, flags) {
C$.superclazz.c$$I$I$I$I$I.apply(this, [xa, ya, xb, yb, flags]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getPostCount', function () {
return 0;
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 09:35:26
