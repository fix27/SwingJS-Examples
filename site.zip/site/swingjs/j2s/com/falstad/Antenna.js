(function(){var P$=Clazz.newPackage("com.falstad"),I$=[['java.awt.Dimension','com.falstad.AntennaFrame',['com.falstad.AntennaFrame','.LinearCenterSetup'],['com.falstad.AntennaFrame','.LoopSetup'],['com.falstad.AntennaFrame','.BroadsideArraySetup'],['com.falstad.AntennaFrame','.EndFireArraySetup'],['com.falstad.AntennaFrame','.BinomialArraySetup'],['com.falstad.AntennaFrame','.SchelkunoffSetup'],['com.falstad.AntennaFrame','.FourierSectoralSetup'],['com.falstad.AntennaFrame','.FourierFunctionSetup'],'java.util.Vector',['com.falstad.AntennaFrame','.LinearSetup'],'com.falstad.AntennaLayout','com.falstad.AntennaCanvas','a2s.Choice','a2s.Checkbox','a2s.Label','a2s.Scrollbar','java.awt.Color','java.util.Random','java.awt.image.MemoryImageSource','java.awt.Rectangle','java.text.NumberFormat']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Antenna", null, 'a2s.Applet');
C$.ogf = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.started = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.started = false;
}, 1);

Clazz.newMeth(C$, 'destroyFrame', function () {
if (C$.ogf != null ) C$.ogf.dispose();
C$.ogf = null;
});

Clazz.newMeth(C$, 'init', function () {
C$.ogf = Clazz.new_((I$[2]||$incl$(2)).c$$com_falstad_Antenna,[this]);
C$.ogf.init();
});

Clazz.newMeth(C$, 'destroy', function () {
if (C$.ogf != null ) C$.ogf.dispose();
C$.ogf = null;
});

Clazz.newMeth(C$, 'main', function (args) {
C$.ogf = Clazz.new_((I$[2]||$incl$(2)).c$$com_falstad_Antenna,[null]);
C$.ogf.init();
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s = "Applet is open in a separate window.";
if (!this.started) s = "Applet is starting.";
 else if (C$.ogf == null ) s = "Applet is finished.";
 else if (C$.ogf.useFrame) C$.ogf.triggerShow();
if (C$.ogf == null  || C$.ogf.useFrame ) g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMeth(C$);
})();
//Created 2018-01-31 09:35:04
